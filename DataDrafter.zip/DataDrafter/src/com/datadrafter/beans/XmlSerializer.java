package com.datadrafter.beans;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import com.datadrafter.xcad.CadDrawing;

public class XmlSerializer {
	public static class CadDrawingSerializer {
	    public static void write(CadDrawing d, String filename) throws Exception{
	        XMLEncoder encoder =
	           new XMLEncoder(
	              new BufferedOutputStream(
	                new FileOutputStream(filename)));
	        encoder.writeObject(d);
	        encoder.close();
	    }

	    public static CadDrawing read(String filename) throws Exception {
	        XMLDecoder decoder =
	            new XMLDecoder(new BufferedInputStream(
	                new FileInputStream(filename)));
	        CadDrawing d = (CadDrawing)decoder.readObject();
	        decoder.close();
	        return d;
	    }
	}
}
