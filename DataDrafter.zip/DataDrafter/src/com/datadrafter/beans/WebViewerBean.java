package com.datadrafter.beans;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Vector;

import com.datadrafter.xcad.CadDrawing;
import com.datadrafter.xcad.CadView;
import com.datadrafter.links.DataLink;
import com.datadrafter.links.DataLinks;
import com.datadrafter.links.LinkGroup;
import com.datadrafter.reports.WebReports;
import com.datadrafter.utils.Utils;

public class WebViewerBean {
  //private DataLinks  links     = new DataLinks(Utils.getProperty("datadrafter.config.links"));
  //private Attribs    attribs   = new Attribs(Utils.getProperty("datadrafter.config.attribs"));
  //private Details 	 details   = new Details(Utils.getProperty("datadrafter.config.details"));
  //private Templates  templates = new Templates(Utils.getProperty("datadrafter.config.templates"));
  private WebReports reports   = new WebReports();

  public WebViewerBean() {
  } 

  public String getTabLayout(DataLink link, int start_tab, int num_tabs, int tab) {
  	String html = "";
  	html = reports.tabLayout(link, start_tab, num_tabs, tab);
  	return html;
  }
  public String getTypeCount(DataLink link) {
  	String html = "";
  	html = reports.typeCount(link);
  	return html;
  }

  public String getTypeList(LinkGroup group, long typeId) {
  	return DataLinks.getTypeList("", group, typeId);
  }
  public String getTypeList(DataLink link, long typeId) {
  	return DataLinks.getTypeList("", link, typeId);
  }
    public Vector getGroups() { 
    return DataLinks.getGroups();
  }
    
  public void deleteSVG(String filename){
	String fileFullPath = Utils.getProperty("datadrafter.drawings.path.svg") + filename;
	File file = new File(fileFullPath);
 	file.delete();
  }

//  public String toSVG(long id, String filename, long viewid) throws IOException {
//	  //PrintWriter out      = null;
//	  CadDrawing  drawing  = null;
//	  CadView     view     = null;
//	  DataLink    link     = null;
//	  String      xml      = null;
//	  //String      filepath = null;
//	  //File        outfile  = null;
//	  
//	  link = DataLinks.getDataLink(id);
//
//	  if (link != null) {
//		if (link.getDrawingId() != -1) {
//		  drawing = new CadDrawing(link.getDrawingId());
//		  	if (link.getElementId() != -1) {
//		  	 	drawing.select(view.getSelectedShapes(), link.getElementId());
//		  	}
//		  xml = drawing.toSVG(view);
//		}
//	  }
//	  return xml;
//	}

  	public String getMembersList(Object in_link, long sel_link_id) {
  	  String html = "";
  	  Iterator iter = null;
  	  
  	  if (in_link instanceof LinkGroup) {
        iter = ((LinkGroup)in_link).getMembers().iterator(); 
  	  } else {
        iter = ((DataLink)in_link).getMembers().iterator();
  	  }

  	while (iter.hasNext()) {
        long id = ((Long)iter.next()).longValue();
        DataLink link = DataLinks.getDataLink(id);

        if (link.getMembers().size() > 0) {
        	html += "<a class=dataLink href=\"#\">\n" +
        	        "<img border=\"0\" title=\"Open Folder\"\n" +
					"src=\"icons/folder.gif\" width=\"20\"\n" +
					"height=\"20\" align=\"middle\"\n" + 
           		    "onClick=downButtonPushed(" + link.getId() + 
					")></a>\n";
        	
          } else {
            html += "&nbsp;&nbsp;&nbsp;\n" +
	                "<a class=dataLink href=\"#\"\n" + 
					"onclick=javascript:linkSelected(\"" +
					link.getId() + "\")>\n" +
	                link.getName() + "</a>\n";
	        if (link.getId() == sel_link_id) {
	            html += "<img border=\"0\" title=\"Current Link\"" +
				        "src=\"icons/selected.gif\" width=\"16\"" +
						"height=\"16\" align=\"middle\">";
	        }
          }
  	   }
  	   return html;
  	}
}
