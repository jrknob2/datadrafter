package com.datadrafter.data;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;

import com.datadrafter.events.ObjectAction;
import com.datadrafter.gui.personal.DataDrafter;
import com.datadrafter.links.DataLink;
import com.datadrafter.links.DataLinks;
import com.datadrafter.links.LinkGroup;
import com.datadrafter.modeler.Detail;
import com.datadrafter.modeler.Template;
import com.datadrafter.tables.TableEditor;
import com.datadrafter.utils.Utils;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class DataEditor extends JToolBar { //implements ObjectActionListener {

	private static final long serialVersionUID = 1L;
	String[]        columns        	= {"Attribute", "Value"};
	String[]        columns2        	= {"Type", "Count"};
	TableEditor     summaryTable  	= new TableEditor(columns2);
	JTabbedPane     tab           	= new JTabbedPane();
	JPanel          tablePanel      = new JPanel(new BorderLayout());
	JPanel          mainPanel       = new JPanel(new BorderLayout());
	JLabel          item            = new JLabel();
	JComboBox       detailSelection	= new JComboBox();
	TableEditor     detailTable   	= new TableEditor(columns);
	Object			curr_obj		= null;
	DataLink        link            = null;
	LinkGroup       group			= null;
	AttributeValues values    		= null;
	AttributeValues summaryValues   = null;
	JToolBar        valueToolBar    = new JToolBar(JToolBar.HORIZONTAL);
  	JButton 		saveButton      = new JButton();
  	JButton 		reportButton    = new JButton();
  
	ClassLoader cl = DataDrafter.class.getClassLoader();
	
	ImageIcon saveIcon 	   	= new ImageIcon(cl.getResource("icons/Save16.gif"));
  	ImageIcon reportIcon	= new ImageIcon(cl.getResource("icons/History16.gif"));
  	
	public void myPropertyChange(PropertyChangeEvent evt) {
		JToolBar tb = (JToolBar)evt.getSource();
		if (tb.getParent() instanceof JPanel) {
			JPanel parent = (JPanel)tb.getParent();
			parent.setPreferredSize(new Dimension(500, 300));
			//JDialog tbdialog = (JDialog)parent.getParent().getParent(); //.getParent();
			//tbdialog.setResizable(false);
		}
	}

	public DataEditor() {
		setLayout(new BorderLayout());
		setBorder(BorderFactory.createEmptyBorder());
		this.setFloatable(false);
		saveButton.setToolTipText("Save");
		reportButton.setToolTipText("Report");
		saveButton.setIcon(saveIcon);
		reportButton.setIcon(reportIcon);
		valueToolBar.add(saveButton, null);
		valueToolBar.add(reportButton, null);
		valueToolBar.setFloatable(false);
		this.addPropertyChangeListener(new PropertyChangeListener() {
    	public void propertyChange(PropertyChangeEvent evt) {
    		myPropertyChange(evt);
    	}
    });

//    header.setFont(new java.awt.Font("Dialog", 1, 12));
//    header.setBorder(BorderFactory.createRaisedBevelBorder());
//    header.setHorizontalAlignment(SwingConstants.CENTER);
//    header.setText("Data Editor");

    item.setFont(new java.awt.Font("Dialog", 1, 12));
    item.setHorizontalAlignment(SwingConstants.LEFT);
    
    //mainPanel.add(header, BorderLayout.NORTH);
    mainPanel.add(valueToolBar, BorderLayout.WEST);
    mainPanel.add(item, BorderLayout.CENTER);

    add(mainPanel, BorderLayout.NORTH);
    add(tablePanel, BorderLayout.CENTER);

    saveButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
//        values.toXML();
        if (values != null) values.toFile();
      }
    });

    reportButton.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	ObjectAction.fireObjectActionEvent(values == null ? summaryTable : detailTable, values, ObjectAction.NEW_REPORT);
        }
    });
   
    tablePanel.add(tab);
    tab.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
    tab.addChangeListener(new javax.swing.event.ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        Utils.tabStateChanged(tab);
      }
    });
  }

  public String getItem() { return item.getText(); }
  
  public void clear() {
//	if (curr_obj instanceof LinkGroup) return;
//	if (curr_obj instanceof DataLink) {
//		DataLink link = (DataLink)curr_obj;
//		if (link.getElementId() == -1)
//			return;
//	}
	if (getValues() != null) getValues().prepareToClose();
  	summaryValues = null;
  	item.setText(""); 	
    tab.removeAll();
    values = null;
    curr_obj = null;
  }
  
  public void addTabs(DataLink link) {
  	if (values == null) return;
  	curr_obj = link;
  	this.saveButton.setEnabled(true);
  	item.setText(" " + values.getTemplate().getName() + " : " + link.getName());
    Iterator iter = values.getTemplate().getDetails().iterator();
    while (iter.hasNext()) {
    	Object obj = iter.next();
    	if (obj instanceof Detail) {
    		Detail detail = (Detail)obj;
    		TableEditor editor = new TableEditor(columns);
    		editor.setDataObject(values, values.toTableData(detail));
    		tab.add(editor, detail.getName());
    	}
    }
  }
  
  public void addLinkSummaryTab(DataLink link ) {
	this.saveButton.setEnabled(false);
	curr_obj = link;
  	int index = 0;
  	item.setText(" " + link.getName());
  	Vector types = DataLinks.getAllDataTypes(link);
    if (types == null) return;
  	Object[][] data = new Object[types.size()][2];

  	Iterator iter = types.iterator();
    while (iter.hasNext()) {
    	Template template = (Template) iter.next();
        int count = DataLinks.getDataTypeCount(template, link);
        data[index][0] = template;
        data[index][1] = new Integer(count);
        ++index;
	}
    
    String[] columns = {"Types", "Total"};
    summaryTable = new TableEditor(columns);
    summaryTable.setDataObject(link, data);
    tab.add(summaryTable, "Summary");
  }
  
  public void addGroupSummaryTab(LinkGroup group) {
	this.saveButton.setEnabled(false);
	curr_obj = group;
  	int index = 0;
  	item.setText(" " + group.getName());
  	Vector types = DataLinks.getAllDataTypes(group);
    if (types == null) return;
  	Object[][] data = new Object[types.size()][2];

  	Iterator iter = types.iterator();
    while (iter.hasNext()) {
    	Template template = (Template) iter.next();
        int count = DataLinks.getDataTypeCount(template, group);
        data[index][0] = template;
        data[index][1] = new Integer(count);
        ++index;
	}

    String[] columns = {"Type", "Total"};
    summaryTable = new TableEditor(columns);
    summaryTable.setDataObject(link, data);
    tab.add(summaryTable, "Summary");
  }
/**
 * @param values The values to set.
 */
  public void setValues(AttributeValues values) {
  	if (this.values != null) this.values.prepareToClose();
  	this.values = values;
  }
  public AttributeValues getValues() {
  	return values;
  }
  public String getXSLT() {
	  return "<?xml version=\"1.0\" encoding=\"utf-8\" ?>" +
		"<xsl:stylesheet xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" version=\"1.0\">" +
		"<xsl:output method=\"html\"/>" +
		"<xsl:template match=\"/\">" +
		"<html><head><title>Template Report</title></head>" +
		"<body><table><tr><th>Template Name</th></tr><tr>" +
		"<th>Detail Name</th><th>Attribute Name</th><th>Attribute Value</th>" +
		"</tr><xsl:for-each select=\"values/attribvalue/detailname\">" +
		"<tr><td><xsl:value-of select=\"detailname\"/></td>" +
		"<td><xsl:value-of select=\"attributename\"/></td>" +
		"<td><xsl:value-of select=\"value\"/></td>" +
		"</tr></xsl:for-each></xsl:template></xsl:stylesheet>";
  }
}
