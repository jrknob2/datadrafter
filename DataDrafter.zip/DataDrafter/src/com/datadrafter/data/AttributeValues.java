package com.datadrafter.data;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.JOptionPane;

import com.datadrafter.links.DataLink;
import com.datadrafter.modeler.Attrib;
import com.datadrafter.modeler.Detail;
import com.datadrafter.modeler.Template;
import com.datadrafter.modeler.Templates;
import com.datadrafter.utils.Utils;


public class AttributeValues  { //implements ObjectActionListener {
  String   filename;
  DataLink link;
  Template template;
  Vector   values = new Vector();
  Vector   modified = new Vector();
  boolean  clean = true;
  
  public AttributeValues(Template template, String xml) {
	  this.template = template;
	  load(xml);
  }
  public AttributeValues(DataLink link, String codeBase) {
	  this.link = link;
	  this.template = Templates.getDetailTemplate(link.getId());
	  
	  URL url =  null;
	  
	  try {
		  url = new URL(codeBase + "data/" + link.getId() + ".DAT");
	  } catch (MalformedURLException e) {
		  // TODO Auto-generated catch block
		  e.printStackTrace();
	  }
	  load(url);
  }
  public AttributeValues(DataLink link) {
 	             
    this.link = link;
    this.template = Templates.getDetailTemplate(link.getTypeId());
    filename = Utils.getProperty("datadrafter.data.path") + 
	           link.getId() + Utils.getProperty("datadrafter.data.file.extention");
    load();
  }

  public Template getTemplate() {
    return template;
  }

  public Vector getModified() {
    return modified;
  }

  public void setClean(boolean value) {
  	this.clean = value;
  }
  public boolean getClean() {
    return clean;
  	//return (modified.size() == 0);
  }

  public void load() {
  	long detailId;
    long attribId;
    String line = null;
    String sBuff = null;
    StringTokenizer st;
    String token;
    BufferedReader in = null;
    AttributeValue value = null;

    try {
      in = new BufferedReader(new FileReader(filename));
    }
    catch (IOException ioe) {
      if (ioe instanceof FileNotFoundException) {
//        File file = new File(filename);
        return;
      }
    }

    try {
      while (true) {
        line = in.readLine();
        if (line == null || line.length() == 0) {
          break;
        }
        sBuff = "";
        st = new StringTokenizer(line, "|");
        token = st.nextToken();
        if (token.equals("//")) {
          ;
        }
        else if (token.equals("value")) {
          if (value != null) {
          	values.add(value);
          }
          detailId = Long.parseLong(st.nextToken());
          attribId = Long.parseLong(st.nextToken());
          sBuff += st.nextToken();
          value = new AttributeValue(detailId, attribId, sBuff);
        }
      }
      if (value != null) {
        values.add(value);
      }
      modified.clear();
    }
    catch (IOException ioe) {
      ioe.printStackTrace();
    }
    catch (NumberFormatException nfe) {
      nfe.printStackTrace();
    }
    catch (NoSuchElementException nse) {
      nse.printStackTrace();
    }
    finally {
      try {
        in.close();
      }
      catch (IOException ioe) {
        ioe.printStackTrace();
      }
    }
  }

  public void load(URL url) {
	  	long detailId;
	    long attribId;
	    String line = null;
	    String sBuff = null;
	    StringTokenizer st;
	    String token;
	    BufferedReader in = null;
	    AttributeValue value = null;

	    try {
			InputStream is = url.openStream(); 
			InputStreamReader inR = new InputStreamReader(is) ; 
			in = new BufferedReader(inR);
	    }
	    catch (IOException ioe) {
	      if (ioe instanceof FileNotFoundException) {
//	        File file = new File(filename);
	        return;
	      }
	    }

	    try {
	      while (true) {
	        line = in.readLine();
	        if (line == null || line.length() == 0) {
	          break;
	        }
	        sBuff = "";
	        st = new StringTokenizer(line, "|");
	        token = st.nextToken();
	        if (token.equals("//")) {
	          ;
	        }
	        else if (token.equals("value")) {
	          if (value != null) {
	          	  values.add(value);
	          }
	          detailId = Long.parseLong(st.nextToken());
	          attribId = Long.parseLong(st.nextToken());
	          sBuff += st.nextToken();
	          value = new AttributeValue(detailId, attribId, sBuff);
	        }
	      }
	      if (value != null) {
	    	  values.add(value);
	      }
	      modified.clear();
	      System.out.println("after clear");
	    }
	    catch (IOException ioe) {
	      ioe.printStackTrace();
	    }
	    catch (NumberFormatException nfe) {
	      nfe.printStackTrace();
	    }
	    catch (NoSuchElementException nse) {
	      nse.printStackTrace();
	    }
	    finally {
	      try {
	        in.close();
	      }
	      catch (IOException ioe) {
	        ioe.printStackTrace();
	      }
	    }
	  }

  public void load(String xml) {

  }

  public AttributeValue getValue(long detailId, long attribId) {
    Iterator iter = values.iterator();
    while (iter.hasNext()) {
      AttributeValue value = (AttributeValue) iter.next();
      if (detailId == -1 && value.getAttribId() == attribId) {
        return value;
      }
      else {
        if (value.getDetailId() == detailId && value.getAttribId() == attribId) {
          return value;
        }
      }
    }
    return null;
  }

  public void add(AttributeValue attribv) {
    values.add(attribv);
  }

  public String getFileName() {
    return //Utils.getProperty("datadrafter.drawings.file.extention") +
           filename;
  }
  public void toFile() {
    try {
      PrintWriter out = new PrintWriter(new FileWriter(getFileName()));
      Enumeration en = values.elements();
      while (en.hasMoreElements()) {
        ( (AttributeValue) en.nextElement()).toFile(out);
      }
      out.flush();
      out.close();
      modified.clear();
    }
    catch (IOException ioe) {
    	ioe.printStackTrace();
    }
  }
  
  public String toXML() {
	  String xmldoc = "";
	  Vector details = null;
	  
	  xmldoc = "<?xml version=\"1.0\" ?>\n" + 
		  		"<values>\n" +
               "	<linkid>" + link.getId() + "</linkid>\n" +
               "	<linkName>" + link.getName() + "</linkName>\n" +
               "	<templateId> " + template.getId() + "</templateId>" +
               "	<templateName>" + template.getName() + "</templateName>";

      Iterator iter = template.getDetails().iterator();
      while (iter.hasNext()) {
    	  Detail detail = (Detail)iter.next();
    	  xmldoc += "<detail><name>" + detail.getName() + "</name>";
    	  Iterator iter2 = values.iterator();
    	  while (iter2.hasNext()) {
    		  AttributeValue attr = (AttributeValue)iter2.next();
    		  if (detail.getId() == attr.getDetailId())
    			  xmldoc += attr.toXML();
    	  }
    	  xmldoc += "</detail>\n";
      }
      xmldoc += "</values>\n";
      return xmldoc;
  }

  public String toHTMLTable(int start, int num_tabs, int selectTab) {
  	String html = "";
    Object[][] table = null;
    int tab_num = 1;
    Detail selectedDetail = null;
    
    html += "<font class=reportTitle>" + template.getName() + ": " + link.getName() + "</font>";

    html += "<table border=0 cellpadding=0 cellspacing=0>\n";
    html += "    <tr nowrap><td>";

    Iterator iter = template.getDetails().iterator();
    
    if (start > 1) { 
    	html += "<a class=regularTab href=javascript:tabFirst()>&nbsp;<<&nbsp;</a>&nbsp;";
    	html += "<a class=regularTab href=javascript:tabBackward()>&nbsp;<&nbsp;</a>&nbsp;";
    }
    int index = 1;
    while (iter.hasNext()) {
      Detail detail = (Detail) iter.next();
      if (index < start) {
      	++index;
      	continue;
      } else {
        if (selectTab == tab_num) {
          html += "<a class=selectedTab href=javascript:tabSelected(" + tab_num + ")>&nbsp;" + detail.getName() + "&nbsp;</a>&nbsp;";
          selectedDetail = detail;
        } else {
          html += "<a class=regularTab href=javascript:tabSelected(" + tab_num + ")>&nbsp;" + detail.getName() + "&nbsp;</a>&nbsp;";
        }
        ++tab_num;
        if (tab_num > num_tabs) break;
      }
    }
    if (start + num_tabs < template.getDetails().size()) { 
    	html += "<a class=regularTab href=javascript:tabForward()>&nbsp;>&nbsp;</a>&nbsp;";
    	html += "<a class=regularTab href=javascript:tabLast(" + (template.getDetails().size() - num_tabs) + ")>&nbsp;>>&nbsp;</a>&nbsp;";
    }
    
    html += "</td></tr></table>";
    //html +=  "<br>";

    if (selectedDetail != null) {
    	table = toTableData(selectedDetail);

    	html += "<table border=1 nowrap cellpadding=0 cellspacing=0 width=100%>";
    	html += "<tr style=background-color:#555555>";
    	html += "  <td width=30% nowrap><font face=Tahoma size=2><b>Attribute</b></font></td>";
    	html += "  <td width=70% nowrap><font face=Tahoma size=2><b>Value</b></font></td>";
    	html += "</tr>";

    	for (int i = 0; i < selectedDetail.getAttributes().size(); ++i) {
    		html += "<tr>";
    		html += "  <td width=30% nowrap><font face=Tahoma size=2><b>" + table[i][0] + "</b></font></td>";
    		html += "  <td width=70%><font face=Tahoma size=2>" + table[i][1] + "</font></td>";
    		html += "</tr>";
    	}
    	html += "</table>";
    }
    return html;
  }

  public Object[][] toTableData(Detail detail) {
    Object[][] data = new Object[detail.getAttributes().size()][2];
    int i = 0;

    Iterator iter = detail.getAttributes().iterator();
    while (iter.hasNext()) {
    	Object obj = iter.next();
    	if (obj instanceof Attrib) {
    		Attrib attrib = (Attrib)obj;
    		AttributeValue value = this.getValue(detail.getId(), attrib.getId());
    		if (value == null) {
    			value = new AttributeValue(detail.getId(), attrib.getId(), "");
    			values.add(value);
    		}
    		value.setLabel(attrib.getName());
    		data[i][0] = value;
    		data[i++][1] = value.getValue();
    	}
    }
    return data;
  }
  public void prepareToClose() {
//  	System.out.println("getClean()-> " + getClean());
    if (getClean() == false) {
      //Custom button text
      Object[] options = {
          "Yes", "No"};
      int n = JOptionPane.showOptionDialog(null,
                                           "The data values for " +
                                           link.getName() +
                                           " have been modified. " +
          "Would you like to save your changes?",
          "Data Values Modified",
          JOptionPane.YES_NO_OPTION,
          JOptionPane.QUESTION_MESSAGE,
          null,
          options,
          options[1]);
      if (n == 0) {
        toFile();
      }
      setClean(true);
    }
  }
}