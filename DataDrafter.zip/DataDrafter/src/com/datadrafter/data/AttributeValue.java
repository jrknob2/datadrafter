package com.datadrafter.data;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
import java.io.PrintWriter;

import com.datadrafter.events.LinkAction;
import com.datadrafter.modeler.Attrib;
import com.datadrafter.modeler.Attribs;
import com.datadrafter.modeler.Detail;
import com.datadrafter.modeler.Details;

public class AttributeValue {
  long detailId;
  long attribId;
  String value;
  String label;
  boolean clean = true;

  public AttributeValue(long detailId, long attribId, String value) {
    this.detailId = detailId;
    this.attribId = attribId;
    this.value = value;
  }

  public void setDetailId(long detailId) {
    if (this.detailId == detailId) {
      return;
    }
    this.detailId = detailId;
    clean = false;
  }

  public long getDetailId() {
    return detailId;
  }

  public void setAttribId(long attribId) {
    if (this.attribId == attribId) {
      return;
    }
    this.attribId = attribId;
    clean = false;
  }

  public long getAttribId() {
    return attribId;
  }

  public void setValue(String value) {
    if (this.value == value) {
      return;
    }
    this.value = value;
    LinkAction.fireObjectActionEvent(this, LinkAction.DATA_MODIIED);
  }

  public String getValue() {
    return value == null ? "" : value;
  }

  public void setLabel(String label) {
    this.label = label;
  }

  public boolean getClean() {
    return clean;
  }

  public String toString() {
    return label;
  }

  public boolean toFile(PrintWriter out) {
    if (getValue().length() < 1) {
      return false;
    }

	
//	System.out.println("value" + "|" + getDetailId() +
//				"|" + getAttribId() +
//				"|" + getValue());

    out.println("value" + "|" + getDetailId() +
                "|" + getAttribId() +
                "|" + getValue());
    out.flush();
    clean = true;
    return true;
  }
  public void toXML(PrintWriter out) {
    out.print(toXML());
  }
  public String toXML() {
    
	Detail detail      = Details.getAttributeDetail(getDetailId());
    Attrib attrib      = Attribs.getAttribute(getAttribId());
    String detailId    = "0";
    String detailName  = "Not Found";
    String attribId    = "0";
    String attribName  = "Not Found";
    String attribValue = "Not Found";
    
    if (detail != null) {
    	detailId = Long.toString(detail.getId());
    	detailName = detail.getName();
    }
    
    if (attrib != null) {
    	attribId = Long.toString(attrib.getId());
    	attribName = attrib.getName();
    	attribValue = getValue();
    }
    

    return "	<attribvalue>\n" +
           "		<detailid>" + detailId + "</detailid>\n" +
           "		<detailname>" + detailName + "</detailname>\n" +
           "		<attribid>" + attribId + "</attribid>\n" +
           "		<attribname>" + attribName + "</attribname>\n" +
           "		<value>" + attribValue + "</value>\n" +
           "	</attribvalue>\n";
  }
}
