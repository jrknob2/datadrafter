package com.datadrafter.data;

public class AttributeHolder {
	String value;
	
	public AttributeHolder(String value) {		
	}
	
	public String getValue() {
		return value;
	}
}
