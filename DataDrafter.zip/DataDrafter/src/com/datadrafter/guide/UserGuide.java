package com.datadrafter.guide;

public class UserGuide {

	String title = null;
	String menu = null;
	String form = null;
	UserGuide previous_menu = null;
	UserGuide next_menu = null;
	
	public UserGuide() {
		
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getMenu() {
		return menu;
	}

	public void setMenu(String menu) {
		this.menu = menu;
	}

	public String getForm() {
		return form;
	}

	public void setForm(String form) {
		this.form = form;
	}

	public UserGuide getPrevious_menu() {
		return previous_menu;
	}

	public void setPrevious_menu(UserGuide previous_menu) {
		this.previous_menu = previous_menu;
	}

	public UserGuide getNext_menu() {
		return next_menu;
	}

	public void setNext_menu(UserGuide next_menu) {
		this.next_menu = next_menu;
	}
}
