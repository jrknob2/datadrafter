package com.datadrafter.guide;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.util.Hashtable;

import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.Document;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.StyleSheet;

import com.datadrafter.events.ObjectAction;

public class UserGuides extends JPanel {
	
	static Hashtable menus = new Hashtable();
	static String    css     = null;

	public UserGuides() {
		
		setLayout(new FlowLayout());
		//setPreferredSize(new Dimension(400, 400));
		
		String bgcolor = Integer.toHexString(getBackground().getRGB() & 0x00ffffff);
		css = "<style type=\"text/css\">" +
					"body {background-color:#" + bgcolor + "margin: 4px; }" +
			        "a { color:\"#00749E\"; font-family:\"Tahoma\", serifSansSerifMonospace; text-decoration:none; }" +
			        "h3 { color:\"#555555\"; font-family:\"Tahoma\", serifSansSerifMonospace; text-decoration:none; }" +
			        "</style>";
		
		String padding = "&nbsp;&nbsp;&nbsp;";

		setOpaque(true);
		setBorder(null);
      
		String m0 = "<html><body>" +
					"<h3>" + padding + "Guide Menu</h3>" +
					"<a href=\"search\">"    + padding + "Search</a><br>" +
					"<a href=\"browse\">"    + padding + "Browse</a><br>" +
					"<a href=\"http://m2\">" + padding + "Add Item</a><br>" +
      			    "<a href=\"http://m3\">" + padding + "Add/Edit Item Type</a><br>" +
      			    "<a href=\"http://m4\">" + padding + "Manage Data Models</a><br>" +
      			    "<a href=\"http://m5\">" + padding + "Manage Graphics Library</a><br>" +
      			    "<a href=\"http://m5\">" + padding + "Manage Reports</a><br><br><br>" +
      			    "<a href=\"http://m6\">" + padding + "Help and Documentation</a><br>" +
      			    "</body></html";
 	  

		String m1 = "<html><body>" +
					"<h3>" + padding + "Manage Projects</h3>" +
					"<a href=\"selectProject\">" + padding + "Open Project</a><br>" +
					"<a href=\"CreatProject\">"  + padding + "Create Project</a><br>" +
					"<a href=\"DeleteProject\">" + padding + "Delete Project</a><br>" +
					"<a href=\"SearchProject\">" + padding + "Search Project for Items</a><br><br>" +
					"<a href=\"http://m0\">" + padding + "Top Menu</a>" +					
					"</body></html>";
					

		String m2 = "<html><body>" +
		"<h3>" + padding + "Search Items</h3>" +
		"<a href=\"openProject\">" + padding +  "Open Project</a><br>" +
		"<a href=\"newProject\">"  + padding +  "New Project</a><br>" +
		"<a href=\"searchProject\">" + padding + "Search</a><br><br><hr>" +
		"<a href=\"http://m0\">" + padding + "Top Menu</a>" +					
		"</body></html>";
		
		String m3 = "<html><body>" +
					"<a href=\"http://java.sun.com\">" + padding + "Create New Template</a><br>" +
					"<a href=\"http://java.sun.com\">" + padding + "Create New Template</a><br>" +
		   		  	"<a href=\"http://m1\">" + padding + "Create New LOV</a><br>" +
		   		  	"<a href=\"http://m1\">" + padding + "Edit Template</a><br>" +
		   		  	"<a href=\"http://m1\">" + padding + "Manage Graphics</a><br><hr><br>" +
		   		  	"<a href=\"http://m1\">" + padding + "Back Up</a><br>" +
		   		  	"<a href=\"http://m1\">" + padding + "Go To Top</a>" +
		   		  	"</body></html>";

		menus.put("http://m0", m0);
		menus.put("http://m1", m1);
      
		JEditorPane editorPane = null;
   	  	editorPane = new JEditorPane();
   	  	editorPane.setEditable(false); 	  	
   	  	editorPane.setOpaque(false);
   	  	editorPane.setBorder(null);
   	  	editorPane.addHyperlinkListener(new MyHyperlinkListener());
      
   	  	HTMLEditorKit kit = new HTMLEditorKit();
   	  	editorPane.setEditorKit(kit);
   	  	StyleSheet styleSheet = kit.getStyleSheet();
   	  	styleSheet.addRule("a:hover {color:#000000;}");
   	  	Document doc = kit.createDefaultDocument();
   	  	editorPane.setDocument(doc);
  	  
   	  	editorPane.setText(css + m0);
   	  	add(editorPane);
   	  	
   	  	//this.setVisible(true);
	}
   
	private static class VerticalMenuBar extends JMenuBar {
	   private final static LayoutManager grid = new GridLayout(0,1);
	   public VerticalMenuBar() {
	     setLayout(grid);
	   }
	}
   
	private static class MyHyperlinkListener implements HyperlinkListener {
	    public void hyperlinkUpdate(HyperlinkEvent evt) {
	        if (evt.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
	            JEditorPane pane = (JEditorPane)evt.getSource();
	            //try {
	            	System.out.println("evt.getURL()-> " + evt.getURL());
	            	if (evt.getURL() != null) {
						pane.setText((String)menus.get(evt.getURL().toString()));
		            	return;
		            } else {
		            	//System.out.println("evt.getDescription()-> " + evt.getDescription());
		            	if (evt.getDescription().equals("browse")) {
		        	        ObjectAction.fireObjectActionEvent(evt.getSource(), null, ObjectAction.MENU_BROWSE);
		        	        return;
		            	}
		            	if (evt.getDescription().equals("search")) {
		        	        ObjectAction.fireObjectActionEvent(evt.getSource(), null, ObjectAction.MENU_SEARCH);
		        	        return;
		            	} 		            	
	            	}
	            	
//	            	if (new_menu == null) {
//	            		pane.setText(css + new_menu);
	        }
	    }
	}
	
	static public void main(String[] args) {
		UserGuides ug = new UserGuides();
		JFrame f = new JFrame("Track My Stuff");
		f.getContentPane().add(ug);
   	  	f.setLayout(new FlowLayout());
   	  	f.setVisible(true);
	}
   
}
