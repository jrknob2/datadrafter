package com.datadrafter.tables;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTable;

import com.datadrafter.modeler.Detail;
import com.datadrafter.modeler.Template;
import com.datadrafter.modeler.Templates;
import com.datadrafter.utils.Utils;
import com.datadrafter.xcad.CadShape;
import com.datadrafter.xcad.CadView;

public class DropListEditor extends DefaultCellEditor implements ActionListener {
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		Object currentValue = null;
		Object currentObject = null;
		String currentLabel = "";
		String noneSelection = "None";
	    JComboBox cb = null;
	    
  public DropListEditor(JButton b) {
    super(new JComboBox()); //Unfortunately, the constructor
    //expects a check box, combo box,
    //or text field.
    editorComponent = b;
    setClickCountToStart(1); //This is usually 1 or 2.
    //Must do this so that editing stops when appropriate.
  }

  protected void fireEditingStopped(ActionEvent e) {
    JComboBox cb = (JComboBox) e.getSource();
    currentValue = cb.getSelectedItem();
    cb.removeItem(noneSelection);
    super.fireEditingStopped();
  }

  public void setCurrentLabel(String label) {
	currentLabel = label; 
  }
  public void setCurrentObject(Object obj) {
	currentObject = obj; 
  }
  public Object getCellEditorValue() {
    return currentValue;
  }
  public void setCurrentValue(Object value) {
  	currentValue = value;
  }
  public Component getTableCellEditorComponent(JTable table,
                                               Object value,
                                               boolean isSelected,
                                               int row,
                                               int column) {
    ((JButton) editorComponent).setText(value.toString());
    
    String label = (String) table.getValueAt(row, 0);
    Object curval = table.getValueAt(row, column);
    
    if (label.equals("Command")) {
      cb = new JComboBox(CadView.validCommands.toArray());
    }
    else if (label.equals("Template")) {
      cb = new JComboBox(Templates.getTemplates());
      cb.addItem(noneSelection);
    }
//    else if (label.equals("View Name")) {
//      CadView view = (CadView) currentObject;
//      CadDrawing drawing = view.getDrawing();
//      cb = new JComboBox(drawing.getSavedViews());
//  	  cb.addItem(noneSelection);
//    }
    else if (label.equals("Default Line Style")) {
      cb = new JComboBox(CadShape.lineStyles);
    }
    else if (label.equals("Line Style")) {
        cb = new JComboBox(CadShape.lineStyles);
    }
    else if (label.equals("Detail")) {
    	Template template = (Template)table.getValueAt(row-1, 1);
    	cb = new JComboBox(template.getDetails());
    	cb.addItem(noneSelection);
    }
    else if (label.equals("Attribute")) {
    	Detail detail = (Detail)table.getValueAt(row-1, 1);
    	cb = new JComboBox(detail.getAttributes());
    	cb.addItem(noneSelection);
    }
    else if (label.equals("Fill")) {
      cb = new JComboBox(CadShape.fillStyles);
    }
//    else if (label.equals("Layer")) {
//      if (currentObject instanceof CadShape) {
//        cb = new JComboBox( ( (CadShape) currentObject).getLayer().getDrawing().
//                           getLayers());
//      }
//    }
    else if (label.equals("Active Layer")) {
      CadView view = (CadView) currentObject;
      cb = new JComboBox(view.getDrawing().getLayers().toArray());
    }
    else if (label.equals("Closure")) {
      cb = new JComboBox(CadShape.arcClosures);
    } 
    else if (label.equals("Font Name")) {
      cb = new JComboBox(Utils.getSystemFonts());
    } 

    for (int i = 0; i < cb.getItemCount(); i++) {
    	Object val = cb.getItemAt(i);
    	if (val.equals(curval)) {
    		cb.setSelectedIndex(i);
    		break;
    	}
    }

    cb.addActionListener(this);

    return cb;
    
  }
  
  public void actionPerformed(ActionEvent e) {
       fireEditingStopped(e);
  }
}
