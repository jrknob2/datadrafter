package com.datadrafter.tables;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JTable;

import com.datadrafter.xcad.CadLayer;

public class CheckBoxEditor extends DefaultCellEditor {
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
Object currentValue = null;
  Object currentObject = null;
  String currentLabel = "";

  public CheckBoxEditor(JButton b) {
    super(new JCheckBox()); //Unfortunately, the constructor
    //expects a check box, combo box,
    //or text field.
    editorComponent = b;
    setClickCountToStart(1); //This is usually 1 or 2.
    //Must do this so that editing stops when appropriate.
  }

  protected void fireEditingStopped(ActionEvent e) {
    JCheckBox cb = (JCheckBox) e.getSource();
    CadLayer layer = (CadLayer) currentValue;
    if (currentLabel.equals("Layer On/Off")) { 
    	layer.setVisible(cb.isSelected());
    }
    if (currentLabel.equals("Selectable")) { 
    	layer.setSelectable(cb.isSelected());
    }
    super.fireEditingStopped();
  }

  public void setCurrentLabel(String label) {
  	currentLabel = label; 
  }
  public Object getCellEditorValue() {return currentValue;}
  public Object getCurrentLabel() {return currentLabel;}

  public Component getTableCellEditorComponent(JTable table,
                                               Object value,
                                               boolean isSelected,
                                               int row,
                                               int column) {
    JCheckBox cb = null;
//      ((JButton)editorComponent).setText(value.toString());
    currentValue = value;
    String label = (String) table.getValueAt(row, 0);
    if (label.equals("Layer On/Off")) {
      CadLayer layer = (CadLayer) value;
      cb = new JCheckBox(layer.getName(), layer.isVisible());
    }
    if (label.equals("Selectable")) {
    	System.out.println();
        CadLayer layer = (CadLayer) value;
        cb = new JCheckBox(layer.getName(), isSelected);
      }
    
    cb.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        fireEditingStopped(e);
      }
    });
    return cb;
  }
}
