package com.datadrafter.tables;

import javax.swing.table.AbstractTableModel;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class EditorTableModel extends AbstractTableModel {
 
	private static final long serialVersionUID = 1L;
	String[] columnNames = {"Attribute", "Value"};
	Object[][] data = new Object[0][0];

  public EditorTableModel() {
  }

  public void setToolTip(String tip) {
	  this.setToolTip(tip);
  }
  public void setDataObject(Object[][] data) {
    this.data = data;
    this.fireTableDataChanged();
  }

  public int getColumnCount() {
    return columnNames.length;
  }

  public int getRowCount() {
    return data.length;
  }

  public String getColumnName(int col) {
    return columnNames[col];
  }

  public Object getValueAt(int row, int col) {
    return data[row][col];
  }

  public Class getColumnClass(int c) {
    return getValueAt(0, c).getClass();
  }

  /*
   * Don't need to implement this method unless your table's
   * editable.
   */
  public boolean isCellEditable(int row, int col) {
    //Note that the data/cell address is constant,
    //no matter where the cell appears onscreen.
	  System.out.println("col-> " + col);
	if (col < 1) return false;
    return true;
  }

  /*
   * Don't need to implement this method unless your table's
   * data can change.
   */
  public void setValueAt(Object value, int row, int col) {
    data[row][col] = value;
    fireTableCellUpdated(row, col);
  }
}