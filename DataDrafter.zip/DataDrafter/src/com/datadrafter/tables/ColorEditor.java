package com.datadrafter.tables;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JTable;

public class ColorEditor extends DefaultCellEditor {
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
Color currentValue = null;

  public ColorEditor(JButton b) {
    super(new JCheckBox()); //Unfortunately, the constructor
    editorComponent = b;
    setClickCountToStart(1); //This is usually 1 or 2.
    editorSetup(b);
  }

  protected void fireEditingStopped() {
    super.fireEditingStopped();
  }

  public Object getCellEditorValue() {
    return currentValue;
  }
  public void setCurrentColor(Color color) {
  	currentValue = color;
  }

  public Component getTableCellEditorComponent(JTable table,
                                               Object value,
                                               boolean isSelected,
                                               int row,
                                               int column) {
    ( (JButton) editorComponent).setText(value.toString());
    currentValue = (Color) value;
    return editorComponent;
  }

  //Set up the editor for the Color cells.
  private void editorSetup(JButton b) {
  	b.setBackground(Color.WHITE);
  	b.setText("");
  	b.addActionListener(new ActionListener() {
  		public void actionPerformed(ActionEvent e) {
  			JColorChooser jcc = new JColorChooser();
			jcc.setColor(currentValue);
			jcc.setVisible(false);
			currentValue = jcc.getColor();
	        fireEditingStopped();
  		}
	});
}

}
