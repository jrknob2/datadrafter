package com.datadrafter.tables;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.GeneralPath;

import javax.swing.Icon;

import com.datadrafter.xcad.CadShape;

class GraphicsIcon
    implements Icon {
  int type;
  int color;
  int width;
  int style;

  public GraphicsIcon(int type, int color, int width, int style) {
    this.type = type;
    this.color = color;
    this.width = width;
    this.style = style;
  }

  public void paintIcon(Component c, Graphics g, int x, int y) {
    Graphics2D g2D = (Graphics2D) g;

    g2D.setStroke(CadShape.getStroke(style, width));
    g2D.setColor(new Color(color));
    GeneralPath p = new GeneralPath();
    p.moveTo(3, getIconHeight() / 2);
    p.lineTo(getIconWidth() - 2, getIconHeight() / 2);
    g2D.draw(p);
  }

  public int getIconWidth() {
    return 70;
  }

  public int getIconHeight() {
    return 20;
  }
}