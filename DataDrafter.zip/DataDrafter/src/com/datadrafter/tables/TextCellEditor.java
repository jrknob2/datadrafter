package com.datadrafter.tables;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JTable;
import javax.swing.JTextField;

public class TextCellEditor extends DefaultCellEditor {
  /**
	 * 
	 */
	private static final long serialVersionUID = -8654356079784010460L;
Object currentValue = null;

  public TextCellEditor(JButton b) {
    super(new JCheckBox()); //Unfortunately, the constructor
    //expects a check box, combo box,
    //or text field.
    editorComponent = b;
    setClickCountToStart(1); //This is usually 1 or 2.
    //Must do this so that editing stops when appropriate.
    b.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        fireEditingStopped();
      }
    });
  }

  protected void fireEditingStopped(ActionEvent e) {
    JTextField tf = (JTextField) e.getSource();
    if (currentValue instanceof Double) {
      currentValue = Double.valueOf(tf.getText());
    }
    else if (currentValue instanceof Long) {
      currentValue = Long.valueOf(tf.getText());
    }
    else if (currentValue instanceof Integer) {
      currentValue = Integer.valueOf(tf.getText());
    }
    else {
      currentValue = tf.getText();
    }
    super.fireEditingStopped();
  }

  public Object getCellEditorValue() {
    return currentValue;
  }

  public Component getTableCellEditorComponent(JTable table,
                                               Object value,
                                               boolean isSelected,
                                               int row,
                                               int column) {
//        ((JButton)editorComponent).setText(value.toString());
    currentValue = value;
//        return editorComponent;
    JTextField tf = new JTextField(currentValue.toString());
    tf.setHorizontalAlignment(JTextField.LEFT);
    tf.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        fireEditingStopped(e);
      }
    });
    return tf;
  }
}
