package com.datadrafter.tables;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JDialog;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import com.datadrafter.xcad.CadArc;
import com.datadrafter.xcad.CadDrawing;
import com.datadrafter.xcad.CadFigure;
import com.datadrafter.xcad.CadLine;
import com.datadrafter.xcad.CadPolyLine;
import com.datadrafter.xcad.CadPolygon;
import com.datadrafter.xcad.CadRectangle;
import com.datadrafter.xcad.CadLabel;
import com.datadrafter.data.AttributeValue;
import com.datadrafter.data.AttributeValues;
import com.datadrafter.links.DataLink;
import com.datadrafter.links.LinkGroup;
import com.datadrafter.links.LinkManagerPreferences;
import com.datadrafter.links.SearchCriteria;
import com.datadrafter.modeler.Attrib;
import com.datadrafter.modeler.Detail;
import com.datadrafter.modeler.Template;
import com.datadrafter.xcad.CadLayer;
import com.datadrafter.xcad.CadView;

public class PropTable extends JTable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Object curr_obj = null;
	PropTableModel model = null;
	BoldTextCellRenderer btcr = new BoldTextCellRenderer();
	String[] columns = null;
	FileChooserEditor fileChooserEditor = null;

	public PropTable(String[] columns) {
		super();
		this.columns = columns;
		Object[][] data = new Object[0][0];
		model = new PropTableModel(data, columns);
		super.setModel(model);
//		TableColumn column = getColumnModel().getColumn(0);
//		column.setPreferredWidth(50);
		//this.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);		
	}

	public Object[][] getDataObject() {
		return model.getDataObject();
	}
	public void setColumns(String[] columns) {
		this.columns = columns;
		super.setModel(model);
	}

	public TableCellEditor getCellEditor(int row, int col) {
		String label = null;
		Object obj = getValueAt(row, col);
		Object leftObj = getValueAt(row, 0);

		if (leftObj instanceof AttributeValue) {
			TextCellEditor editor = new TextCellEditor(new JButton());
			return editor;
		} else if (leftObj instanceof String) {
			label = (String) leftObj;
		}
		if (obj instanceof Color) {
			return setUpColorEditor(this);
		} else if (obj instanceof Boolean) {
			TableCellEditor tce = getDefaultEditor(getCellClass(row, col));
			return getDefaultEditor(getCellClass(row, col));
		} else if (obj instanceof CadLayer && label.equals("Layer On/Off")) {
			CheckBoxEditor cbe = (CheckBoxEditor) setUpCheckBoxEditor(this);
			cbe.currentLabel = label;
			return cbe;
		} else if (obj instanceof CadLayer && label.equals("Selectable")) {
			CheckBoxEditor cbe = (CheckBoxEditor) setUpCheckBoxEditor(this);
			cbe.currentLabel = label;
			return cbe;
		} else {
			if (label.equals("Command") || label.equals("Layers")
					|| label.equals("Saved View") || label.equals("View Name")
					|| label.equals("Fill") || label.equals("Active Layer")
					|| label.equals("Default Line Style") || label.equals("Closure")
					|| label.equals("Layer") || label.equals("Font Name")
					|| label.equals("Saved View") || label.equals("Line Style")) {
				DropListEditor dleditor = (DropListEditor) setUpDropListEditor(this);
				dleditor.currentLabel = label;
				return (TableCellEditor) dleditor;
			} else if (label.equals("Template") || label.equals("Detail")
					|| label.equals("Attribute")) {
				DropListEditor dleditor = (DropListEditor) setUpDropListEditor(this);
				dleditor.currentLabel = label;
				return (TableCellEditor) dleditor;
			} else if (label.equals("Background Image")) {
				FileChooserEditor fce = new FileChooserEditor(new JButton(""));
				fce.currentValue = label;
				return fce;
			} else if (label.equals("Drawing ID")) {
				DrawingChooserEditor fce = new DrawingChooserEditor(new JButton(""));
				fce.currentValue = label;
				return fce;
			}
			
			TextCellEditor editor = new TextCellEditor(new JButton());
			return editor;
		}
	}

	public TableCellRenderer getCellRenderer(int row, int col) {
		if (col == 0) {
			return btcr;
		}

		Object obj = getValueAt(row, col);
		Object first = getValueAt(row, 0);
		String label = (first instanceof String) ? (String) first : null;

		if (obj instanceof Color) {
			return new ColorRenderer(true);
		} else if (obj instanceof String) {
			return new TextCellRenderer((String) obj);
		} else if (obj instanceof Integer) {
			return new TextCellRenderer(((Integer) obj).toString());
		} else if (obj instanceof Long) {
			return new TextCellRenderer(((Long) obj).toString());
		} else if (obj instanceof Double) {
			return new TextCellRenderer(((Double) obj).toString());
		} else if (obj instanceof CadLayer && label.equals("Layer On/Off")) {
			CadLayer layer = (CadLayer) obj;
			return new CheckBoxRenderer(layer.getName(), layer.isVisible());
		} else if (obj instanceof CadLayer && label.equals("Selectable")) {
			CadLayer layer = (CadLayer) obj;
			return new CheckBoxRenderer(layer.getName(), layer.isSelectable());
		} else if (obj instanceof CadDrawing) {
			//CadDrawing drwg = (CadDrawing) obj;
			return new CadAreaRenderer();
		} else {
			TableCellRenderer defrend = getDefaultRenderer(getCellClass(row, col));
//			System.out.println("obj-> " + obj.getClass());
//			System.out.println("defrend-> " + defrend.getClass());
			return defrend;
		}
	}

	public Class getCellClass(int row, int col) {
		return getValueAt(row, col).getClass();
	}

	public void setCurrentObject(Object obj) {
		this.curr_obj = obj;
	}

	public Object getCurrentObject() {
		return curr_obj;
	}

	public void setDataObject(Object[][] data) {
		
		model.setDataObject(data);
		model.fireTableDataChanged();
	}
	
	//Set up the editor for the Color cells.
	  private TableCellEditor setUpColorEditor(JTable table) {
	    //First, set up the button that brings up the dialog.
	    final JButton button = new JButton("") {
	      /**
			 * 
			 */
			private static final long serialVersionUID = 1L;

		public void setText(String s) {
	        //Button never shows text -- only color.
	      }
	    };
//	      button.setBackground(Color.white);
//	      button.setBorderPainted(false);
//	      button.setMargin(new Insets(0,0,0,0));

	    //Now create an editor to encapsulate the button, and
	    //set it up as the editor for all Color cells.
	    final ColorEditor colorEditor = new ColorEditor(button);

	    //Set up the dialog that the button brings up.
	    final JColorChooser colorChooser = new JColorChooser();
	    ActionListener okListener = new ActionListener() {
	      public void actionPerformed(ActionEvent e) {
	        colorEditor.setCurrentColor(colorChooser.getColor());
	      }
	    };
	    final JDialog dialog = JColorChooser.createDialog(button,
	        "Pick a Color",
	        true,
	        colorChooser,
	        okListener,
	        null); //XXXDoublecheck this is OK

	    //Here's the code that brings up the dialog.
	    button.addActionListener(new ActionListener() {
	      public void actionPerformed(ActionEvent e) {
	        button.setBackground((Color)colorEditor.getCellEditorValue());
	        colorChooser.setColor((Color)colorEditor.getCellEditorValue());
	        //Without the following line, the dialog comes up
	        //in the middle of the screen.
	        //dialog.setLocationRelativeTo(button);
	        dialog.setVisible(true);
	      }
	    });
	    return colorEditor;
	  }

	private TableCellEditor setUpCheckBoxEditor(JTable table) {
		//First, set up the button that brings up the dialog.
		final JButton button = new JButton("") {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public void setText(String s) {
				//Button never shows text -- only color.
			}
		};
		//      button.setBackground(Color.white);
		//      button.setBorderPainted(false);
		//      button.setMargin(new Insets(0,0,0,0));

		//Now create an editor to encapsulate the button, and
		//set it up as the editor for all Color cells.
		final CheckBoxEditor checkboxEditor = new CheckBoxEditor(button);

		//Here's the code that brings up the dialog.
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		return checkboxEditor;
	}

	private TableCellEditor setUpDropListEditor(JTable table) {
		//First, set up the button that brings up the dialog.
		final JButton button = new JButton("") {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public void setText(String s) {
				//Button never shows text -- only color.
			}
		};
		//      button.setBackground(Color.white);
		//      button.setBorderPainted(false);
		//      button.setMargin(new Insets(0,0,0,0));

		//Now create an editor to encapsulate the button, and
		//set it up as the editor for all Color cells.
		final DropListEditor dropListEditor = new DropListEditor(button);
		dropListEditor.currentObject = curr_obj;
		//Set up the dialog that the button brings up.
		//final JComboBox combox = new JComboBox();
//		ActionListener okListener = new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				dropListEditor.currentValue = combox.getSelectedItem();
//			}
//		};
		return dropListEditor;
	}

	public class PropTableModel extends AbstractTableModel {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		String[] columns = null;
		Object[][] data = new Object[0][0];

		public PropTableModel(Object[][] data, String[] columns) {
			this.columns = columns;
			this.data = data;
		}

		public int getColumnCount() {
			return columns.length;
		}

		public int getRowCount() {
			return data.length;
		}

		public String getColumnName(int col) {
			return columns[col];
		}

		public Object getValueAt(int row, int col) {
			return data[row][col];
		}

		/*
		 * JTable uses this method to determine the default renderer/ editor for
		 * each cell. If we didn't implement this method, then the last column
		 * would contain text ("true"/"false"), rather than a check box.
		 */
		public Class getColumnClass(int c) {
			return getValueAt(0, c).getClass();
		}

		/*
		 * Don't need to implement this method unless your table's editable.
		 */
		public boolean isCellEditable(int row, int col) {
			//Note that the data/cell address is constant,
			//no matter where the cell appears onscreen.
			if (col < 1) return false;
			
			// disable the table cells that have derived values
			Object obj = getValueAt(row, col-1);
			
			//System.out.println("class-> " + obj.getClass());
			
			if (obj instanceof java.lang.String) {
				if (((String)obj).equals("ID")) return false;
				if (((String)obj).equals("Id")) return false;
				if (((String)obj).equals("Version")) return false;
				if (((String)obj).equals("Clean")) return false;
				if (((String)obj).equals("Element Count")) return false;
				if (((String)obj).equals("Saved Views")) return false;
				if (((String)obj).equals("Max X")) return false;
				if (((String)obj).equals("Max Y")) return false;
				if (((String)obj).equals("Min X")) return false;
				if (((String)obj).equals("Min Y")) return false;
				if (((String)obj).equals("Vector Count")) return false;
				if (((String)obj).equals("Area")) return false;
				if (((String)obj).equals("Element Type")) return false;
				if (((String)obj).equals("Link Type")) return false;
				if (((String)obj).equals("Group Id")) return false;
				if (((String)obj).equals("Child Links")) return false;
				if (((String)obj).equals("Link Count")) return false;
				if (((String)obj).equals("Used In Detail")) return false;
				if (((String)obj).equals("Used In Template")) return false;
				if (((String)obj).equals("Elem ID")) return false;
				if (((String)obj).equals("Element Id")) return false;
				if (((String)obj).equals("Drawing Id")) return false;
				if (((String)obj).equals("Start Point")) return false;
				if (((String)obj).equals("End Point")) return false;
				if (((String)obj).equals("Length")) return false;
				if (((String)obj).equals("Corner")) return false;
				if (((String)obj).equals("Parent Link Id")) return false;
				if (((String)obj).equals("Preview")) return false;
				if (((String)obj).equals("Center")) return false;
				
//				Template template = Templates.getDetailTemplate(((String)obj).toString());
//				if (template != null) return false;

			}
			
			return true;
		}

		public void setDataObject(Object[][] data) {
			this.data = data;
		}

		public Object[][] getDataObject() {
			return this.data;
		}
		
		public void setValueAt(Object value, int row, int col) {
			if (value == null) return;
			
			boolean clean = true;
			data[row][col] = value;

			if (curr_obj instanceof CadPolygon) {
				CadPolygon poly = (CadPolygon) curr_obj;
				poly.setDataField((String) getValueAt(row, 0), value);
			} else if (curr_obj instanceof CadLine) {
				CadLine line = (CadLine) curr_obj;
				line.setDataField((String) getValueAt(row, 0), value);
			} else if (curr_obj instanceof CadPolyLine) {
				CadPolyLine lineseg = (CadPolyLine) curr_obj;
				lineseg.setDataField((String) getValueAt(row, 0), value);
			} else if (curr_obj instanceof CadArc) {
				CadArc arc = (CadArc) curr_obj;
				arc.setDataField((String) getValueAt(row, 0), value);
			} else if (curr_obj instanceof CadRectangle) {
				CadRectangle rect = (CadRectangle) curr_obj;
				rect.setDataField((String) getValueAt(row, 0), value);
			} else if (curr_obj instanceof CadView) {
				CadView view = (CadView) curr_obj;
				view.setDataField((String) getValueAt(row, 0), value);
			} else if (curr_obj instanceof CadDrawing) {
				CadDrawing drawing = (CadDrawing) curr_obj;
				drawing.setDataField((String) getValueAt(row, 0), value);
			} else if (curr_obj instanceof CadLabel) {
				CadLabel symb = (CadLabel) curr_obj;
				symb.setDataField((String) getValueAt(row, 0), value);
			} else if (curr_obj instanceof DataLink) {
				DataLink link = (DataLink) curr_obj;
				clean = link.setDataField((String) getValueAt(row, 0), value);
				if (clean == false) {
					//ObjectAction.fireObjectActionEvent(this, link,
						//	ObjectAction.OBJ_MODIFIED);

					/***********************************************************
					 *  
					 */

				}
			} else if (curr_obj instanceof Template) {
				Template template = (Template) curr_obj;
				template.setDataField(getValueAt(row, 0), value);
				clean = template.setDataField(getValueAt(row, 0), value);
				if (clean == false) {
					//ObjectAction.fireObjectActionEvent(this, template,
						//	ObjectAction.OBJ_MODIFIED);

					/***********************************************************
					 *  
					 */

				}
			} else if (curr_obj instanceof Attrib) {
				Attrib attrib = (Attrib) curr_obj;
				clean = attrib.setDataField((String) getValueAt(row, 0), value);
				if (clean == false) {
					//ObjectAction.fireObjectActionEvent(this, attrib,
						//	ObjectAction.OBJ_MODIFIED);

					/***********************************************************
					 *  
					 */

				}
			} else if (curr_obj instanceof Detail) {
				Detail detail = (Detail) curr_obj;
				clean = detail.setDataField(getValueAt(row, 0), value);
				//Object obj = this.getValueAt(row + 1, 1);
				if (clean == false) {
					//ObjectAction.fireObjectActionEvent(this, detail,
						//	ObjectAction.OBJ_MODIFIED);
				}
			} else if (curr_obj instanceof LinkGroup) {
				LinkGroup group = (LinkGroup) curr_obj;
				clean = group.setDataField((String) getValueAt(row, 0), value);
				if (clean == false) {
					//ObjectAction.fireObjectActionEvent(this, group,
						//	ObjectAction.OBJ_MODIFIED);

				}
			} else if (curr_obj instanceof CadFigure) {
				CadFigure item = (CadFigure) curr_obj;
				item.setDataField((String) getValueAt(row, 0), value);
			} else if (curr_obj instanceof CadLayer) {
				CadLayer item = (CadLayer) curr_obj;
				item.setDataField((String) getValueAt(row, 0), value);
			} else if (curr_obj instanceof AttributeValues) {
				AttributeValues values = (AttributeValues) curr_obj;
				AttributeValue aValue = (AttributeValue) data[row][0];
				aValue.setValue((String) value);
				if (aValue.getClean() == false)
					values.getModified().add(aValue);
			} else if (curr_obj instanceof SearchCriteria) {
				SearchCriteria criters = (SearchCriteria) curr_obj;
				String label = (String) getValueAt(row, 0);
				criters.setDataField(label, value);
				if (label.equals("Template")) {
					// reset detail and attribute values
					setValueAt("None", row + 1, col);
					setValueAt("None", row + 2, col);
				}
				if (label.equals("Detail"))
					setValueAt("None", row + 1, col);
			} else if (curr_obj instanceof LinkManagerPreferences) {
				LinkManagerPreferences prefs = (LinkManagerPreferences) curr_obj;
				prefs.setDataField((String) getValueAt(row, 0), value);
			}
			fireTableCellUpdated(row, col);
		}
	}
}