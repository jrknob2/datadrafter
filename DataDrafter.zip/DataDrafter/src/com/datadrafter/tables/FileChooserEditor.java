package com.datadrafter.tables;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JTable;

public class FileChooserEditor extends DefaultCellEditor {
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		String currentValue = null;
		String currentDirectory = "./drawings";
	public FileChooserEditor(JButton b) {
		super(new JCheckBox()); //Unfortunately, the constructor
		//expects a check box, combo box,
		//or text field.
		editorComponent = b;
		setClickCountToStart(1); //This is usually 1 or 2.
		editorSetup(b);
		//Must do this so that editing stops when appropriate.
	}

  protected void fireEditingStopped() {
    super.fireEditingStopped();
  }

  public Object getCellEditorValue() {
    return currentValue;
  }
  public void setCurrentColor(String value) {
  	currentValue = value;
  }

  public Component getTableCellEditorComponent(JTable table,
                                               Object value,
                                               boolean isSelected,
                                               int row,
                                               int column) {
	  System.out.println("column-> " + column);
	  String lbl = (String)table.getValueAt(row, column - 1);
	  if (lbl.equals("Background Image")) currentDirectory = "./images";
	  currentValue = value.toString();
	  return editorComponent;
  }

  public void editorSetup(JButton b) {
    //Here's the code that brings up the dialog.
    b.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
      	JFileChooser chooser = new JFileChooser();
      	chooser.setCurrentDirectory(new File("./images"));
      	chooser.setSelectedFile(new File(currentValue));
      	int b = chooser.showOpenDialog(editorComponent);
      	if (b == 1) {
      		currentValue = "";
      	} else {
      		currentValue = chooser.getSelectedFile().getName();
      	}
        fireEditingStopped();
      }
    });
  }
}
