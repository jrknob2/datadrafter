package com.datadrafter.tables;

import java.awt.Component;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

public class TextCellRenderer
    extends JLabel
    implements TableCellRenderer {
  /**
	 * 
	 */
	private static final long serialVersionUID = 8935464198545150382L;

public TextCellRenderer(String value) {
    super(value);
  }

  public Component getTableCellRendererComponent(JTable table,
                                                 Object color,
                                                 boolean isSelected,
                                                 boolean hasFocus,
                                                 int row,
                                                 int column) {
    this.setHorizontalAlignment(JLabel.LEFT);
    this.setBorder(BorderFactory.createEmptyBorder());
    return this;
  }
}
