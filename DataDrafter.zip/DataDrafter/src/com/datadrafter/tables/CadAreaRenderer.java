package com.datadrafter.tables;

import java.awt.Component;
import java.awt.Image;

import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

import com.datadrafter.xcad.CadDrawing;
import com.datadrafter.xcad.CadView;

public class CadAreaRenderer
    extends DefaultTableCellRenderer {
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public Component getTableCellRendererComponent
      (JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
    int col_width = table.getColumnModel().getColumn(1).getWidth();
    int col_height = table.getRowHeight(row);
    if (col_width != col_height) table.setRowHeight(row, col_width);
    CadView view = new CadView((CadDrawing)value);
    view.setSize(col_width, col_width);
    if (view.getDrawing().getElementCount() > 0) {
    	double drawing_width = view.getDrawing().getMaxX() + 5;
    	double drawing_height = view.getDrawing().getMaxY() + 5;
    	double scale_adj = drawing_width > drawing_height ? drawing_width : drawing_height;
    	double scale = col_width/scale_adj;
    	//System.out.println("preview scale-> " + scale);
    	view.setScale(scale);
    } else {
  		if (view.getDrawing().getBackgroundImage().length() > 0) {
  			Image image  = new javax.swing.ImageIcon("./images/" + view.getDrawing().getBackgroundImage()).getImage(); 
  	    	double drawing_width = image.getWidth(null);
  	    	double drawing_height = image.getHeight(null);
  	    	double scale_adj = drawing_width > drawing_height ? drawing_width : drawing_height;
  	    	double scale = col_width/scale_adj;
  	    	view.setScale(scale);
  		} else {
  			view.setScale(1.0);
  		}
    }
    view.redraw();
    return view;
  }
}
