/*
 * Created on Feb 16, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

package com.datadrafter.tables;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;

import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class LightGrayCellRenderer
	extends DefaultTableCellRenderer {
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public Component getTableCellRendererComponent
	  (JTable table, Object value, boolean isSelected,
	   boolean hasFocus, int row, int column) {
	Component cell = super.getTableCellRendererComponent
		(table, value, isSelected, hasFocus, row, column);
	//Font font = cell.getFont();
	cell.setFont(new Font(cell.getFont().getName(), Font.BOLD, 11));
	cell.setForeground(Color.black);
	cell.setBackground(Color.gray);
	return cell;

  }
}
