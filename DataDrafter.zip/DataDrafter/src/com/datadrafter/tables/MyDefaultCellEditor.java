package com.datadrafter.tables;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Font;

import javax.swing.DefaultCellEditor;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

public class MyDefaultCellEditor extends JFrame {
  DefaultTableModel model = new DefaultTableModel(
		  new Object[][] { 
				  { "some", false},
				  { "any", true }, 
				  { "even", false }, 
				  { "text", true }, 
				  { "and", true },
				  { "text", false } }, 
		  new Object[] { "Column 1", "Column 2" });

  public MyDefaultCellEditor() {
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JTable table = new JTable(model);
    table.setDefaultEditor(Object.class, new MyEditor());
    getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);
    pack();
  }

  public static void main(String arg[]) {
    new MyDefaultCellEditor().setVisible(true);
  }
}

class MyEditor extends DefaultCellEditor {
  public MyEditor() {
    super(new JTextField());
  }

  public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected,
      int row, int column) {
    
	  if (column == 1) {
		  JCheckBox editor = (JCheckBox) super.getTableCellEditorComponent(table, value, isSelected, row, column);
	      editor.setHorizontalAlignment(SwingConstants.LEFT);
	      editor.setSelected(Boolean.getBoolean(value.toString()));
	      return editor;
	  }
	  
	  JTextField editor = new JTextField();
	  if (value != null)
		  editor.setText(value.toString());
      editor.setHorizontalAlignment(SwingConstants.CENTER);
      editor.setFont(new Font("Serif", Font.BOLD, 14));

      return editor;
  }
}