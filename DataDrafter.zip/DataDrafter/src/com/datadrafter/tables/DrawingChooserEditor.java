package com.datadrafter.tables;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JTable;

import com.datadrafter.gui.dialogs.ImagePreview;
import com.datadrafter.utils.ExampleFileFilter;
import com.datadrafter.utils.Utils;

	public class DrawingChooserEditor extends DefaultCellEditor {

		private static final long serialVersionUID = 1L;
		String currentValue = null;

	public DrawingChooserEditor(JButton b) {
		super(new JCheckBox()); //Unfortunately, the constructor
		//expects a check box, combo box,
		//or text field.
		editorComponent = b;
		setClickCountToStart(1); //This is usually 1 or 2.
		editorSetup(b);
		//Must do this so th
	}
	
	protected void fireEditingStopped() {
		super.fireEditingStopped();
	}

	public Object getCellEditorValue() {
		return currentValue;
	}

  public Component getTableCellEditorComponent(JTable table,
                                               Object value,
                                               boolean isSelected,
                                               int row,
                                               int column) {
//    ((JButton) editorComponent).setText(value.toString());
//    System.out.println("value-> " + value.getClass());
    currentValue = value.toString();
    return editorComponent;
  }

  public void editorSetup(JButton b) {
    //Here's the code that brings up the dialog.
    b.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
      	JFileChooser chooser = new JFileChooser();
		chooser.setAccessory(new ImagePreview(chooser));
		ExampleFileFilter filter = new ExampleFileFilter();
		filter.addExtension("CAD");
		filter.addExtension("XML");
		chooser.setCurrentDirectory(new File("./drawings"));
		chooser.setFileFilter(filter);
		Utils.centerDialog(chooser);      	
		chooser.setSelectedFile(new File(currentValue));
      	int b = chooser.showOpenDialog(editorComponent);
      	if (b == 1) {
      		currentValue = "-1";
      	} else {
      		currentValue = chooser.getSelectedFile().getName();
      	}
        fireEditingStopped();
      }
    });
  }
}
