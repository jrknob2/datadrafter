package com.datadrafter.tables;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JScrollPane;
import javax.swing.JTable;

import com.datadrafter.utils.Utils;

/**
 * This is like TableEditDemo, except that it substitutes a
 * Favorite Color column for the Last Name column and specifies
 * a custom cell renderer and editor for the color data.
 */
public class TableEditor extends JScrollPane {
  /**
	 * 
	 */
	private static final long serialVersionUID = -4473222787475616527L;
	private PropTable table = null;

	public TableEditor(String[] columns) {
		table = new PropTable(columns);
		table.setPreferredScrollableViewportSize(new Dimension(10, 10));
		this.getViewport().add(table, BorderLayout.CENTER);
	}

	public PropTable getTable() {
		return table;
	}

  public Object getCurrentObject() {
    return table.getCurrentObject();
  }

  public void setDataObject(Object obj, Object[][] data) {
    table.setCurrentObject(obj);
    table.setDataObject(data);
    Utils.resizeColumns((JTable) table);
  }
}
