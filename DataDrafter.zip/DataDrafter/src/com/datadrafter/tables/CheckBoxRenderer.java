package com.datadrafter.tables;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JCheckBox;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.TableCellRenderer;

import com.datadrafter.xcad.CadLayer;

public class CheckBoxRenderer extends JCheckBox implements TableCellRenderer {
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public CheckBoxRenderer(String value, boolean selected) {
    super(value, selected);
    
  }

  public Component getTableCellRendererComponent
      (JTable table, Object value, boolean isSelected,
       boolean hasFocus, int row, int column) {
    CadLayer layer = (CadLayer) value;

    JCheckBox cb = new JCheckBox(layer.getName(), layer.isVisible());
    cb.setBackground(Color.white);
    cb.setHorizontalAlignment(SwingConstants.LEFT);
    return cb;
  }
}
