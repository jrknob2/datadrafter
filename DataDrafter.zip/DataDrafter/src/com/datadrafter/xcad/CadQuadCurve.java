package com.datadrafter.xcad;

import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.QuadCurve2D;
import java.io.PrintWriter;
import java.util.ArrayList;

import com.datadrafter.utils.Utils;
import com.datadrafter.xcad.CadView.CadCanvas;

public class CadQuadCurve extends CadShape implements ICadComponent {

	public CadQuadCurve() {
	}
	
	public CadQuadCurve(ArrayList points) {
		vectors.add(0, (Point2D)points.get(0));
		vectors.add(1, (Point2D)points.get(1));
		vectors.add(2, (Point2D)points.get(2));
	}
	
	public Shape getShape(CadView view) {
		Point2D[] points = new Point2D[3];

		points[0] =  view.getViewPoint(vectors.get(0));
		points[1] =  view.getViewPoint(vectors.get(1));
		points[2] =  view.getViewPoint(vectors.get(2));
		
		QuadCurve2D curve = new QuadCurve2D.Double();
		curve.setCurve(points, 0);
		return curve;
	}
	
	public void paint(Graphics g, CadCanvas canvas) {
	    Graphics2D g2 = (Graphics2D)g;
	    Color orig_color = g2.getColor();
	    Stroke orig_stroke = g2.getStroke();
	    
	    if (isSelected()) {
	    	g2.setStroke(bounds_stroke);
	    	g2.setColor(bounds_color);
	    	g2.draw((getShape(canvas.view).getBounds()));
	    }
	    
	    g2.setStroke(orig_stroke);	    
	    g2.setColor(bounds_color);
	    g2.draw((getShape(canvas.view)));
	    
	    if (!isSelected() && isMouseOver()) {
	    	Composite orig_comp = g2.getComposite();
	        g2.setComposite(makeComposite(0.5f));
	    	g2.fill(getShape(canvas.view));
	        g2.setComposite(orig_comp);	    	
	    }

	    if (isSelected()) {
	        Line2D tangent1 = new Line2D.Double(vectors.get(0), vectors.get(1));
	        Line2D tangent2 = new Line2D.Double(vectors.get(1), vectors.get(2));

	        g2.draw(tangent1);
	        g2.draw(tangent2);	    	
	    	
	        drawVectors(g2, canvas.view);
	        
	    }
	    
//	    if (getLabel() != null && getLabel().length() > 0 && overPoint != null) {
//			g2.setColor(Color.black);
//			Point2D point = new Point2D.Double(getShape(scale).getBounds().getCenterX(),
//												getShape(scale).getBounds().getCenterY());
//			g2.drawString(getLabel(), (int)overPoint.getX(), (int)overPoint.getY());
//	    }

	    g2.setColor(orig_color);
	    g2.setStroke(orig_stroke);

	}
	
	public boolean contains(Point2D point, CadView view) {
		return getShape(view).contains(point);
	}

	public String toXML() {	
		return "<curve>" +
			   	  "<id>" + getId() + "</id>" +
			      commonAttribsToXML() +
			      vectorsToXML() +
			   "</curve>";
	}

	public boolean setDataField(String label, Object value) {
	  	if (label.equals("Line Color")) {
	  		return setLineColor(((Color)value).getRGB()); 
	  	}
	  	if (label.equals("Line Width")) {
	  		return setWidth(Double.parseDouble((String)value));
	  	}
	  	return false;
	}

	public Object[][] toTableData() {
	    Object[][] data = new Object[1][2];

	    data[0][0] = "Element Type";
	    data[0][1] = "Curve";

	    return data;
   }	
	public CadQuadCurve clone() {
	    CadQuadCurve clone = new CadQuadCurve();
	    clone.vectors = new ArrayList<Point2D>(vectors);
		clone.angle = angle;
		clone.bounds_color = bounds_color;
		clone.bounds_stroke = bounds_stroke;
		clone.color = color;
		clone.fill = fill;
		clone.fillc = fillc;
		clone.label = label;
		clone.id = Utils.getUniqueId();
		clone.style = style;
	    return clone;
	}			
}