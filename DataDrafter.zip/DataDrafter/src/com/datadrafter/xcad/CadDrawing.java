package com.datadrafter.xcad;

/* CadDrawing.java */

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;

import javax.swing.JOptionPane;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.datadrafter.events.GraphicsAction;
import com.datadrafter.events.GraphicsAction;
import com.datadrafter.events.ObjectAction;
import com.datadrafter.xcad.CadView.CadCanvas;

public class CadDrawing {

	private boolean   clean       = true; 
	private long      id          = -1;
	private String    title       = "Untitled";
	private ArrayList<CadLayer> layers = new ArrayList<CadLayer>();
	private CadLayer  activeLayer = null;
	private CadGrid   grid        = new CadGrid();

	private Color back_color       = Color.WHITE;
	private String back_image_path = "";
	
	public BufferedImage buff_image = null;

	private String uomStandard = "SAE";
	private String uomBase = "Feet";
	private int    uomSize  = 144;
	
	private double minx = 0;
	private double miny = 0;
	private double maxx = 0;
	private double maxy = 0;

	private boolean showBackgroundImage = true;

	String version = null;
	String edition = null;
	
	public CadDrawing() {
		
		addLayer(new CadLayer(this));
		setClean(true);
	}

	public CadDrawing(long id) {
		setId(id);
		new DrawingReader(this);
    }

    public CadDrawing(URL filename) 
    {
    }
    
	public CadDrawing(String filename) {
		if (filename.contains(".CAD")) {
			try {
				InputSource input_source = new InputSource(filename);
				CadDrawingParser parser = new CadDrawingParser(this);
				parser.parse(input_source);
				setClean(true);
			} catch (InstantiationException e) {
				e.printStackTrace();
			} catch (SAXException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		if (filename.contains(".XML")) {
			try {
				InputSource input_source = new InputSource(filename);
				CadDrawingParser parser = new CadDrawingParser(this);
				parser.parse(input_source);
				setClean(true);
				GraphicsAction.fireGraphicsActionEvent(this, this, GraphicsAction.OPEN_DRAWING);
			} catch (InstantiationException e) {
				e.printStackTrace();
			} catch (SAXException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public BufferedImage getBufferedImage() {
		return buff_image;
	}
	public void addElement(CadShape shape) {
		getActiveLayer().add(shape);
		buff_image = null;
	}
	public void select(ArrayList selection, long elemId) {
		Iterator<CadLayer> iter = null;
		iter = layers.iterator();
		while (iter.hasNext()) {
			CadLayer layer = iter.next();
			if (layer.isVisible()) {
				layer.select(selection, elemId);
			}
		}
	}

	public boolean delete(ArrayList selectedShapes) {
		boolean anyremoved = false;

		Iterator<CadLayer> iter = null;
		iter = layers.iterator();
		while (iter.hasNext()) {
			CadLayer layer = iter.next();
			Iterator siter = selectedShapes.iterator();
			while (siter.hasNext()) {
				boolean removed = layer.remove((CadShape) siter.next());
				if (removed && anyremoved == false)
					anyremoved = removed; // removed is true
			}
		}
		return anyremoved;
	}

	public CadShape getElementById(long elemId) {
		Iterator<CadLayer> iter = null;
		iter = layers.iterator();
		while (iter.hasNext()) {
			CadLayer layer = iter.next();
			CadShape shape = layer.select(elemId);
			if (shape != null)
				return shape;
		}
		return null;
	}

	public void select(Point2D cp, CadView view, int mods) {
		switch (mods) {
		case (16): // no buttons down new selection
		{
			view.selectedShapes.clear();
			Iterator<CadLayer> layeriter = view.getDrawing().getLayers().iterator();
			while (layeriter.hasNext()) {
				CadLayer layer = layeriter.next();
				if (layer.isVisible() && layer.isSelectable()) {
					Iterator elemiter = layer.getShapes().iterator();
					while (elemiter.hasNext()) {
						ICadComponent comp = (ICadComponent) elemiter.next();
						if (comp.contains(cp, view)) {
							if (view.selectedShapes.indexOf(comp) == -1) {
								view.selectedShapes.add((CadShape) comp);
								return;
							}
						}
					}
				}
			}
			break;
		}
		case (17): // shift down selection
		{
			Iterator<CadLayer> layeriter = view.getDrawing().getLayers().iterator();
			while (layeriter.hasNext()) {
				CadLayer layer = layeriter.next();
				if (layer.isSelectable()) {
					Iterator elemiter = layer.getShapes().iterator();
					while (elemiter.hasNext()) {
						ICadComponent comp = (ICadComponent) elemiter.next();
						if (comp.contains(cp, view)) {
							if (view.selectedShapes.indexOf(comp) == -1) {
								view.selectedShapes.add((CadShape) comp);
								return;
							}
						}
					}
				}
			}
			break;
		}
		case (18): // ctrl down unselect
		{
			// view.getSelection().clear();
			Iterator<CadLayer> layeriter = view.getDrawing().getLayers().iterator();
			while (layeriter.hasNext()) {
				CadLayer layer = layeriter.next();
				if (layer.isVisible() && layer.isSelectable()) {
					Iterator elemiter = layer.getShapes().iterator();
					while (elemiter.hasNext()) {
						ICadComponent comp = (ICadComponent) elemiter.next();
						if (comp.contains(cp, view)) {
							if (view.selectedShapes.indexOf(comp) != -1) {
								view.selectedShapes.remove(comp);
								return;
							}
						}
					}
				}
			}
			break;
		}
		}
		return;
	}

	public void prepareToClose() {
		if (getClean() == false) {
			// Custom button text
			Object[] options = { "Yes", "No" };
			int n = JOptionPane
					.showOptionDialog(
							null,
							"Drawing ["
									+ this.getTitle()
									+ "] has been modified. "
									+ " Would you like to save these changes before closing it?",
							" Save Modifications", JOptionPane.YES_NO_OPTION,
							JOptionPane.QUESTION_MESSAGE, null, options,
							options[1]);
			if (n == 0) {
				toXML();
			}
		}
	}

	public void setTitle(String title) {
		if (!this.title.equals(title)) {
			this.title = title;
			setClean(false);
		}
	}

	public String getTitle() {
		return title;
	}

	public void setBackgroundImage(String back_image_path) {
		if (!this.back_image_path.equals(back_image_path)) {
			setClean(false);
			this.back_image_path = back_image_path;
		}
	}
	
	public String getBackgroundImage() {
		return back_image_path;
	}

	public boolean setBackGroundColor(int rgb) {
		if (this.back_color.getRGB() == rgb) {
			return false;
		}
		this.back_color = new Color(rgb);
		setClean(false);
		return true;
	}

	public Color getBackGroundColor() {
		return back_color;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getId() {
		return id;
	}

	public ArrayList<CadLayer> getLayers() {
		return layers;
	}
	
	public ArrayList<CadLayer> getVisibleLayers() {
		ArrayList<CadLayer> result = new ArrayList<CadLayer>();
		Iterator iter = layers.iterator();
		while (iter.hasNext()) {
			CadLayer layer = (CadLayer)iter.next();
			if (layer.isVisible()) result.add(layer);
		}
		return result;
	}

	public void setClean(boolean b) {
		clean = b;
	}

	public boolean getClean() {
		return clean;
	}

	public void addLayer(CadLayer layer) {
		layers.add(layer);
		activeLayer = layer;
		clean = false;
	}

	public CadLayer getLayerById(long id) {
		CadLayer l = null;
		Enumeration<CadLayer> en = Collections.enumeration(layers);
		while (en.hasMoreElements()) {
			l = en.nextElement();
			if (l.getID() == id) {
				return l;
			}
		}
		return null;
	}

	public boolean toXML(String filename) {
		PrintWriter out = null;
		if (filename == null) filename = "./drawings/" + getId() + ".XML";
		try {
			out = new PrintWriter(new FileWriter(filename));
			out.write(toXML());
		} catch (IOException ioe) {
			return false;
		} finally {
			out.close();
		}
		clean = true;
		return true;
	}

	public String toXML() {
		String xml = "<drawing>" +
				         "<version>" + getVersion() + "</version>" +
				         "<id>" + getId() + "</id>" +
				         "<title>" + getTitle() + "</title>" +
				         "<bckimg>" + getBackgroundImage() + "</bckimg>" +
				         "<bgcolor>" + getBackGroundColor().getRGB() + "</bgcolor>" +
				         "<uomtype>" + getUomStandard() + "</uomtype>" +
				         "<uombase>" + getUomBase() + "</uombase>" +
				         "<uomsize>" + getUomSize() + "</uomsize>" +			
				         "<layers>";

							Iterator<CadLayer> iter = layers.iterator();
							while (iter.hasNext()) {
								CadLayer layer = (CadLayer)iter.next();
								xml += layer.toXML();
							}
				
		return xml += "</layers></drawing>";
	}

	public Rectangle2D getBounds(double scale) {
		return new Rectangle.Double(minx * scale, miny * scale, (maxx - minx)
				* scale, (maxy - miny) * scale);
	}

	public Rectangle2D getBounds() {
		return new Rectangle.Double(minx, miny, maxx - minx, maxy - miny);
	}

	public void setDataField(String label, Object value) {
		if (label.equals("BG Color")) {
			if (setBackGroundColor(((Color) value).getRGB()))
				GraphicsAction.fireGraphicsActionEvent(this, this, GraphicsAction.DRAWING_MODIFIED);
		} else if (label.equals("Title")) {
			setTitle((String)value);
			//			if (setTitle((String) value))
//				GraphicsAction.fireGraphicsActionEvent(this, this, GraphicsAction.ELEM_MODIFIED);
		} else if (label.equals("Background Image")) {
			setBackgroundImage("./images/" +(String) value);
//			if (setBackgroundImage("./images/" +(String) value))
//				GraphicsAction.fireGraphicsActionEvent(this, this, GraphicsAction.DRAWING_UPDATED);
		}
	}

	public Object[][] toTableData() {
		Object[][] data = new Object[14][2];

		data[0][0] = "Id";
		data[0][1] = new Long(getId());
		data[1][0] = "Clean";
		data[1][1] = getClean() ? "True" : "False";
		data[2][0] = "Title";
		data[2][1] = getTitle();
		data[3][0] = "UOM Standard";
		data[3][1] = getUomStandard();
		data[4][0] = "UOM Base";
		data[4][1] = getUomBase();
		data[5][0] = "UOM Size";
		data[5][1] = getUomSize();
		data[6][0] = "Background Image";
		data[6][1] = getBackgroundImage() == null ? "" : getBackgroundImage();
		data[7][0] = "BG Color";
		data[7][1] = getBackGroundColor();
		data[8][0] = "Elements";
		data[8][1] = new Integer(getElementCount());
		data[9][0] = "Layers";
		data[9][1] = new Integer(getLayers().size());
		data[10][0] = "Max X";
		data[10][1] = new Double(getMaxX());
		data[11][0] = "Max Y";
		data[11][1] = new Double(getMaxY());
		data[12][0] = "Min X";
		data[12][1] = new Double(getMinX());
		data[13][0] = "Min Y";
		data[13][1] = new Double(getMinY());

		return data;
	}

	public boolean getShowBackgroundImage() {
		if (back_image_path == null)
			return false;
		return showBackgroundImage;
	}

	public boolean setShowBackgroundImage(boolean value) {
		if (this.showBackgroundImage == value)
			return false;
		this.showBackgroundImage = value;
		return true;
	}

	public int getElementCount() {
		int count = 0;

		Iterator<CadLayer> iter = layers.iterator();
		while (iter.hasNext()) {
			count += iter.next().getSize();
		}
		return count;
	}

	public double getMaxX() {
		return maxx;
	}

	/**
	 * @param maxx
	 *            The maxx to set.
	 */
	public void setMaxX(double maxx) {
		this.maxx = maxx;
	}

	/**
	 * @return Returns the maxy.
	 */
	public double getMaxY() {
		return maxy;
	}

	/**
	 * @param maxy
	 *            The maxy to set.
	 */
	public void setMaxY(double maxy) {
		this.maxy = maxy;
	}

	/**
	 * @return Returns the minx.
	 */
	public double getMinX() {
		return minx;
	}

	/**
	 * @param minx
	 *            The minx to set.
	 */
	public void setMinX(double minx) {
		this.minx = minx;
	}

	/**
	 * @return Returns the miny.
	 */
	public double getMinY() {
		return miny;
	}

	/**
	 * @param miny
	 *            The miny to set.
	 */
	public void setMinY(double miny) {
		this.miny = miny;
	}

	public boolean setLayerOrder(CadLayer layer, int dir) {
		if (layers.size() == 1)
			return false;
		int old_index = layers.indexOf(layer);
		int new_index = old_index + dir;
		if (new_index == -1 || new_index == layers.size())
			return false;
		CadLayer temp_layer = layers.get(new_index);

		layers.set(new_index, layer);
		layers.set(old_index, temp_layer);

		return true;
	}

	
	public void paint(CadCanvas canvas) {

		double scale = canvas.view.getScale();
		int width    = canvas.view.getCanvas().getPreferredSize().width; // TODO dont use prefered size use actual size
		int height   = canvas.view.getCanvas().getPreferredSize().height;
		
		Graphics2D buff_g = null;
		
		if (buff_image == null) {
			buff_image   = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			buff_g = (Graphics2D) buff_image.getGraphics();
			buff_g.setColor(getBackGroundColor());
			buff_g.fillRect(0, 0, width, height);

			if (getShowBackgroundImage() == true 
					&& getBackgroundImage() != null 
					&& getBackgroundImage().length() > 0) {
				Image image = new javax.swing.ImageIcon("./images/"	+ getBackgroundImage()).getImage();
				buff_g.drawImage(image, 0, 0, (int)(image.getWidth(canvas) * canvas.view.getScale()),
						             		  (int)(image.getHeight(canvas) * canvas.view.getScale()), canvas);
			}

			if (canvas.view.isShowGrid()) {
				grid.drawGrid(canvas);
			}

			Iterator<CadLayer> iter = getLayers().iterator();
			while (iter.hasNext()) {
				CadLayer layer = iter.next();
				if (!layer.isVisible()) return;
				Iterator citer = layer.getShapes().iterator();
				while (citer.hasNext()) {
					ICadComponent ccomp = (ICadComponent)citer.next();
					ccomp.paint(buff_g, canvas);
				}
			}
		}
	}

	public CadLayer getActiveLayer() {
		return activeLayer;
	}

	public void setActiveLayer(CadLayer activeLayer) {
		this.activeLayer = activeLayer;
	}
	
	public CadGrid getGrid() {
		return grid;
	}

	public void setGrid(CadGrid grid) {
		this.grid = grid;
	}

	public String getEdition() {
		return edition;
	}

	public void setEdition(String edition) {
		this.edition = edition;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getVersion() {
		return version;
	}
	public String getUomStandard() {
		return uomStandard;
	}

	public void setUomStandard(String uomStandard) {
		this.uomStandard = uomStandard;
	}

	public String getUomBase() {
		return uomBase;
	}

	public void setUomBase(String uomBase) {
		this.uomBase = uomBase;
	}

	public void setUomSize(int uomSize) {
		this.uomSize = uomSize;
	}
	
	public int getUomSize() {
		return uomSize;
	}
}