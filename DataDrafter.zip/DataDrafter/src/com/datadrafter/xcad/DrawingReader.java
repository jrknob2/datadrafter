package com.datadrafter.xcad;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */
import java.awt.geom.Point2D;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

import com.datadrafter.utils.Utils;

public class DrawingReader {

  private BufferedReader in = null;
  private CadDrawing drawing = null; 
  
  public DrawingReader(CadDrawing drawing) {
  	drawing.setVersion("1.1");
  	drawing.setEdition("Personal");
    this.drawing = drawing;
    openDrawing("./drawings/" + drawing.getId() + ".CAD");
  }

//  public DrawingReader(String filename, CadDrawing drawing) {
//  	drawing.setVersion("1.1");
//  	drawing.setEdition("Personal");
//  	this.drawing = drawing;
//    openDrawing(filename);
//  }

  public DrawingReader(URL url, CadDrawing drawing) {
	  	drawing.setVersion("1.1");
	  	drawing.setEdition("Personal");
	  	this.drawing = drawing;
	    openDrawing(url);
	  }

  public void openDrawing(String filename) {
	  try {
		  in = new BufferedReader(new FileReader(filename));
		  getDrawing();
	  } catch (FileNotFoundException fnf) {
		  fnf.printStackTrace();
	  }
  }
  public void openDrawing(URL url) {
	  try {
		  InputStream is = url.openStream(); 
		  InputStreamReader inR = new InputStreamReader(is) ; 
		  in = new BufferedReader(inR) ;
		  getDrawing();
	  } catch (IOException e) {
		  e.printStackTrace();
	  }
  }
  public void getDrawing() {
    String line = "";
    StringTokenizer st;
    String token;
    //int count = 0; /* to count layers */
    double aspect;
    //double h, w;
    long id = -1;
    long elemId;
    double x0, y0, x1, y1, cx, cy, r, start, da, angle, width;
    long drawingId;
    int style, color, fill, fillc; //units
    Point2D cp0; //, cp1;
    String name, sbuff; //linkName, ;

    try {
      while ( (line = in.readLine()) != null) {
    	  try {
    		  st = new StringTokenizer(line, "|");
    		  token = st.nextToken();
    		  if (token.equals("//")) {
    			  ;
    		  }
    		  else if (token.equals("version")) {
    			  drawing.setVersion(st.nextToken());
    		  }      
    		  else if (token.equals("edition")) {
    			  drawing.setEdition(st.nextToken());
    		  }
    		  else if (token.equals("id")) {
    			  drawing.setId(Long.parseLong(st.nextToken()));
    		  }
    		  else if (token.equals("title")) {
    			  sbuff = st.nextToken();
    			  drawing.setTitle(sbuff);
    		  }
    		  else if (token.equals("bckimg")) {
    			  sbuff = st.nextToken();
    			  drawing.setBackgroundImage(sbuff);
    		  }
//    		  else if (token.equals("suname")) {
//    			  drawing.setSmallUnitName(st.nextToken());
//    		  }
//    		  else if (token.equals("susize")) {
//    			  drawing.setSmallUnitSize(Integer.parseInt(st.nextToken()));
//    		  }
//    		  else if (token.equals("muname")) {
//    			  drawing.setMediumUnitName(st.nextToken());
//    		  }
//    		  else if (token.equals("musize")) {
//    			  drawing.setMediumUnitSize(Integer.parseInt(st.nextToken()));
//    		  }
//    		  else if (token.equals("luname")) {
//    			  drawing.setLargeUnitName(st.nextToken());
//    		  }
//    		  else if (token.equals("lusize")) {
//    			  drawing.setLargeUnitSize(Integer.parseInt(st.nextToken()));
//    		  }
    		  else if (token.equals("bgcolor")) {
    			  drawing.setBackGroundColor(Integer.parseInt(st.nextToken()));
    		  }
    		  else if (token.equals("layer")) {
    			  if (drawing.getVersion().equals("1.1")) {        	
    				  CadLayer layer = new CadLayer();
    				  layer.setId(Utils.getUniqueId());
    				  name = st.nextToken();
    				  double autoOn = Double.parseDouble(st.nextToken());
    				  double autoOff = Double.parseDouble(st.nextToken());
    				  layer.setName(name);
    				  layer.setAutoOn(autoOn);
    				  layer.setAutoOff(autoOff);
    			  } else if (drawing.getVersion().equals("1.2")) {
    				  id = Long.parseLong(st.nextToken());
    				  name = st.nextToken();
    				  double autoOn = Double.parseDouble(st.nextToken());
    				  double autoOff = Double.parseDouble(st.nextToken());       			
    				  boolean selectable = st.nextToken().equals("false") ? false : true;
    				  CadLayer layer = new CadLayer();
    				  layer.setName(name);
    				  layer.setAutoOff(autoOff);
    				  layer.setAutoOn(autoOn);
    				  layer.setSelectable(selectable);
    				  drawing.addLayer(layer);        		   			
    			  }
    		  }
//    		  else if (token.equals("view")) {
//    			  double height = 1.0;
//    			  double scale  = 1.0;        	
//    			  if (drawing.getVersion().equals("1.1")) {
//    				  id = Utils.getUniqueId();
//    				  Point2D orig = new Point2D.Double(
//    				  Double.parseDouble(st.nextToken()),
//					  Double.parseDouble(st.nextToken()));
//    				  height = Double.parseDouble(st.nextToken());
//    				  width  = Double.parseDouble(st.nextToken());
//    				  scale  = 1.0;
//    				  name   = st.nextToken();
//    				  SavedView view = new SavedView(id, orig, scale, name, height, width);
//    				  drawing.addView(view);
//    			  } else if (drawing.getVersion().equals("1.2")) {
//    				  id = Long.parseLong(st.nextToken());
//    				  Point2D orig = new Point2D.Double(
//    				  Double.parseDouble(st.nextToken()),
//                      Double.parseDouble(st.nextToken()));
//    				  height = Double.parseDouble(st.nextToken());
//    				  width = Double.parseDouble(st.nextToken());
//    				  scale = Double.parseDouble(st.nextToken());
//    				  sbuff = st.nextToken();
//    				  SavedView view = new SavedView(id, orig, scale, sbuff, height, width);
//    				  drawing.addView(view);          		
//    			  }
//    		  }
    		  else if (token.equals("item")) {
    			  if (drawing.getVersion().equals("1.1")) {
    				  double scale;
    				  elemId    = Long.parseLong(st.nextToken());
    				  scale     = Double.parseDouble(st.nextToken());
    				  x0        = Double.parseDouble(st.nextToken());
    				  y0        = Double.parseDouble(st.nextToken());
    				  drawingId = Long.parseLong(st.nextToken());
    				  angle = Double.parseDouble(st.nextToken());
    				  Point2D cp = new Point2D.Double(x0, y0);
    				  CadFigure item = new CadFigure(elemId, cp, drawingId);
    				  item.setAngle(angle);
    				  item.setScale(scale);
    				  drawing.getActiveLayer().add(item);
    				  // TODO: implement element clean
    				  //item.clean = true;
    			  } else if (drawing.getVersion().equals("1.2")) {
    				  double scale;
    				  elemId    = Long.parseLong(st.nextToken());
    				  scale     = Double.parseDouble(st.nextToken());
    				  x0        = Double.parseDouble(st.nextToken());
    				  y0        = Double.parseDouble(st.nextToken());
    				  drawingId = Long.parseLong(st.nextToken());
    				  angle = Double.parseDouble(st.nextToken());
    				  Point2D cp = new Point2D.Double(x0, y0);
    				  CadFigure item = new CadFigure();
    				  item.id = elemId;
    				  item.vectors.add(cp);
    				  item.setDrawingId(drawingId);
    				  item.setAngle(angle);
    				  item.setScale(scale);
    				  drawing.getActiveLayer().add(item);
    			  }
    		  } else if (token.equals("line")) {
    			  if (drawing.getVersion().equals("1.1")) {
    				  elemId = Long.parseLong(st.nextToken());
    				  x0 = Double.parseDouble(st.nextToken());
    				  y0 = Double.parseDouble(st.nextToken());
    				  x1 = Double.parseDouble(st.nextToken());
    				  y1 = Double.parseDouble(st.nextToken());
    				  color = Integer.parseInt(st.nextToken());
    				  width = Double.parseDouble(st.nextToken());
    				  style = Integer.parseInt(st.nextToken());
    				  angle = Double.parseDouble(st.nextToken());
    				  CadLine cl = new CadLine(new Point2D.Double(x0, y0), 
    						  				   new Point2D.Double(x1, y1));
    				  cl.color = color;
    				  cl.style = style;
    				  cl.angle = angle;
    				  cl.id = elemId;
    				  drawing.getActiveLayer().add(cl);
    			  } else if (drawing.getVersion().equals("1.2")) {
    				  elemId = Long.parseLong(st.nextToken());
    				  x0 = Double.parseDouble(st.nextToken());
    				  y0 = Double.parseDouble(st.nextToken());
    				  x1 = Double.parseDouble(st.nextToken());
    				  y1 = Double.parseDouble(st.nextToken());
    				  color = Integer.parseInt(st.nextToken());
    				  width = Double.parseDouble(st.nextToken());
    				  style = Integer.parseInt(st.nextToken());
    				  angle = Double.parseDouble(st.nextToken());
       				  CadLine cl = new CadLine(new Point2D.Double(x0, y0), 
       						  				   new Point2D.Double(x1, y1));
       				  cl.id = elemId; 
       				  cl.color = color;
       				  cl.style = style;
       				  cl.angle = angle;
       				
       				  drawing.getActiveLayer().add(cl);
    			  }
    		  } else if (token.equals("rect")) {
    			  if (drawing.getVersion().equals("1.1")) {
    				  elemId = Long.parseLong(st.nextToken());
    				  x0 = Double.parseDouble(st.nextToken());
    				  y0 = Double.parseDouble(st.nextToken());
    				  x1 = Double.parseDouble(st.nextToken());
    				  y1 = Double.parseDouble(st.nextToken());
    				  color = Integer.parseInt(st.nextToken());
    				  width = Double.parseDouble(st.nextToken());
    				  style = Integer.parseInt(st.nextToken());
    				  fill = Integer.parseInt(st.nextToken());
    				  fillc = Integer.parseInt(st.nextToken());
    				  angle = Double.parseDouble(st.nextToken());
    				  CadRectangle cr = new CadRectangle(new Point2D.Double(x0, y0),
    						  							 new Point2D.Double(x1, y1));
    				  cr.color = color;
    				  cr.width = width;
    				  cr.style = style;
    				  cr.fill = fill;
    				  cr.fillc = fillc;
    				  cr.setId(elemId);
    				  cr.setAngle(angle);
    				  drawing.getActiveLayer().add(cr);
    				  //cr.clean = true;
    			  } else if (drawing.getVersion().equals("1.2")){
    				  id = Long.parseLong(st.nextToken());
    				  x0 = Double.parseDouble(st.nextToken());
    				  y0 = Double.parseDouble(st.nextToken());
    				  x1 = Double.parseDouble(st.nextToken());
    				  y1 = Double.parseDouble(st.nextToken());
    				  color = Integer.parseInt(st.nextToken());
    				  width = Double.parseDouble(st.nextToken());
    				  style = Integer.parseInt(st.nextToken());
    				  fill = Integer.parseInt(st.nextToken());
    				  fillc = Integer.parseInt(st.nextToken());
    				  angle = Double.parseDouble(st.nextToken());
    				  CadRectangle cr = new CadRectangle(new Point2D.Double(x0, y0),
    						  	        new Point2D.Double(x1, y1)); 
    				  cr.id = id;
    				  cr.color = color;
    				  cr.width = width;
    				  cr.style = style;
    				  cr.fill = fill;
    				  cr.fillc = fillc;
    				  cr.angle = angle;
    				  drawing.getActiveLayer().add(cr);
    			  }
    		  }
    		  else if (token.equals("arc")) {
    			  if (drawing.getVersion().equals("1.1")) {
    				  elemId 	= Long.parseLong(st.nextToken());
    				  cx 		= Double.parseDouble(st.nextToken());
    				  cy 		= Double.parseDouble(st.nextToken());
    				  r 		= Double.parseDouble(st.nextToken());
    				  start 	= Double.parseDouble(st.nextToken());
    				  da 		= Double.parseDouble(st.nextToken());
    				  aspect 	= Double.parseDouble(st.nextToken());
    				  color 	= Integer.parseInt(st.nextToken());
    				  width 	= Double.parseDouble(st.nextToken());
    				  style 	= Integer.parseInt(st.nextToken());
    				  fill 		= Integer.parseInt(st.nextToken());
    				  fillc 	= Integer.parseInt(st.nextToken());
    				  angle 	= Double.parseDouble(st.nextToken());
    				  CadArc ca = new CadArc(new Point2D.Double(cx, cy), 
    						                 new Point2D.Double(cx + 10, cy + 10));
    				  ca.startAngle = start;
    				  ca.endAngle = da;
    				  ca.color = color;
    				  ca.width = width;
    				  ca.style = style;
    				  ca.fill = fill;
    				  ca.fillc = fillc;
    				  ca.setId(elemId);
    				  ca.setAngle(angle);
    				  drawing.getActiveLayer().add(ca);
    				  //ca.clean = true;
    			  } else if (drawing.getVersion().equals("1.2")) {
    				  id 		= Long.parseLong(st.nextToken());
    				  cx 		= Double.parseDouble(st.nextToken());
    				  cy 		= Double.parseDouble(st.nextToken());
    				  r 		= Double.parseDouble(st.nextToken());
    				  start 	= Double.parseDouble(st.nextToken());
    				  da 		= Double.parseDouble(st.nextToken());
    				  aspect 	= Double.parseDouble(st.nextToken());
    				  color 	= Integer.parseInt(st.nextToken());
    				  width 	= Double.parseDouble(st.nextToken());
    				  style 	= Integer.parseInt(st.nextToken());
    				  fill 	= Integer.parseInt(st.nextToken());
    				  fillc 	= Integer.parseInt(st.nextToken());
    				  angle 	= Double.parseDouble(st.nextToken());
    				  CadArc ca = new CadArc(new Point2D.Double(cx, cy), 
				                 new Point2D.Double(cx + 10, cy + 10));
					  ca.startAngle = start;
					  ca.endAngle = da;
					  ca.color = color;
					  ca.width = width;
					  ca.style = style;
					  ca.fill = fill;
					  ca.fillc = fillc;
					  ca.id = id;
					  ca.setAngle(angle);
					  drawing.getActiveLayer().add(ca);
    			  }
    		  } else if (token.equals("poly")) {
    			  if (drawing.getVersion().equals("1.1")) {
    				  elemId = Long.parseLong(st.nextToken());
    				  int k = 0;
    				  int size = Integer.parseInt(st.nextToken());
    				  ArrayList vecs = new ArrayList(size);
    				  while (k < size) {
    					  x0 = Double.parseDouble(st.nextToken());
    					  y0 = Double.parseDouble(st.nextToken());
    					  vecs.add(new Point2D.Double(x0, y0));
    					  ++k;
    				  }
    				  color = Integer.parseInt(st.nextToken());
    				  width = Double.parseDouble(st.nextToken());
    				  style = Integer.parseInt(st.nextToken());
    				  fill  = Integer.parseInt(st.nextToken());
    				  fillc = Integer.parseInt(st.nextToken());
    				  angle = Double.parseDouble(st.nextToken());          
    				  CadPolygon poly = new CadPolygon(vecs);
    				  poly.color = color;
    				  poly.width = width;
    				  poly.style = style;
    				  poly.fill = fill;
    				  poly.fillc = fillc;
    				  poly.setId(elemId);
    				  poly.setAngle(angle);
    				  drawing.getActiveLayer().add(poly);
    			  } else if (drawing.getVersion().equals("1.2")) {
    				  id = Long.parseLong(st.nextToken());
    				  int k = 0;
    				  int size = Integer.parseInt(st.nextToken());
    				  ArrayList vecs = new ArrayList(size);
    				  while (k < size) {
    					  x0 = Double.parseDouble(st.nextToken());
    					  y0 = Double.parseDouble(st.nextToken());
    					  vecs.add(new Point2D.Double(x0, y0));
    					  ++k;
    				  }
    				  color = Integer.parseInt(st.nextToken());
    				  width = Double.parseDouble(st.nextToken());
    				  style = Integer.parseInt(st.nextToken());
    				  fill  = Integer.parseInt(st.nextToken());
    				  fillc = Integer.parseInt(st.nextToken());
    				  angle = Double.parseDouble(st.nextToken());          
    				  CadPolygon poly = new CadPolygon(vecs);
    				  poly.color = color;
    				  poly.width = width;
    				  poly.style = style;
    				  poly.fill = fill;
    				  poly.fillc = fillc;
    				  poly.setId(id);
    				  poly.setAngle(angle);
    				  drawing.getActiveLayer().add(poly);
    			  }
    		  } else if (token.equals("lseg")) {
    			  id = Long.parseLong(st.nextToken());
    			  int k = 0;
    			  int size = Integer.parseInt(st.nextToken());
    			  ArrayList vecs = new ArrayList(size);
    			  while (k < size) {
    				  x0 = Double.parseDouble(st.nextToken());
    				  y0 = Double.parseDouble(st.nextToken());
    				  vecs.add(new Point2D.Double(x0, y0));
    				  ++k;
    			  }
    			  color = Integer.parseInt(st.nextToken());
    			  width = Double.parseDouble(st.nextToken());
    			  style = Integer.parseInt(st.nextToken());
    			  fill  = Integer.parseInt(st.nextToken());
    			  fillc = Integer.parseInt(st.nextToken());
    			  angle = Double.parseDouble(st.nextToken());
				  CadPolyLine polyl = new CadPolyLine(vecs);
				  polyl.color = color;
				  polyl.width = width;
				  polyl.style = style;
				  polyl.fill = fill;
				  polyl.fillc = fillc;
				  polyl.setId(id);
				  polyl.setAngle(angle);
				  drawing.getActiveLayer().add(polyl);
    		  }
    		  else if (token.equals("symb")) {
    			  elemId = Long.parseLong(st.nextToken());
    			  cp0 = new Point2D.Double(Double.parseDouble(st.nextToken()), Double.parseDouble(st.nextToken()));
    			  String text = st.nextToken();
    			  String fontName = st.nextToken();
    			  int fontSize = Integer.parseInt(st.nextToken());
    			  boolean bold = Integer.parseInt(st.nextToken()) == 1 ? true : false;
    			  boolean italic = Integer.parseInt(st.nextToken()) == 1 ? true : false;
    			  color = Integer.parseInt(st.nextToken());
    			  angle = Double.parseDouble(st.nextToken());
    			  CadLabel label = new CadLabel();
    			  label.id = elemId;
    			  label.text = text;
    			  label.vectors.add(cp0);
    			  label.setFontName(fontName);
    			  label.setFontSize(fontSize);
    			  label.setBold(bold);
    			  label.setItalic(italic);
    			  label.color = color;
    			  label.setAngle(angle);
    			  drawing.getActiveLayer().add(label);
    		  }
    	  } catch (NoSuchElementException nse) {
    	      //nse.printStackTrace();
    	  }

    	  CadLayer cl = drawing.getActiveLayer();
    	  if (cl != null) {
    		  // TODO figure out what this was
    		  //cl.clearStack();
    	  }
      }
    }
    catch (FileNotFoundException fnf) {
    	fnf.printStackTrace();
    }
    catch (IOException ioe) {
    	ioe.printStackTrace();
    }
    catch (NumberFormatException nfe) {
    	nfe.printStackTrace();
    }
    drawing.setClean(true);
  }
}