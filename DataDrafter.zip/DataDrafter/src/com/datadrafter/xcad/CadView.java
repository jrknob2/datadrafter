package com.datadrafter.xcad;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;

import com.datadrafter.events.GraphicsAction;
import com.datadrafter.events.GraphicsAction;
import com.datadrafter.utils.Utils;

public class CadView extends JPanel {

	private static final long serialVersionUID = 1L;

	protected JToolBar toolbar = new JToolBar(JToolBar.HORIZONTAL);
	protected JScrollPane scroller = new JScrollPane();
	
	public CadDrawing drawing = null;
	public CadCanvas canvas = null;
	
	public ArrayList<Point2D> points = new ArrayList<Point2D>();
	public ArrayList<CadShape> selectedShapes  = new ArrayList<CadShape>();	
	public ArrayList<CadShape> mouseOverShapes = new ArrayList<CadShape>();
	public static ArrayList<String> validCommands = new ArrayList<String>();
	public static ArrayList<String> validActions = new ArrayList<String>();

	private Point2D     mouse_point     = null;
	private Point2D     origin          = new Point2D.Double(0, 0);
	private Point2D[]   drag_points     = new Point2D[2];
	private Rectangle2D select_rec      = null;
	private boolean     redraw_needed   = false;
	private double      scale           = 1.0;
	private boolean     showGrid        = true;
	private Point2D     selected_vector = null;

	public static final int CMD_NONE       = 0;
	public static final int CMD_LINE_SHAPE = 1;
	public static final int CMD_RECT_SHAPE = 2;
	public static final int CMD_POLY_SHAPE = 3;
	public static final int CMD_CIRC_SHAPE = 4;
	public static final int CMD_TEXT_SHAPE = 5;
	public static final int CMD_PLYL_SHAPE = 6;
	public static final int CMD_CURV_SHAPE = 7;
	
	public static final int ACT_NONE     = 0;
	public static final int ACT_SELECT   = 1;
	public static final int ACT_ZOOM_IN  = 2;
	public static final int ACT_ZOOM_OUT = 3;
	public static final int ACT_PAN      = 4;
	
	private int def_brush_color      = Color.black.getRGB();
	private int def_brush_line_width = 1;
	private int def_line_style       = 0;
	
	private int view_width			 = 2000;
	private int view_height			 = 2000;
	
	private int command = CMD_NONE;
	private int action = ACT_SELECT;
	
	public CadView() {
		initialize();
	}
	public CadView(CadDrawing drawing) {
		this.drawing = drawing;		
		initialize();
	}
	
	private void initialize() {
		
		validCommands.add("None");
		validCommands.add("Line");
		validCommands.add("Rectangle");
		validCommands.add("Polygon");
		validCommands.add("Elipse");
		validCommands.add("Text Symbol");
		validCommands.add("Line Segment");
		validCommands.add("Curve");

		validActions.add("None");
		validActions.add("Select");
		validActions.add("Zoom In");
		validActions.add("Zoom Out");
		validActions.add("Pan");
		validActions.add("Copy");
		validActions.add("Paste");

	    canvas = new CadCanvas(drawing, this);
		canvas.setPreferredSize(new Dimension(view_height, view_width));

	    scroller.setAutoscrolls(true);
	    scroller.getViewport().add(canvas);
	    
	    setLayout(new BorderLayout());
	    
	    add(scroller, BorderLayout.CENTER);
	    add(toolbar, BorderLayout.SOUTH);		
	}
	
	public JPanel getCanvas() { return canvas; }
	
	public ArrayList getSelectedShapes() {
		return selectedShapes;
	}

	public void setSelectedShapes(ArrayList selectedShapes) {
		this.selectedShapes = selectedShapes;
	}

	public boolean setScale(double scale) {
    	if(this.scale == scale) return false;
    	if (scale < 0) scale = 0.0;
    	this.scale = scale;
    	return true;
	}
    
    public double getScale() { return Utils.getFormattedDouble(scale);}

	public int getDef_brush_color() {
		return def_brush_color;
	}
	public boolean setDef_brush_color(int defBrushColor) {
		if (this.def_brush_color == defBrushColor) return false;
		this.def_brush_color = defBrushColor;
		return true;
	}
	public int getDef_brush_line_width() {
		return def_brush_line_width;
	}
	public boolean setDef_brush_line_width(int defBrushLineWidth) {
		if (def_brush_line_width == defBrushLineWidth) return false;
		this.def_brush_line_width = defBrushLineWidth;
		return true;
	}
	public int getDef_line_style() {
		return def_line_style;
	}
	public boolean setDef_line_style(int defLineStyle) {
		if (def_line_style == defLineStyle) return false;
		this.def_line_style = defLineStyle;
		return true;
	}

	public int getView_width() {
		return view_width;
	}
	
	public boolean setView_width(int viewWidth) {
		if (view_width == viewWidth) return false;
		this.view_width = viewWidth;
		return true;
	}
	public int getView_height() {
		return view_height;
	}
	public boolean setView_height(int viewHeight) {
		if (view_height == viewHeight) return false;
		this.view_height = viewHeight;
		return true;
	}

    public void redraw() {
    	canvas.redraw();
    }

//	public void mouseClicked(MouseEvent e) {
//		
//		mouse_point = e.getModifiers() == 17 ? drawing.getGrid().snapToGrid(e.getPoint(), this) : e.getPoint();
//
//		switch (e.getModifiers()) {
//			case (4): { // right click
//				if (points.size() > 0) points.remove(points.size() - 1);
//				if (points.size() == 0) command = CMD_SELE_SHAPE;
//				break;
//			}
//			
//			case (16): { // regular click
//				points.add(new Point2D.Double(mouse_point.getX(), mouse_point.getY()));
//				break;
//			}			
//		}
//
//		switch (command) {
//			case (CMD_CIRC_SHAPE): {
//				if (points.size() == 2) {
//					Point2D p1 = new Point2D.Double(((Point2D)points.get(0)).getX()/scale, ((Point2D)points.get(0)).getY()/scale);
//					Point2D p2 = new Point2D.Double(((Point2D)points.get(1)).getX()/scale, ((Point2D)points.get(1)).getY()/scale);
//					CadArc arc = new CadArc(p1, p2);
//					arc.setSelected(false);
//					drawing.addElement(arc);
//					GraphicsAction.fireGraphicsActionEvent(this, arc, GraphicsAction.ELEM_ADDED);
//					points.clear();
//				}
//				break;
//			}
//			case (CMD_LINE_SHAPE): {
//				if (points.size() == 2) {
//					Point2D p1 = new Point2D.Double(((Point2D)points.get(0)).getX()/scale, ((Point2D)points.get(0)).getY()/scale);
//					Point2D p2 = new Point2D.Double(((Point2D)points.get(1)).getX()/scale, ((Point2D)points.get(1)).getY()/scale);
//					CadLine line = new CadLine(p1, p2);
//					line.setSelected(false);
//					drawing.addElement(line);
//					GraphicsAction.fireGraphicsActionEvent(this, line, GraphicsAction.ELEM_ADDED);
//					points.clear();
//				}
//				break;
//			}
//			case (CMD_RECT_SHAPE): {
//				if (points.size() == 2) {
//					Point2D p1 = new Point2D.Double(((Point2D)points.get(0)).getX()/scale, ((Point2D)points.get(0)).getY()/scale);
//					Point2D p2 = new Point2D.Double(((Point2D)points.get(1)).getX()/scale, ((Point2D)points.get(1)).getY()/scale);
//					CadRectangle rect = new CadRectangle(p1, p2);
//					rect.setSelected(false);
//					drawing.addElement(rect);
//					GraphicsAction.fireGraphicsActionEvent(this, rect, GraphicsAction.ELEM_ADDED);
//					points.clear();
//				}
//				break;
//			}
//			case (CMD_POLY_SHAPE): {
//				if (e.getModifiers() == 18) { // last point
//					CadPolygon poly = new CadPolygon();
//					//System.out.println("points.size-> " + points.size());
//					Iterator iter = points.iterator();
//					while (iter.hasNext()) {
//						Point2D p1 = (Point2D)iter.next();
//						Point2D p2 = new Point2D.Double(p1.getX()/scale, p1.getY()/scale);
//						poly.getVectors().add(p2);
//					}
//					poly.setSelected(false);
//					drawing.addElement(poly);
//					GraphicsAction.fireGraphicsActionEvent(this, poly, GraphicsAction.ELEM_ADDED);
//					points.clear();
//				}
//				break;
//			}
//			case (CMD_PLYL_SHAPE): {
//				if (e.getModifiers() == 18) { // last point
//					CadPolyLine poly = new CadPolyLine();
//					//System.out.println("points.size-> " + points.size());
//					Iterator iter = points.iterator();
//					while (iter.hasNext()) {
//						Point2D p1 = (Point2D)iter.next();
//						Point2D p2 = new Point2D.Double(p1.getX()/scale, p1.getY()/scale);
//						poly.getVectors().add(p2);
//					}
//					poly.setSelected(false);
//					drawing.addElement(poly);
//					GraphicsAction.fireGraphicsActionEvent(this, poly, GraphicsAction.ELEM_ADDED);
//					points.clear();
//				}
//				break;
//			}
//			case (CMD_SELE_SHAPE): {
//				// TODO add logic here for shift click and control click
//				System.out.println("e.getModifiers()-> " + e.getModifiers());
//
//				if (e.getModifiers() == 16) {// left-click
//					Iterator iter = selectedShapes.iterator();
//					while(iter.hasNext()) {
//						CadShape shape = (CadShape)iter.next();
//						((ICadComponent)shape).setSelected(false);
//					}
//					selectedShapes.clear();
//				}
//				
//				Iterator liter = drawing.getLayers().iterator();
//				while (liter.hasNext()) {
//					CadLayer layer = (CadLayer)liter.next();
//					if (!layer.isVisible() || !layer.isSelectable()) continue;
//					Iterator siter = layer.getShapes().iterator();
//					while (siter.hasNext()) {
//						CadShape shape = (CadShape)siter.next();
//						if (((ICadComponent)shape).contains(mouse_point, this)) {
//							if (e.getModifiers() == 16 || e.getModifiers() == 17) { // shift-left-click
//								shape.setSelected(true);
//								selectedShapes.add(shape);
//								repaint(); //canvas.paintComponent(canvas.getGraphics());
//							}
//							if (e.getModifiers() == 18) { // ctrl-left-click
//								if (selectedShapes.indexOf(shape) != -1) {
//									shape.setSelected(false);
//									selectedShapes.remove(selectedShapes.indexOf(shape));
//									repaint();
//								}
//							}							
//						}						
//					}
//				}
//
//				break;
//			}
//		}
//	}
//
//	public void mousePressed(MouseEvent e) {		
//	}
//
//	public void mouseReleased(MouseEvent e) {
//		if (command == CadView.CMD_SELE_SHAPE) {
//			select_rec = null;
//		}
////			Point2D p1 = (Point2D)drag_points[0];
////			Point2D p2 = (Point2D)drag_points[1];
////			Rectangle2D select_rec = new Rectangle2D.Double(p1.getX(), p1.getY(), p2.getX(), p2.getY());
////
////			Iterator liter = drawing.getLayers().iterator();
////			while (liter.hasNext()) {
////				CadLayer layer = (CadLayer)liter.next();
////				if (!layer.isVisible() || !layer.isSelectable()) continue;
////				Iterator siter = layer.getShapes().iterator();
////				while (siter.hasNext()) {
////					CadShape shape = (CadShape)siter.next();
////					if (select_rec.contains(((ICadComponent)shape).getShape(this).getBounds2D())) {
////						if (selectedShapes.indexOf(shape) != -1) {
////							shape.setSelected(false);
////							selectedShapes.remove(selectedShapes.indexOf(shape));
////						}						
////					}						
////					paint(getGraphics());
////				}
////			}		
////		}
//	}
//
//	public void mouseEntered(MouseEvent e) {
//	}
//
//	public void mouseExited(MouseEvent e) {
//	}
//
//	public void mouseDragged(MouseEvent e) {
//		
//		if (command == CadView.CMD_SELE_SHAPE) {
//			if (select_rec == null) {
//				drag_points[0] = (Point2D)e.getPoint();
//			} else {
//				drag_points[1] = (Point2D)e.getPoint(); 
//				Point2D p0 = (Point2D)drag_points[0];
//				Point2D p1 = (Point2D)drag_points[1];
//				select_rec = new Rectangle2D.Double(p0.getX(), p0.getY(), p1.getX(), p1.getY());
//			}
//			return;
//		}
//		
//		if (mouse_point == null) return;
//		
//		Point2D this_point = e.getModifiers() == 17 ? 
//				drawing.getGrid().snapToGrid(e.getPoint(), this) : e.getPoint();
//		
//		Point2D p1 = new Point2D.Double(mouse_point.getX() / scale, mouse_point.getY() / scale);
//		Point2D p2 = new Point2D.Double(this_point.getX() / scale, this_point.getY() / scale);
//		Point2D uv = CadShape.subtractPoints(p1, p2);
//		
//		Iterator iter = selectedShapes.iterator();
//		while(iter.hasNext()) {
//			CadShape shape = (CadShape)iter.next();
//			if (shape.isSelected()) {
//				if (shape.getSelectedVector() != null) {
//					int index = shape.getVectors().indexOf(shape.getSelectedVector());
//					shape.getVectors().set(index, p2);
//					shape.setSelectedVector(p2);
//				} else {
//					shape.move(uv);
//				}
//			}
//		}
//		mouse_point = this_point;
//		redraw();
//	}
//
//	public void mouseMoved(MouseEvent e) {
//		if (drawing == null) return; 
//		
//		mouse_point = e.getModifiers() == 1 ? drawing.getGrid().snapToGrid(e.getPoint(), this) : e.getPoint();
//
//		GraphicsAction.fireGraphicsActionEvent(this, mouse_point, GraphicsAction.MOUSE_MOVED);
//		
//		if (selectedShapes.size() > 0) {
//			Iterator tag_iter = selectedShapes.iterator();
//			while (tag_iter.hasNext()) {
//				CadShape shape = (CadShape)tag_iter.next();
//				shape.setSelectedVector(shape.getVector(mouse_point, scale));
//			}
//		}
//		
//		Iterator iter = drawing.getLayers().iterator();
//		while (iter.hasNext()) {
//			CadLayer layer = (CadLayer)iter.next();
//			if (!layer.isVisible()) continue;
//			Iterator siter = layer.getShapes().iterator();
//			while (siter.hasNext()) {
//				CadShape shape = (CadShape)siter.next();
//				if (((ICadComponent)shape).contains(e.getPoint(), this)) {
//					shape.setMouseOver(true);
//					if (mouseOverShapes.indexOf(shape) == -1) 
//						mouseOverShapes.add(shape);
//				} else {
//					shape.setMouseOver(false);
//					if (mouseOverShapes.indexOf(shape) != -1) 
//						mouseOverShapes.remove(shape);
//				}
//			}
//		}
//		repaint(); //canvas.paintComponent(canvas.getGraphics());
//	}

//	public boolean setMouseOver(boolean value) {
//		if (getMouseOver() == value) return false;
//		this.mouse_over = value;
//		return true;
//	}
	
//	public boolean getMouseOver() {return mouse_over;}
//	public int getCommand() {
//		return command;
//	}

	public Point2D getCenterPoint() {
		double xp = (getWidth()/2 - origin.getX()) * scale;
		double yp = (getHeight()/2 - origin.getY()) * scale;
		return new Point2D.Double(xp, yp);
	}

	public int getCommand() {
		return command;
	}

	public CadDrawing getDrawing() {
		return drawing;
	}

	public int getAction() {
		return action;
	}
	public void setAction(int action) {
		this.action = action;
	}

	//	public void setDrawing(CadDrawing drawing) {
//		if (this.drawing != null) this.drawing.prepareToClose();
//		this.drawing = drawing;
//		GraphicsAction.fireGraphicsActionEvent(this, drawing, GraphicsAction.DRAWING_OPENED);
//	}
	
	public Point2D getOrigin() {
		return origin;
	}

	public boolean setOrigin(Point2D origin) {
		if (this.origin.getX() == origin.getX() && this.origin.getY() == origin.getY())
			return false;
		this.origin = origin;
		return true;
	}
	
	public Point2D getViewPoint(Point2D p) {
		return new Point2D.Double((p.getX() - origin.getX()) * scale , (p.getY() - origin.getY()) * scale);
	}
	
	public Point2D getMouse_point() {
		return mouse_point;
	}

	public void setMouse_point(Point2D mousePoint) {
		mouse_point = mousePoint;
	}
 	public boolean isShowGrid() {
		return showGrid;
	}

	public boolean setShowGrid(boolean showGrid) {
		
		if (this.showGrid == showGrid) return false;
		this.showGrid = showGrid;
		return true;
	}

	public boolean setCommand(String value) {
		return setCommand(validCommands.indexOf(value));
	}

	public boolean setCommand(int command) {
		if (this.command == command)
			return false;
		this.command = command;
		this.selectedShapes.clear();
		points.clear();
		action = CadView.ACT_SELECT;
		GraphicsAction.fireGraphicsActionEvent(this, getCommandName(), GraphicsAction.COMMAND_SET);
		return true;
	}

	public String getCommandName() {
		return (String) validCommands.get(command);
	}

	public void setDataField(String label, Object value) {
		if (value == null) return;
		boolean modified = false;
		
		if (label.equals("Show Grid")) {
			modified = setShowGrid(((Boolean) value).booleanValue());
		} else if (label.equals("Grid Size")) {
			modified = drawing.getGrid().setSize(Integer.parseInt(value.toString()));
		} else if (label.equals("Show Background")) {
			modified = drawing.setShowBackgroundImage(((Boolean) value).booleanValue());
		} else if (label.equals("View Height")) {
			modified = setView_height(Integer.parseInt(value.toString()));
		} else if (label.equals("View Width")) {
			modified = setView_width(Integer.parseInt(value.toString()));
		} else if (label.equals("Origin X")) {
			Point2D p = new Point2D.Double(Double.parseDouble(value.toString()), origin.getY());
			modified = setOrigin(p);
		} else if (label.equals("Origin Y")) {
			Point2D p = new Point2D.Double(origin.getX(), Double.parseDouble(value.toString()));
			modified = setOrigin(p);
		} else if (label.equals("Scale")) {
			modified = setScale(Double.parseDouble(value.toString()));
		} else if (label.equals("Command")) {
			modified = setCommand(validCommands.indexOf(value));
		} else if (label.equals("Layer On/Off")) {
			modified = true;
		} else if (label.equals("Default Color")) {
			modified = setDef_brush_color(((Color) value).getRGB());
		} else if (label.equals("Default Line Width")) {
			modified = setDef_brush_line_width(((Integer) value).intValue());
		} else if (label.equals("Default Line Style")) {
			modified = setDef_line_style(CadShape.getStyle((String) value));
		} else if (label.equals("Active Layer")) {
			drawing.setActiveLayer((CadLayer)value);
		}

		if (modified) redraw();
	}
	
	public Object[][] toTableData() {
		
		int add_show_background = drawing.getBackgroundImage().length() > 0 ? 1 : 0;
		int i = 12;

		Object[][] data = new Object[i + getDrawing().getLayers().size() + add_show_background][2];
		data[0][0] = "Command";
		data[0][1] = validCommands.get(command);
		data[1][0] = "Active Layer";
		data[1][1] = drawing.getActiveLayer();		
		data[2][0] = "Scale";
		data[2][1] = new Double(Utils.getFormattedDouble(getScale()));
		data[3][0] = "Origin X";
		data[3][1] = new Double(origin.getX());
		data[4][0] = "Origin Y";
		data[4][1] = new Double(origin.getY());
		data[5][0] = "View Height";
		data[5][1] = new Integer(getHeight());
		data[6][0] = "View Width";
		data[6][1] = new Integer(getWidth());
		data[7][0] = "Grid Size";
		data[7][1] = new Double(16.0); // TODO grid.getSize());
		data[8][0] = "Show Grid";
		data[8][1] = new Boolean(true); // TODO getGrid().getVisible());
		data[9][0] = "Default Color";
		data[9][1] = Color.black; // new Color(Color.black); // TODO getDefaultColor());
		data[10][0] = "Default Line Width";
		data[10][1] = new Integer(1); // TODO width);
		data[11][0] = "Default Line Style";
		data[11][1] = CadShape.lineStyles[1]; //TODO .getStyleName(1style);

		if (add_show_background != 0) {
			data[i][0] = "Show Background";
			data[i][1] = new Boolean(drawing.getShowBackgroundImage());
		}

		for (int j = 0; j < getDrawing().getLayers().size(); ++j) {
			data[i + add_show_background][0] = "Layer On/Off";
			CadLayer layer = (CadLayer) getDrawing().getLayers().get(j);
			data[i + add_show_background][1] = layer;
			++i;
		}
		return data;
	}

	public void setDrawing(CadDrawing drawing) {
		this.drawing = drawing;
	}
	public static ArrayList getValidCommands() {
		return validCommands;
	}
	public static ArrayList getValidActions() {
		return validActions;
	}

	public class CadCanvas extends JPanel  implements MouseListener, MouseMotionListener {
		private static final long serialVersionUID = 1L;

		CadDrawing drawing = null;
		CadView view = null;
		
		public CadCanvas(CadDrawing drawing, CadView view)
		{
			this.drawing = drawing;
			this.view = view;
			
			addMouseListener(this);
		    addMouseMotionListener(this);
		}
		
		public void mouseClicked(MouseEvent e) {

			mouse_point = e.getModifiers() == 17 ? drawing.getGrid().snapToGrid(e.getPoint(), view) : 
							new Point2D.Double(e.getPoint().getX() / scale, e.getPoint().getY() / scale);


			switch (e.getModifiers()) {
				case (4): { // right click
					if (points.size() == 0) {
						setAction(ACT_SELECT);
						setCommand(CMD_NONE);
					}
					if (points.size() > 0) points.remove(points.size() - 1);
					
					if (points.size() == 1) 
						if (command != CMD_CURV_SHAPE)
							points.clear();
					
					break;
				}
				
				case (16): { // regular click
					points.add(new Point2D.Double(mouse_point.getX(), mouse_point.getY()));
					break;
				}			
			}

			switch (command) {
				case (CMD_CIRC_SHAPE): {
					if (points.size() == 2) {
						Point2D p1 = new Point2D.Double(((Point2D)points.get(0)).getX()/scale, ((Point2D)points.get(0)).getY()/scale);
						Point2D p2 = new Point2D.Double(((Point2D)points.get(1)).getX()/scale, ((Point2D)points.get(1)).getY()/scale);
						CadArc arc = new CadArc(p1, p2);
						arc.setSelected(false);
						drawing.addElement(arc);
						GraphicsAction.fireGraphicsActionEvent(this, arc, GraphicsAction.ELEM_ADDED);
						points.clear();
					}
					break;
				}
				case (CMD_LINE_SHAPE): {
					if (points.size() == 2) {
						Point2D p1 = new Point2D.Double(((Point2D)points.get(0)).getX()/scale, ((Point2D)points.get(0)).getY()/scale);
						Point2D p2 = new Point2D.Double(((Point2D)points.get(1)).getX()/scale, ((Point2D)points.get(1)).getY()/scale);
						CadLine line = new CadLine(p1, p2);
						line.setSelected(false);
						drawing.addElement(line);
						GraphicsAction.fireGraphicsActionEvent(this, line, GraphicsAction.ELEM_ADDED);
						points.clear();
					}
					break;
				}
				case (CMD_RECT_SHAPE): {
					if (points.size() == 2) {
						Point2D p1 = new Point2D.Double(((Point2D)points.get(0)).getX()/scale, ((Point2D)points.get(0)).getY()/scale);
						Point2D p2 = new Point2D.Double(((Point2D)points.get(1)).getX()/scale, ((Point2D)points.get(1)).getY()/scale);
						CadRectangle rect = new CadRectangle(p1, p2);
						rect.setSelected(false);
						drawing.addElement(rect);
						GraphicsAction.fireGraphicsActionEvent(this, rect, GraphicsAction.ELEM_ADDED);
						points.clear();
					}
					break;
				}
				case (CMD_CURV_SHAPE): {
					if (e.getModifiers() == 18) { // last point
						if (points.size() == 2) {
							CadQuadCurve curve = new CadQuadCurve();
							Iterator iter = points.iterator();
							while (iter.hasNext()) {
								Point2D p1 = (Point2D)iter.next();
								Point2D p2 = new Point2D.Double(p1.getX()/scale, p1.getY()/scale);
								curve.getVectors().add(p2);
							}
							curve.getVectors().add(new Point2D.Double(e.getPoint().getX()/scale, e.getPoint().getY()/scale));
							curve.setSelected(false);
							drawing.addElement(curve);
							GraphicsAction.fireGraphicsActionEvent(this, curve, GraphicsAction.ELEM_ADDED);
							points.clear();							
						}
					}

					if (points.size() == 4) {
						CadCubicCurve curve = new CadCubicCurve();
						Iterator iter = points.iterator();
						while (iter.hasNext()) {
							Point2D p1 = (Point2D)iter.next();
							Point2D p2 = new Point2D.Double(p1.getX()/scale, p1.getY()/scale);
							curve.getVectors().add(p2);
						}
						//curve.getVectors().add(new Point2D.Double(e.getPoint().getX()/scale, e.getPoint().getY()/scale));
						curve.setSelected(false);
						drawing.addElement(curve);
						GraphicsAction.fireGraphicsActionEvent(this, curve, GraphicsAction.ELEM_ADDED);
						points.clear();							
					}
					
					break;
				}
				case (CMD_POLY_SHAPE): {
					if (e.getModifiers() == 18) { // last point
						CadPolygon poly = new CadPolygon();
						//System.out.println("points.size-> " + points.size());
						Iterator iter = points.iterator();
						while (iter.hasNext()) {
							Point2D p1 = (Point2D)iter.next();
							Point2D p2 = new Point2D.Double(p1.getX()/scale, p1.getY()/scale);
							poly.getVectors().add(p2);
						}
						poly.setSelected(false);
						drawing.addElement(poly);
						GraphicsAction.fireGraphicsActionEvent(this, poly, GraphicsAction.ELEM_ADDED);
						points.clear();
					}
					break;
				}
				case (CMD_PLYL_SHAPE): {
					if (e.getModifiers() == 18) { // last point
						CadPolyLine poly = new CadPolyLine();
						//System.out.println("points.size-> " + points.size());
						Iterator iter = points.iterator();
						while (iter.hasNext()) {
							Point2D p1 = (Point2D)iter.next();
							Point2D p2 = new Point2D.Double(p1.getX()/scale, p1.getY()/scale);
							poly.getVectors().add(p2);
						}
						poly.setSelected(false);
						drawing.addElement(poly);
						GraphicsAction.fireGraphicsActionEvent(this, poly, GraphicsAction.ELEM_ADDED);
						points.clear();
					}
					break;
				}
			}				
				
			//boolean repaint_needed = false;
			boolean selection_changed = false;
			
			switch (action) {
				case (ACT_SELECT): 
				{
					Iterator liter = drawing.getVisibleLayers().iterator();
					while (liter.hasNext()) {
						CadLayer layer = (CadLayer)liter.next();
						if (!layer.isSelectable()) continue;
						Iterator siter = layer.getShapes().iterator();
						while (siter.hasNext()) {
							CadShape shape = (CadShape)siter.next();
							if (e.getModifiers() == 16) { // regular click
								if (((ICadComponent)shape).contains(mouse_point, view)) {
									if (shape.isSelected()) continue;
									shape.setSelected(true);
									selectedShapes.add(shape);
									selection_changed = true;
									repaint();
									((ICadComponent)shape).paint(getGraphics(), this);
								} else {
									if (shape.isSelected()) {
										shape.setSelected(false);
										selectedShapes.remove(shape);
										selection_changed = true;
										repaint();
										((ICadComponent)shape).paint(getGraphics(), this);
									}
								}
							}
							if (e.getModifiers() == 16 || e.getModifiers() == 17) { // shift-left-click
								if (((ICadComponent)shape).contains(mouse_point, view)) {
									if (selectedShapes.indexOf(shape) == -1) {
										shape.setSelected(true);
										selectedShapes.add(shape);
										selection_changed = true;
										repaint();
										((ICadComponent)shape).paint(getGraphics(), this);
									}
								}
							}
							if (e.getModifiers() == 18) { // ctrl-left-click
								if (((ICadComponent)shape).contains(mouse_point, view)) {
									if (selectedShapes.indexOf(shape) != -1) {
										shape.setSelected(false);
										selection_changed = true;
										selectedShapes.remove(selectedShapes.indexOf(shape));
										repaint();
										((ICadComponent)shape).paint(getGraphics(), this);
									}
								}
							}														
						}
					}
					break;
				}				
			}
			
			if (selection_changed) {
				if (selectedShapes.size() == 1) {
					GraphicsAction.fireGraphicsActionEvent(view, selectedShapes.get(0), GraphicsAction.ELEM_SELECTED);
				}		
			}
		}
		public void mousePressed(MouseEvent e) {		
		}

		public void mouseReleased(MouseEvent e) {
			if (selected_vector != null) selected_vector = null;
			if (redraw_needed) redraw();
			
			if (select_rec != null) {
				Iterator liter = drawing.getVisibleLayers().iterator();
				while (liter.hasNext()) {
					CadLayer layer = (CadLayer)liter.next();
					if (!layer.isSelectable()) continue;
					Iterator siter = layer.getShapes().iterator();
					while (siter.hasNext()) {
						CadShape shape = (CadShape)siter.next();
						if (shape == null) continue;
						Shape s = ((ICadComponent)shape).getShape(view);
						if (s == null) continue;
						Rectangle2D bounds = s.getBounds2D();
						Point2D centerp = new Point2D.Double(bounds.getCenterX(),bounds.getCenterY());
						if (select_rec.contains(centerp)) {
							if (selectedShapes.indexOf(shape) == -1) {
								shape.setSelected(true);
								selectedShapes.add(shape);
							}						
						}						
					}
				}
				select_rec = null;
				drag_points[0] = null;
				drag_points[1] = null;
				repaint();									
			}
		}

		public void mouseEntered(MouseEvent e) {
		}

		public void mouseExited(MouseEvent e) {
		}

		public void mouseDragged(MouseEvent e) {
			
			Point2D drag_point = e.getModifiers() == 17 ? 
					drawing.getGrid().snapToGrid(e.getPoint(), view) : 
					new Point2D.Double(e.getPoint().getX() / scale, e.getPoint().getY() / scale);

			Point2D uv = CadShape.subtractPoints(mouse_point, drag_point);
			mouse_point = drag_point;
			
			if (selected_vector != null) {
				selected_vector.setLocation(drag_point);
				view.getDrawing().setClean(false);
				redraw_needed = true;
				repaint();
			} else {
				if (mouseOverShapes.size() > 0) { 
					Iterator iter = selectedShapes.iterator();
					while(iter.hasNext()) {
						CadShape shape = (CadShape)iter.next();
						shape.move(uv);
						redraw_needed = true;
						repaint();
					}
				} else {
					if (drag_points[0] == null) {
						drag_points[0] = (Point2D)e.getPoint();
					} else {
						drag_points[1] = (Point2D)e.getPoint(); 
						Point2D p0 = (Point2D)drag_points[0];
						Point2D p1 = (Point2D)drag_points[1];
						select_rec = new Rectangle2D.Double( p0.getX(), p0.getY(), p1.getX() - p0.getX(), p1.getY() - p0.getY());
						repaint();
						((Graphics2D)getGraphics()).draw(select_rec);
					}					
				}
			}

			//			if (action == CadView.ACT_SELECT) {
//				if (select_rec == null) {
//					drag_points[0] = (Point2D)e.getPoint();
//				} else {
//					drag_points[1] = (Point2D)e.getPoint(); 
//					Point2D p0 = (Point2D)drag_points[0];
//					Point2D p1 = (Point2D)drag_points[1];
//					select_rec = new Rectangle2D.Double(p0.getX(), p0.getY(), p1.getX(), p1.getY());
//				}
//				return;
//			}
			
//			if (mouse_point == null) return;
			
			
//			Point2D p1 = new Point2D.Double(mouse_point.getX() / scale, mouse_point.getY() / scale);
//			Point2D p2 = new Point2D.Double(this_point.getX() / scale, this_point.getY() / scale);
//			Point2D uv = CadShape.subtractPoints(p1, p2);
//			
////			Iterator iter = selectedShapes.iterator();
////			while(iter.hasNext()) {
////				CadShape shape = (CadShape)iter.next();
////				if (shape.isSelected()) {
////					if (shape.getSelectedVector() != null) {
////						int index = shape.getVectors().indexOf(shape.getSelectedVector());
////						shape.getVectors().set(index, p2);
////						shape.setSelectedVector(p2);
////					} else {
////						shape.move(uv);
////					}
////				}
////			}
//			mouse_point = this_point;
			//if (redraw_needed) redraw();
		}

		public void mouseMoved(MouseEvent e) {
			if (drawing == null) return; 
			
			mouse_point = e.getModifiers() == 1 ? drawing.getGrid().snapToGrid(e.getPoint(), view) : e.getPoint();
			GraphicsAction.fireGraphicsActionEvent(this, mouse_point, GraphicsAction.MOUSE_MOVED);
			
			if (selectedShapes.size() > 0) {
				Iterator tag_iter = selectedShapes.iterator();
				while (tag_iter.hasNext()) {
					CadShape shape = (CadShape)tag_iter.next();
					selected_vector = shape.getVector(mouse_point, scale);
				}
			}
			
			Iterator iter = drawing.getLayers().iterator();
			while (iter.hasNext()) {
				CadLayer layer = (CadLayer)iter.next();
				if (!layer.isVisible() || !layer.isSelectable()) continue;
				Iterator siter = layer.getShapes().iterator();
				while (siter.hasNext()) {
					CadShape shape = (CadShape)siter.next();
					if (((ICadComponent)shape).contains(e.getPoint(), view)) {
						shape.setMouseOver(true);
						if (mouseOverShapes.indexOf(shape) == -1) 
							mouseOverShapes.add(shape);
							repaint();
					} else {
						shape.setMouseOver(false);
						if (mouseOverShapes.indexOf(shape) != -1) 
							mouseOverShapes.remove(shape);
							repaint();
					}
				}
			}
		}

	    public void redraw() {
	    	if (drawing != null) drawing.buff_image = null;
	    	System.out.println("redraw!");
	    	redraw_needed = false;
	    	repaint();
	    }
		
		public void paint(Graphics g) {
			
			Graphics2D g2d = (Graphics2D)g; //(Graphics2D)g;
			g2d.drawRect(10, 10, 250, 250);
			
	    	Color orig_color = g2d.getColor();
	    	
	    	if (drawing != null) {
	    		if (drawing.buff_image == null)
	    			drawing.paint(this);
	    		g2d.drawImage(drawing.buff_image, 0, 0, drawing.buff_image.getWidth(), 
	    												drawing.buff_image.getHeight(), this);	    		
	    	}    	
	    	
			switch(command) {
				case (CMD_CIRC_SHAPE): {
					if (mouse_point != null && points.size() == 1) {
						CadArc arc = new CadArc((Point2D)points.get(0), (Point2D)mouse_point);
						arc.setSelected(true);
						arc.paint(g2d, this);
					}
					break;
				}
				case (CMD_LINE_SHAPE): {
					if (mouse_point != null && points.size() == 1) {
						CadLine line = new CadLine((Point2D)points.get(0), (Point2D)mouse_point);
						line.setSelected(true);
						line.paint(g2d, this);
					}
					break;
				}		
				case (CMD_RECT_SHAPE): {
					if (mouse_point != null && points.size() == 1) {
						CadRectangle rect = new CadRectangle((Point2D)points.get(0), (Point2D)mouse_point);
						rect.setSelected(true);
						rect.paint(g2d, this);
					}
					break;
				}
				case (CMD_CURV_SHAPE): {
					if (mouse_point != null) {						
						if (points.size() == 1) {
							CadLine line = new CadLine(points.get(0), mouse_point);
							line.setSelected(true);
							line.paint(g2d, this);
						}
						
						if (points.size() == 2) {
							points.add(mouse_point);
							CadQuadCurve curve = new CadQuadCurve(points);
							curve.getVectors().add(mouse_point);
							curve.setSelected(true);
							curve.paint(g2d, this);
							points.remove(points.size()-1);							
						}
						
						if (points.size() == 3) {
							points.add(mouse_point);
							CadCubicCurve curve = new CadCubicCurve(points);
							curve.getVectors().add(mouse_point);
							curve.setSelected(true);
							curve.paint(g2d, this);
							points.remove(points.size()-1);							
						}

					}					
					break;
				}
				case (CMD_POLY_SHAPE): {
					if (mouse_point != null) {						
						if (points.size() == 1) {
							CadPolygon poly = new CadPolygon(points);
							poly.getVectors().add(poly.getVectors().size(), mouse_point);
							poly.setSelected(true);
							poly.paint(g2d, this);
						}
						
						if (points.size() > 1) {
							CadPolygon poly = new CadPolygon(points);
							poly.getVectors().set(poly.getVectors().size()-1, mouse_point);
							poly.setSelected(true);
							poly.paint(g2d, this);
						}
					}
					
					break;
				}
				case (CMD_PLYL_SHAPE): {
					if (mouse_point != null) {
						
						if (points.size() == 1) {
							CadPolyLine poly = new CadPolyLine(points);
							poly.getVectors().add(poly.getVectors().size(), mouse_point);
							poly.setSelected(true);
							poly.paint(g2d, this);
						}
						
						if (points.size() > 1) {
							CadPolyLine poly = new CadPolyLine(points);
							poly.getVectors().set(poly.getVectors().size()-1, mouse_point);
							poly.setSelected(true);
							poly.paint(g2d, this);
						}
					}	
					break;
				}
			}
			
			switch (action) {
				case (ACT_SELECT): {
					if (select_rec != null) 
						g2d.draw(select_rec);				
				}
			}
			
			Iterator siter2 = mouseOverShapes.iterator();
			while (siter2.hasNext()) {
				ICadComponent comp = (ICadComponent)siter2.next();
				comp.paint(g2d, canvas);
			}
	
			Iterator siter = selectedShapes.iterator();
			while (siter.hasNext()) {
				ICadComponent comp = (ICadComponent)siter.next();
				comp.paint(g2d, canvas);
			}
	
			// draw cross hairs if needed
			if (mouse_point != null && command != CadView.CMD_NONE) {
				g2d.setXORMode(Color.WHITE);
				Line2D hline = new Line2D.Double(0, mouse_point.getY(), getWidth(), mouse_point.getY()); 
				Line2D vline = new Line2D.Double(mouse_point.getX(), 0, mouse_point.getX(), getHeight());
				g2d.draw(hline);
				g2d.draw(vline);
				g2d.setColor(orig_color);
			}
		}	
	}
}