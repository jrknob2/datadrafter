package com.datadrafter.xcad;

import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.CubicCurve2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;

import com.datadrafter.utils.Utils;
import com.datadrafter.xcad.CadView.CadCanvas;

public class CadCubicCurve extends CadShape implements ICadComponent {

	public CadCubicCurve() {
	}
	
	public CadCubicCurve(ArrayList points) {
		vectors.add(0, (Point2D)points.get(0));
		vectors.add(1, (Point2D)points.get(1));
		vectors.add(2, (Point2D)points.get(2));
		vectors.add(3, (Point2D)points.get(3));
	}
	
	public Shape getShape(CadView view) {
		Point2D[] points = new Point2D[4];

		Point2D p1 = (Point2D)vectors.get(0);
		Point2D p2 = (Point2D)vectors.get(1);
		Point2D p3 = (Point2D)vectors.get(2);
		Point2D p4 = (Point2D)vectors.get(3);
		
		points[0] =  new Point2D.Double((p1.getX() - view.getOrigin().getX()) * view.getScale(), 
				                        (p1.getY() - view.getOrigin().getY()) * view.getScale());
		points[1] =  new Point2D.Double((p2.getX() - view.getOrigin().getX()) * view.getScale(), 
										(p2.getY() - view.getOrigin().getY()) * view.getScale());
		points[2] =  new Point2D.Double((p3.getX() - view.getOrigin().getX()) * view.getScale(), 
										(p3.getY() - view.getOrigin().getY()) * view.getScale());
		points[3] =  new Point2D.Double((p4.getX() - view.getOrigin().getX()) * view.getScale(),
										(p4.getY() - view.getOrigin().getY()) * view.getScale());
		
		CubicCurve2D curve = new CubicCurve2D.Double();
		curve.setCurve(points, 0);
		return curve;
	}
	
	public void paint(Graphics g, CadCanvas canvas) {
	    Graphics2D g2 = (Graphics2D)g;
	    Color orig_color = g2.getColor();
	    Stroke orig_stroke = g2.getStroke();
	    
	    if (isSelected()) {
	    	g2.setStroke(bounds_stroke);
	    	g2.setColor(bounds_color);
	    	g2.draw((getShape(canvas.view).getBounds()));
	    }
	    
	    g2.setStroke(orig_stroke);	    
	    g2.setColor(bounds_color);
	    g2.draw((getShape(canvas.view)));
	    
	    if (!isSelected() && isMouseOver()) {
	    	Composite orig_comp = g2.getComposite();
	        g2.setComposite(makeComposite(0.5f));
	    	g2.fill(getShape(canvas.view));
	        g2.setComposite(orig_comp);	    	
	    }

	    if (isSelected()) {
	        Line2D tangent1 = new Line2D.Double(vectors.get(0), vectors.get(1));
	        Line2D tangent2 = new Line2D.Double(vectors.get(2), vectors.get(3));

	        g2.draw(tangent1);
	        g2.draw(tangent2);	    	
	    	
	    	Iterator iter = vectors.iterator();
		    while (iter.hasNext()) {
		    	Point2D vec = (Point2D)iter.next();
				Rectangle2D vecrec = new Rectangle2D.Double(((vec.getX() - canvas.view.getOrigin().getX())* canvas.view.getScale()) - side / 2, 
															((vec.getY() - canvas.view.getOrigin().getY())* canvas.view.getScale()) - side / 2, side, side);
				g2.setColor(vec == getSelectedVector() ? selvec_color : vector_color);
				g2.fill(vecrec);
				g2.setColor(bounds_color);
				g2.draw(vecrec);	
		    }
	    }
	    
	    g2.setColor(orig_color);
	    g2.setStroke(orig_stroke);

	}
	
	public boolean contains(Point2D point, CadView view) {
		return getShape(view).contains(point);
	}

	public String toXML() {	
		return "<curve>" +
			   	  "<id>" + getId() + "</id>" +
			      commonAttribsToXML() +
			      vectorsToXML() +
			   "</curve>";
	}

	public boolean setDataField(String label, Object value) {
	  	if (label.equals("Line Color")) {
	  		return setLineColor(((Color)value).getRGB()); 
	  	}
	  	if (label.equals("Line Width")) {
	  		return setWidth(Double.parseDouble((String)value));
	  	}
	  	return false;
	}

	public Object[][] toTableData() {
	    Object[][] data = new Object[1][2];

	    data[0][0] = "Element Type";
	    data[0][1] = "Curve";

	    return data;
   }	
	
	public CadCubicCurve clone() {
	    CadCubicCurve clone = new CadCubicCurve();
	    clone.vectors = new ArrayList<Point2D>(vectors);
		clone.angle = angle;
		clone.bounds_color = bounds_color;
		clone.bounds_stroke = bounds_stroke;
		clone.color = color;
		clone.fill = fill;
		clone.fillc = fillc;
		clone.label = label;
		clone.id = Utils.getUniqueId();
		clone.style = style;
	    return clone;
	}		
}