package com.datadrafter.xcad;

import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;

import com.datadrafter.events.GraphicsAction;
import com.datadrafter.utils.Utils;
import com.datadrafter.xcad.CadView.CadCanvas;

public class CadLayer {
  private ArrayList<ICadComponent> shapes = new ArrayList<ICadComponent>();
  private long id;
  private String name = "";
 
  private double  autoOn     = -1;
  private double  autoOff    = -1;
  private boolean visible    = true;
  private boolean selectable = true;
  
  public ArrayList<ICadComponent> getShapes() {
  	return shapes; 
  }
  
  public CadLayer() {
  }
  
  public CadLayer(CadDrawing drawing) {
	  this(Utils.getUniqueId(), "Layer " + (drawing.getLayers().size() + 1), -1, -1, true);
	  drawing.setActiveLayer(this);
  }

  public CadLayer(long id, String name, double autoOn, double autoOff, boolean selectable) {
    this.id = id;
    this.name = name;
    this.autoOn = autoOn;
    this.autoOff = autoOff;
    this.selectable = selectable;
    shapes = new ArrayList<ICadComponent>();
  }

  public boolean remove(CadShape shape) {
    return shapes.remove(shape);
  }
  public long getId() { return id;}

  public boolean setOrder(CadShape shape, int dir) {
  	int index = shapes.indexOf(shape);

  	if (dir == -1 && index == 0) return false;
  	if (dir == 1 && index == shapes.size() - 1) return false;
  	
  	CadShape shape2 = (CadShape)shapes.get(index + dir);
  	shapes.set(index + dir, (ICadComponent) shape);
  	shapes.set(index, (ICadComponent) shape2);

  	return true;
  }
  public boolean setAutoOn(double autoOn) {
	if (this.autoOn == autoOn) 
		return false;
	this.autoOn = autoOn;
	return true;
  }
  public double getAutoOn() {
    return autoOn;
  }
  public boolean setAutoOff(double autoOff) {
	if (this.autoOff == autoOff) 
		return false;
	this.autoOff = autoOff;
	return true;
  }
  
  public double getAutoOff() {
    return autoOff;
  }

  public void setVisible(boolean visible) {
    this.visible = visible;
  }

  public boolean isVisible() {
    return visible;
  }

  public void setID(int id) {
    this.id = id;
  }

  public long getID() {
    return id;
  }

  public boolean setName(String name) {
	if (this.name.equals(name)) 
		return false;
	this.name = name;
	return true;
  }

  public String getName() {
    return name;
  }

//  public int getSelectionSize() {
//    return selection.size();
//  }

  public int getSize() {
    return shapes.size();
  }

  public void add(CadShape shape) {
    shapes.add((ICadComponent) shape);
  }

  public boolean select(ArrayList selection, long elemId) {
  	boolean changed = false;
  	CadShape shape = null;
    //long id = -1;

    int i = shapes.size() - 1;
    while (i > -1) {
    	shape = (CadShape) shapes.get(i--);
      if (shape.getId() == elemId) {
        if (selection.indexOf(shape) == -1) {
          shape.setSelected(true);
          selection.add(shape);
          changed = true;
        }
      }
    }
    return changed;
  }

  public CadShape select(long elemId) {
  	CadShape shape = null;

    int i = shapes.size() - 1;
    while (i > -1) {
      shape = (CadShape) shapes.get(i--);
      if (shape.getId() == elemId) {
          return shape;
      }
    }
    return null;
  }

  public boolean select(Point2D cp, CadView view, int modifiers) {
    ICadComponent ccomp = null;
    boolean changed = false;
    
    if (!isSelectable()) return false;
    
    switch (modifiers) {
      case (16): { // just a click
        view.selectedShapes.clear(); // clear everything and see what happens
        int i = shapes.size() - 1;
        while (i > -1) {
          ccomp = (ICadComponent)shapes.get(i--);
          if (ccomp.contains(cp, view)) {
          	 if (view.selectedShapes.indexOf(ccomp) == -1) {
          	 	view.selectedShapes.add((CadShape)ccomp);
          	 	changed = true;
          	 }
          }
        }
        break;
      } 
      case (17): { // shift-click
        int i = shapes.size() - 1;
        while (i > -1) {
          ccomp = (ICadComponent)shapes.get(i--);
          if (ccomp.contains(cp, view)) {
            if (view.selectedShapes.indexOf(ccomp) == -1) {
              view.selectedShapes.add((CadShape)ccomp);
              changed = true;
            }
          }
        }
        break;
      }
      case (18): { // ctrl-click
        int i = shapes.size() - 1;
        while (i > -1) {
          ccomp = (ICadComponent)shapes.get(i--);
          if (ccomp.contains(cp, view)) {
            if (view.selectedShapes.indexOf(ccomp) != -1) {
              view.selectedShapes.remove(ccomp);
              changed = true;
            }
          }
        }
        break;
      }
    }
    return changed;
  }

  public String toString() {
    return name;
  }

  public String toXML() {
	  String xml = "<layer>" +
	  					"<name>" + getName() + "</name>" +
	  					"<autoon>" + getAutoOn() + "</autoon>" +
	  					"<autooff>" + getAutoOff() + "</autooff>" +
	  					"<selectable>" + this.isSelectable() + "</selectable>" +
	  					"<shapes>";

						    Enumeration<ICadComponent> en = Collections.enumeration(shapes);
						    while (en.hasMoreElements()) {
						    	xml += ((ICadComponent) en.nextElement()).toXML();
						    }
	  return xml += "</shapes></layer>";
  }

  public void paint(Graphics2D g, CadCanvas canvas) {
  	int size = shapes.size();
    int k = 0;

    while (k < size) {
      ICadComponent cp = (ICadComponent) shapes.get(k);
      if (canvas.view.selectedShapes.indexOf(cp) == -1) {
      	cp.paint(g, canvas);    	
      }
      k++;
    }
  }

  public Object[][] toTableData() {
    Object[][] data = new Object[6][2];

    data[0][0] = "ID";
    data[0][1] = new Long(getId());
    data[1][0] = "Layer Name";
    data[1][1] = this.getName();
    data[2][0] = "Element Count";
    data[2][1] = new Integer(shapes.size());
    data[3][0] = "Auto On";
    data[3][1] = new Double(getAutoOn());
    data[4][0] = "Auto Off";
    data[4][1] = new Double(getAutoOff());
    data[5][0] = "Selectable";
    data[5][1] = Boolean.valueOf(isSelectable());

    return data;
  }
	public void setDataField(String label, Object value) {
  		if (label.equals("Layer Name")) {
			if (this.setName((String) value))
				GraphicsAction.fireGraphicsActionEvent(this, this, GraphicsAction.ELEM_MODIFIED);
  		} else if (label.equals("Auto On")) {
			if (setAutoOn(Double.parseDouble(value.toString())))
				GraphicsAction.fireGraphicsActionEvent(this, this, GraphicsAction.ELEM_MODIFIED);
		} else if (label.equals("Auto Off")) {
			if (setAutoOff(Double.parseDouble(value.toString())))
				GraphicsAction.fireGraphicsActionEvent(this, this, GraphicsAction.ELEM_MODIFIED);
		} else if (label.equals("Selectable")) {
			if (setSelectable(((Boolean)value).booleanValue()))
				GraphicsAction.fireGraphicsActionEvent(this, this, GraphicsAction.ELEM_MODIFIED);
  		}
	}
/**
 * @return Returns the selectable.
 */
	public boolean isSelectable() {
		return selectable;
	}
/**
 * @param selectable The selectable to set.
 */
	public boolean setSelectable(boolean value) {
		if (this.selectable == value)
			return false;
		this.selectable = value;
		return true;
	}
/**
 * @param id The id to set.
 */
	public void setId(long id) {
		this.id = id;
	}
}