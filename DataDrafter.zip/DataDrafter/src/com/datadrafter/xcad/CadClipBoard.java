package com.datadrafter.xcad;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
import java.util.ArrayList;
import java.util.Iterator;

public class CadClipBoard {
  private static ArrayList clipboard = new ArrayList();

  public CadClipBoard() {
  }

  public static void clear() {
  	clipboard.clear();
  }
  public static void add(ArrayList selectedShapes) {
  	Iterator iter = selectedShapes.iterator();
  	while (iter.hasNext()) {
  		ICadComponent comp = (ICadComponent)iter.next();
//  	    if (comp instanceof CadPolygon) {
//  	      CadPolygon poly = (CadPolygon) comp;
//  	      clipboard.add(CadPolygon.clone(poly));
//  	    }
//  	    if (comp instanceof CadItem) {
//  	      CadItem item = (CadItem) comp;
//  	      clipboard.add(CadItem.clone(item));
//		}
//  	    if (comp instanceof CadArc) {
//  	      CadArc arc = (CadArc) comp;
//  	      clipboard.add(CadArc.clone(arc));
//  	    }  		
  	}
  }
  public static int size() {
	  return clipboard.size();
  }
  public static ArrayList get() {
    return clipboard;
  }
}