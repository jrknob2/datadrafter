package com.datadrafter.xcad;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Arc2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Iterator;

import com.datadrafter.events.GraphicsAction;
import com.datadrafter.utils.Utils;

public class CadShape {

	public static final int LINE_SOLID = 0;
	public static final int LINE_DOTTED = 1;
	public static final int LINE_DASH = 2;
	public static final int LINE_CHAIN = 3;

	public static final int FILL_NONE = 0;
	public static final int FILL_SOLID = 1;
	public static final int FILL_GRADIENT = 2;

	public static final int CORNER_SQUARE   = 0;
	public static final int CORNER_ROUNDAED = 1;

	public static final int GRADIENT_CENTER      = 0;
	public static final int GRADIENT_LEFT        = 1;
	public static final int GRADIENT_RIGHT       = 2;
	public static final int GRADIENT_TOP         = 3;
	public static final int GRADIENT_BOTTOM      = 4;
	public static final int GRADIENT_TOPLEFT     = 5;
	public static final int GRADIENT_TOPRIGHT    = 6;
	public static final int GRADIENT_BOTTOMLEFT  = 7;
	public static final int GRADIENT_BOTTOMRIGHT = 8;

	public static final String[] lineStyles = { "SOLID", "DOTTED", "DASH", "CHAIN" };
	public static final String[] fillStyles = { "NO FILL", "SOLID", "GRADIENT" };
	public static final String[] arcClosures = { "CHORD", "OPEN", "PIE" };
	public static final String[] gradientDirections = { "CENTER", "LEFT", "RIGHT", "TOP", "BOTTOM", "TOP LEFT", "TOP RIGHT", "BOTTOM LEFT", "BOTTOM RIGHT"};
	
	private static float[] dotted_dash = new float[] { 1, 2, 1, 2 };
	private static float[] dashed_dash = new float[] { 6, 12, 6, 12 };
	private static float[] chained_dash = new float[] { 1, 12, 6, 12 };

	private static int cap = BasicStroke.CAP_SQUARE;
	private static int join = BasicStroke.JOIN_BEVEL;

	protected ArrayList<Point2D> vectors = new ArrayList<Point2D>();
	protected ArrayList<Arc2D> midPoints = new ArrayList<Arc2D>();
	
	protected Point2D selectedVector = null;
	protected Arc2D   selectedMidPoint = null;
	protected boolean mouseOver = false;

	protected CadDrawing drawing     = null;
	protected CadLayer   layer       = null;
	protected long       id          = -1;
	protected String     label       = null;
	protected int        color       = Color.BLACK.getRGB();
	protected int        style       = LINE_SOLID;
	protected double     width       = 1.0;
	protected int        fill        = 0;
	protected int        fillc       = 0;
	protected double     angle       = 0.0;
	
	protected Color bounds_color = Color.BLACK;
	protected Color vector_color = Color.YELLOW;
	protected Color selvec_color = Color.RED;
	protected Color default_color = Color.DARK_GRAY;
	
	protected int side = 6; // controls size of vector handles

	private float dash[] = { 4.0f, 2.0f };
	protected BasicStroke bounds_stroke = new BasicStroke(1.0f,
			BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, dash, 0.0f);

	protected boolean selected = false;
	//protected boolean mouseover = false;

	public CadShape() {
	}

	public ArrayList<Point2D> getVectors() {
		return vectors;
	}
	
	public String commonAttribsToXML() {
		return "<color>" + getColor() + "</color>" + 
		       "<style>" + getStyle() + "</style>" +
		       "<fill>" + getFill() + "</fill>" +
		       "<fillc>" + getFillColor() + "</fillc>" +
		       "<angle>" + getAngle() + "</angle>";		
	}
	
	public String vectorsToXML() {
		String xml = "<vectors>";
		Iterator iter = vectors.iterator();
		while (iter.hasNext()) {
			Point2D vector = (Point2D)iter.next();
			xml += "<vector>" +
						"<vectorx>" + vector.getX() + "</vectorx>" +
						"<vectory>" + vector.getY() + "</vectory>" +
					"</vector>";
		}
		return xml += "</vectors>";
	}
	public Point2D getSelectedVector() {
		return selectedVector;
	}

	public void setSelectedVector(Point2D selectedVector) {
		this.selectedVector = selectedVector;
	}

	public Point2D getVector(Point2D point, double scale) {
		Iterator iter = vectors.iterator();
		while (iter.hasNext()) {
			Point2D vec = (Point2D) iter.next();
			Rectangle2D vecrec = new Rectangle2D.Double((vec.getX()) - side / 2, (vec.getY()) - side / 2, side,	side);
			Point2D testp = new Point2D.Double(point.getX() / scale, point.getY()/ scale);
			if (vecrec.contains(testp)) {
				this.selectedVector = vec;
				return vec;
			}
		}
		Iterator iter2 = vectors.iterator();
		while (iter2.hasNext()) {
			Point2D vec = (Point2D)iter2.next();
			Rectangle2D vecrec = new Rectangle2D.Double((vec.getX()) - side / 2, (vec.getY()) - side / 2, side,	side);
			Point2D testp = new Point2D.Double(point.getX() / scale, point.getY()/ scale);
			if (vecrec.contains(testp)) {
				return vec;
			}
		}
		return null;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		// System.out.println("setting label-> " + label);
		this.label = label;
	}

	public boolean isMouseOver() {
		return mouseOver;
	}

	public void setMouseOver(boolean mouseover) {
		this.mouseOver = mouseover;
	}

	public boolean isSelected() {
		return this.selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	protected AlphaComposite makeComposite(float alpha) {
		int type = AlphaComposite.SRC_OVER;
		return (AlphaComposite.getInstance(type, alpha));
	}

	public static Point2D subtractPoints(Point2D p1, Point2D p2) {
		return new Point2D.Double(p1.getX() - p2.getX(), p1.getY() - p2.getY());
	}

	public void move(Point2D vector) {
		for (int i = 0; i < vectors.size(); i++) {
			vectors.set(i, CadShape.subtractPoints(vectors.get(i), vector));
		}
	}

	public static double distanceBetween(Point2D p1, Point2D p2) {
		Point2D p3 = subtractPoints(p1, p2);
		return Math.sqrt(p3.getX() * p3.getX() + p3.getY() * p3.getY());
	}

	public static Point2D getUnitVector(Point2D p1, Point2D p2) {
		double length = distanceBetween(p1, p2);
		return new Point2D.Double(p2.getX() / length, p2.getY() / length);
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

//	public Color getLineColor() {
//		return new Color(color);
//	}
	
	public int getFillColor() {
		return fillc;
	}

	public boolean isFilled() {
		return fill != 0 ? true : false;
	}
	public boolean setLineColor(int color) {
		if (this.color == color) return false;
		this.color = color;
		GraphicsAction.fireGraphicsActionEvent(this, this, GraphicsAction.ELEM_MODIFIED);
		return true;
	}

	public static BasicStroke getStroke(int style, double width) {
		BasicStroke stroke = null;
		switch (style) {
		case (0): { // solid
			stroke = new BasicStroke((int) width, cap, join);
			break;
		}
		case (1): { // dotted
			stroke = new BasicStroke((int) width, cap, join, 0, dotted_dash, 0);
			break;
		}
		case (2): { // dashed
			stroke = new BasicStroke((int) width, cap, join, 0, dashed_dash, 0);
			break;
		}
		case (3): { // chained
			stroke = new BasicStroke((int) width, cap, join, 0, chained_dash, 0);
			break;
		}
		}
		return stroke;
	}

	public static int getStyle(String value) {
		if (value.equals("SOLID")) {
			return 0;
		}
		else if (value.equals("DOTTED")) {
			return 1;
		}
		else if (value.equals("DASH")) {
			return 2;
		}
		else if (value.equals("CHAIN")) {
			return 3;
		}
		else {
			return -1;
		}
	}

	public boolean setStyle(String value) {
		if (value.equals("SOLID")) {
			return setStyle(0);
		} else if (value.equals("DOTTED")) {
			return setStyle(1);
		} else if (value.equals("DASH")) {
			return setStyle(2);
		} else if (value.equals("CHAIN")) {
			return setStyle(3);
		} else {
			return setStyle(-1);
		}
	}

	public int getFill() {
		return fill;
	}

	public String getFillType() {
		if (getFill() == 1) {
			return "SOLID";
		}
		if (getFill() == 2) {
			return "GRADIENT";
		}
		return "NO FILL";
	}

	public boolean setStyle(int style) {
		if (this.style == style)
			return false;

		this.style = style;
		return true;
	}

	public boolean setAngle(double angle) {
		if (this.angle == angle) {
			return false;
		}
		this.angle = angle;
		return true;
	}

	public double getAngle() {
		return angle;
	}

	public boolean setFill(int fill) {
		if (this.fill == fill) {
			return false;
		}
		this.fill = fill;
		return true;
	}

	public boolean setFillColor(int fillc) {
		if (this.fillc == fillc) {
			return false;
		}
		this.fillc = fillc;
		return true;
	}
		
	public void drawVectors(Graphics2D g2, CadView view) {
		Iterator iter = vectors.iterator();
		while (iter.hasNext()) {
			Point2D vec = (Point2D)iter.next();
			Rectangle2D vecrec = new Rectangle2D.Double(view.getViewPoint(vec).getX() - side / 2, view.getViewPoint(vec).getY() - side / 2, side, side);		
			g2.setColor(vec == getSelectedVector() ? selvec_color : vector_color);
			g2.fill(vecrec);
			g2.setColor(bounds_color);
			g2.draw(vecrec);	
		}
	}

	public void drawMidPoints(Graphics2D g2, CadView view, boolean closed) {
		if (vectors.size() < 2) return;
		
		midPoints.clear();
		
		Color orig_color = g2.getColor();
		
		Iterator iter = vectors.iterator();
		Point2D p1 = view.getViewPoint((Point2D)iter.next());
		Point2D first = p1;
		Point2D p2 = null;
		
		while (iter.hasNext()) {
			p2 = (Point2D)iter.next();
			p2 = view.getViewPoint(p2);
			Point2D midp = Utils.getMidPoint(p1, p2);
			Rectangle2D rec = new Rectangle2D.Double(midp.getX() - side / 2, midp.getY() - side / 2, side, side);
			Arc2D arc = new Arc2D.Double(rec, 0, 360.0, 1); 	
			p1 = p2;
			g2.setColor(Color.green);
			g2.fill(arc);
			g2.setColor(bounds_color);
			g2.draw(arc);
			midPoints.add(arc);
		}
		
		if (closed) {
			Point2D midp = Utils.getMidPoint(p2, first);
			Rectangle2D rec = new Rectangle2D.Double(midp.getX() - side / 2, midp.getY() - side / 2, side, side);
			Arc2D arc = new Arc2D.Double(rec, 0, 360.0, 1); 	
	
			g2.setColor(Color.green);
			g2.fill(arc);
			g2.setColor(bounds_color);
			g2.draw(arc);
			midPoints.add(arc);
		}
		
		g2.setColor(orig_color);
	}

	public CadDrawing getDrawing() {
		return drawing;
	}

	public void setDrawing(CadDrawing drawing) {
		this.drawing = drawing;
	}

	public CadLayer getLayer() {
		return layer;
	}

	public void setLayer(CadLayer layer) {
		this.layer = layer;
	}
	
	public int getColor() {
		return color;
	}

	public void setColor(int color) {
		this.color = color;
	}

	public int getFillc() {
		return fillc;
	}

	public void setFillc(int fillc) {
		this.fillc = fillc;
	}

	public double getWidth() {
		return width;
	}

	public boolean setWidth(double width) {
		if (this.width == width)
			return false;
		this.width = width;
		return true;
	}

	public int getStyle() {
		return style;
	}
}
