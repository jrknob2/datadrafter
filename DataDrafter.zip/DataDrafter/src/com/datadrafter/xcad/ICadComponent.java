package com.datadrafter.xcad;

import java.awt.Graphics;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.io.PrintWriter;

import com.datadrafter.xcad.CadView.CadCanvas;

public interface ICadComponent {
	public void setSelected(boolean selected);
	public boolean isSelected();
	public Shape getShape(CadView view);
	public boolean contains(Point2D point, CadView view);
	public void paint(Graphics g, CadCanvas canvas);
	public String toXML();
	public boolean setDataField(String label, Object value);
	public Object[][] toTableData();	
    public ICadComponent clone();
} 