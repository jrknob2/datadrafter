package com.datadrafter.xcad;

import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.PrintWriter;
import java.util.ArrayList;

import com.datadrafter.utils.Utils;
import com.datadrafter.xcad.CadView.CadCanvas;

public class CadLine extends CadShape implements ICadComponent {

	public CadLine() {
	}

	public CadLine(Point2D p1, Point2D p2) {
		vectors.add(0, p1);
		vectors.add(1, p2);		
	}

	public Shape getShape(CadView view) {
		double height = view.getViewPoint(vectors.get(1)).getY() - view.getViewPoint(vectors.get(0)).getY(); 
		double width  = view.getViewPoint(vectors.get(1)).getX() - view.getViewPoint(vectors.get(0)).getX();
		Line2D rec = new Line2D.Double(view.getViewPoint(vectors.get(0)), view.getViewPoint(vectors.get(1)));
		
		return rec;
	}
	
	public void paint(Graphics g, CadCanvas canvas) {
	    Graphics2D g2 = (Graphics2D)g;
	    Color orig_color = g2.getColor();
	    Stroke orig_stroke = g2.getStroke();
	    
	    if (isSelected()) {
	    	g2.setStroke(bounds_stroke);
	    	g2.setColor(bounds_color);
	    	g2.draw((getShape(canvas.view).getBounds()));
	    } else {
	    	g2.setColor(new Color(color));
	    }
	    
	    g2.setStroke(orig_stroke);	    
	    g2.setColor(default_color);
	    g2.draw((getShape(canvas.view)));
	    
	    if (!isSelected() && isMouseOver()) {
	    	Composite orig_comp = g2.getComposite();
	        g2.setComposite(makeComposite(0.5f));
	    	g2.fill(getShape(canvas.view));
	        g2.setComposite(orig_comp);	    	
	    }
	    
	    if (isSelected())
	    	drawVectors(g2, canvas.view);
	    
//	    if (getLabel() != null && getLabel().length() > 0 && overPoint != null) {
//			g2.setColor(Color.black);
//			Point2D point = new Point2D.Double(getShape(view).getBounds().getCenterX(),
//												getShape(view).getBounds().getCenterY());
//			g2.drawString(getLabel(), (int)overPoint.getX(), (int)overPoint.getY());
//	    }

//	    g2.setColor(orig_color);
//	    g2.setStroke(orig_stroke);

	}

	public boolean contains(Point2D point, CadView view) {
		Rectangle2D rec = new Rectangle2D.Double(point.getX() - 3, point.getY() - 3, 6, 6);
		return getShape(view).intersects(rec);
	}

	public String toXML() {	
		return "<line>" +
			   	  "<id>" + getId() + "</id>" +
			      commonAttribsToXML() +
			      vectorsToXML() +
			   "</line>";
	}

	public boolean setDataField(String label, Object value) {
	  	if (label.equals("Line Color")) {
	  		return setLineColor(((Color)value).getRGB()); 
	  	}
	  	if (label.equals("Line Width")) {
	  		return setWidth(Double.parseDouble((String)value));
	  	}
	  	return false;
	}

	public Object[][] toTableData() {
	    Object[][] data = new Object[1][2];

	    data[0][0] = "Element Type";
	    data[0][1] = "Line";

	    return data;
   }	

	public CadLine clone() {
	    CadLine clone = new CadLine();
	    clone.vectors = new ArrayList<Point2D>(vectors);
		clone.angle = angle;
		clone.bounds_color = bounds_color;
		clone.bounds_stroke = bounds_stroke;
		clone.color = color;
		clone.fill = fill;
		clone.fillc = fillc;
		clone.label = label;
		clone.id = Utils.getUniqueId();
		clone.style = style;
	    return clone;
	}
}