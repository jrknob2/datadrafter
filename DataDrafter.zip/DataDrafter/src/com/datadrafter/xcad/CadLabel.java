package com.datadrafter.xcad;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.io.PrintWriter;

import com.datadrafter.xcad.CadView.CadCanvas;

public class CadLabel extends CadShape implements ICadComponent {

	String  fontName = "System";
	String  text     = "New Label";
	boolean bold     = false;
	boolean italic   = false;
	int     fontSize = 12;
	
	public CadLabel() {		
	}
	
	public String getFontName() {
		return fontName;
	}

	public void setFontName(String fontName) {
		this.fontName = fontName;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	public boolean isBold() {
		return bold;
	}

	public void setBold(boolean bold) {
		this.bold = bold;
	}

	public boolean isItalic() {
		return italic;
	}

	public void setItalic(boolean italic) {
		this.italic = italic;
	}

	public int getFontSize() {
		return fontSize;
	}

	public void setFontSize(int fontSize) {
		this.fontSize = fontSize;
	}

	public boolean setDataField(String label, Object value) {
	  	if (label.equals("Line Color")) {
	  		return setLineColor(((Color)value).getRGB()); 
	  	}
	  	if (label.equals("Line Width")) {
	  		return setWidth(Double.parseDouble((String)value));
	  	}
	  	return false;
	}

	public Object[][] toTableData() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean contains(Point2D point, CadView view) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Shape getShape(CadView view) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void paint(Graphics g, CadCanvas canvas) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String toXML() {
		// TODO Auto-generated method stub
		return "<label>" +
			   		vectorsToXML() +
			   "</label>";
	}
	
	public CadLabel clone(){
		return new CadLabel(); //TODO implement clone in CadLabel
	}
}
