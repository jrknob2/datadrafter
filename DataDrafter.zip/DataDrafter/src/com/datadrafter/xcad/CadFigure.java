package com.datadrafter.xcad;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.io.PrintWriter;

import com.datadrafter.xcad.CadView.CadCanvas;

public class CadFigure extends CadShape implements ICadComponent {

	private long   elemId = -1;
	private long   drawingId = -1;
	private double scale = 1.0;
 
	public CadFigure() {		
	}
	
	public CadFigure(long elemId, Point2D cp, long drawingId) {
		this.elemId = elemId;
		this.vectors.add(cp);
		this.drawingId = drawingId;
	}

	public void setDrawingId(long drawingId) {
		this.drawingId = drawingId;
	}
	
	public long getDrawingId() {
		return drawingId;
	}

	public void setScale(double scale) {
		this.scale = scale;
	}
	
	public double getScale() {
		return scale;
	}

	public boolean setDataField(String label, Object value) {
	  	if (label.equals("Line Color")) {
	  		return setLineColor(((Color)value).getRGB()); 
	  	}
	  	if (label.equals("Line Width")) {
	  		return setWidth(Double.parseDouble((String)value));
	  	}
	  	return false;
	}

	public Object[][] toTableData() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean contains(Point2D point, CadView view) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Shape getShape(CadView view) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void paint(Graphics g, CadCanvas canvas) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String toXML() {
		// TODO Auto-generated method stub
		return "<figure>" +
				vectorsToXML() +
				"</figure>";
	}
	
	@Override
	public CadFigure clone() {
		return new CadFigure();
	}
	
}
