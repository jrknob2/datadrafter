package com.datadrafter.xcad;

import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.GeneralPath;
import java.awt.geom.Point2D;
import java.io.PrintWriter;
import java.util.ArrayList;

import com.datadrafter.utils.Utils;
import com.datadrafter.xcad.CadView.CadCanvas;

public class CadPolygon extends CadShape implements ICadComponent {

	public CadPolygon() {
	}

	public CadPolygon(ArrayList vectors) {
		this.vectors = vectors;
	}

	public Shape getShape(CadView view) {
		// draw GeneralPath (polygon)
		GeneralPath polygon = new GeneralPath(GeneralPath.WIND_EVEN_ODD, vectors.size());

		polygon.moveTo(view.getViewPoint(vectors.get(0)).getX(), view.getViewPoint(vectors.get(0)).getY());

		for (int index = 1; index < vectors.size(); index++) {
			polygon.lineTo(view.getViewPoint(vectors.get(index)).getX(), view.getViewPoint(vectors.get(index)).getY());
		}

		polygon.closePath();
		return polygon;
	}

	public void paint(Graphics g, CadCanvas canvas) {
		Graphics2D g2 = (Graphics2D)g;
		Stroke orig_stroke = g2.getStroke();
		Shape shape = getShape(canvas.view);
		
		if (isSelected()) {
			g2.setStroke(bounds_stroke);
			g2.setColor(bounds_color);
			g2.draw((shape.getBounds()));
		}

		if (isFilled()) {
			g2.setColor(new Color(getFillColor()));
			g2.fill(shape);
		}

		if (!isSelected() && isMouseOver()) {
			// TODO: get inverse color
			g2.setColor(Color.black);
			Composite orig_comp = g2.getComposite();
			g2.setComposite(makeComposite(0.5f));
			g2.fill(shape);
			g2.setComposite(orig_comp);
		}

		g2.setStroke(orig_stroke);
		g2.setColor(new Color(getColor()));
		g2.draw(shape);
		
		if (isSelected()) {
			drawVectors(g2, canvas.view);
			drawMidPoints(g2, canvas.view, true);
		}
	}

	public boolean contains(Point2D point, CadView view) {
		return getShape(view).contains(point);
	}

	public String toXML() {	
		return "<polygon>" +
			   	  "<id>" + getId() + "</id>" +
			      commonAttribsToXML() +
			      vectorsToXML() +
			   "</polygon>";
	}
	
	public boolean setDataField(String label, Object value) {
	  	if (label.equals("Line Color")) {
	  		return setLineColor(((Color)value).getRGB()); 
	  	}
	  	return false;
	}
	
	public Object[][] toTableData() {
	    Object[][] data = new Object[2][2];

	    data[0][0] = "Element Type";
	    data[0][1] = "Polygon";
	    data[1][0] = "Line Color";
	    data[1][1] = new Color(getColor());
	    
	    return data;
   }
	
	public CadLine clone() {
	    CadLine clone = new CadLine();
	    clone.vectors = new ArrayList<Point2D>(vectors);
		clone.angle = angle;
		clone.bounds_color = bounds_color;
		clone.bounds_stroke = bounds_stroke;
		clone.color = color;
		clone.fill = fill;
		clone.fillc = fillc;
		clone.label = label;
		clone.id = Utils.getUniqueId();
		clone.style = style;
	    return clone;
	}		
}