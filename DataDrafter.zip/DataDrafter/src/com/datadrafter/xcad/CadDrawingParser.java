package com.datadrafter.xcad;

import java.awt.geom.Point2D;
import java.io.IOException;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

public class CadDrawingParser {

	public static final int DRAWING     = 0;
	public static final int SAVEDVIEW   = 1;
	public static final int LAYER       = 2;
	public static final int RECTANGLE   = 3;
	public static final int POLYGON     = 4;
	public static final int ARC         = 5;
	public static final int LINE        = 6;
	public static final int FIGURE      = 7;
	public static final int LABEL       = 8;
	public static final int LINESEGMENT = 9;
	public static final int ID          = 10;
	public static final int VERSION     = 11;
	public static final int EDITION     = 12;
	public static final int TITLE       = 13;
	public static final int BCKIMG      = 14;
	public static final int BGCOLOR     = 15;
	public static final int UOMTYPE     = 16;
	public static final int UOMBASE     = 17;
	public static final int UOMSIZE     = 18;
	public static final int NAME        = 19;
	public static final int HEIGHT      = 21;
	public static final int WIDTH       = 22;
	public static final int SCALE       = 23;
	public static final int COLOR       = 28;
	public static final int STYLE       = 30;
	public static final int ANGLE       = 31;
	public static final int FILL        = 32;
	public static final int FILLC       = 33;
	public static final int VECTORX     = 34;
	public static final int VECTORY     = 35;
	public static final int STARTANGLE  = 44;
	public static final int ENDANGLE    = 45;
	public static final int CLOSURE     = 46;
	public static final int TEXT        = 49;
	public static final int FONTNAME    = 50;
	public static final int FONTSIZE    = 51;
	public static final int BOLD        = 52; 
	public static final int ITALIC      = 53;
	public static final int DRAWINGID   = 54;
	public static final int AUTOON      = 55;
	public static final int AUTOOFF     = 56;
	public static final int SELECTABLE  = 57;
	public static final int VHEIGHT     = 58;
	public static final int VWIDTH      = 59;
	public static final int QUADCURVE   = 60;
	public static final int CUBECURVE   = 61;
	public static final int VECTOR      = 62;
	
	CadDrawing drawing  = null;
	String     filename = null;

    public final static boolean debug;
	
    static
    {
/*        String strDebug = System.getProperty("DEBUG");
        if (strDebug == null)
            strDebug = System.getProperty("debug");

        if (strDebug != null && strDebug.equalsIgnoreCase("true"))
            debug = true;
        else
            debug = false; */
        debug = true; 
    }

    private XMLReader xmlreader;
    private DocHandler docHandler;

    class DocHandler implements org.xml.sax.ContentHandler
    {
        /** locator object from parser. */
        //private Locator loc;

        /** Vector of addresses. */
        //private Vector members = null;
        /** Current element parsed. */
        private int currentElement = -1;

        /** current Link Group */
        private CadLayer curr_layer = null;
        private CadShape curr_shape = null;
        
        private double	vectorx = -1;
        private double	vectory = -1;
        private Point2D	vector  = null;
        private String	buffer	= null;
        
        /** method of the DocumentHandler Interface. */
        public synchronized void characters(char[] ch, int start, int length)
        {
            buffer += new String(ch, start, length);
        }
        public void skippedEntity(String s) {
        }
        /** method of the DocumentHandler Interface. */
        public void startDocument()
        {
            // Receive notification of the beginning of the document.
            if (debug) System.out.println("Called startDocument()");
        }

        /** method of the DocumentHandler Interface. */
        public void endDocument()
        {
            // Receive notification of the end of the document.
            if (debug) System.out.println("Called endDocument()");
        }

        /** method of the DocumentHandler Interface. */
        public void startElement(String namespaceURI, String localName, String qName, Attributes atts)
        {
            // Receive notification of the start of an element.
            //if (debug) System.out.println("Called startElement(name:" + localName + ")");

        	buffer = new String();
        	
        	if (localName.toUpperCase().equals("DRAWING")) {
        		drawing = new CadDrawing();
        		curr_shape = null;
        	} else if (localName.toUpperCase().equals("LAYER")) {
        		curr_layer = new CadLayer(drawing);
        		currentElement = -1;            
        	} else if (localName.toUpperCase().equals("ARC")) {
            	currentElement = ARC;
            	curr_shape = new CadArc();
    		} else if (localName.toUpperCase().equals("LINE")) {
    			currentElement = LINE;
    			curr_shape = new CadLine();
			} else if (localName.toUpperCase().equals("POLYGON")) {
				currentElement = POLYGON;
                curr_shape = new CadPolygon();
			} else if (localName.toUpperCase().equals("RECTANGLE")) {
				currentElement = RECTANGLE;
                curr_shape = new CadRectangle();
			} else if (localName.toUpperCase().equals("LABEL")) {
				currentElement = LABEL;
                curr_shape = new CadLabel();
			} else if (localName.toUpperCase().equals("QUADCURVE")) {
				currentElement = QUADCURVE;
                curr_shape = new CadQuadCurve(); 
			} else if (localName.toUpperCase().equals("CUBECURVE")) {
				currentElement = CUBECURVE;
                curr_shape = new CadCubicCurve(); 
			} else if (localName.toUpperCase().equals("ID")) {
				currentElement = ID;
			} else if (localName.toUpperCase().equals("VERSION")) {
				currentElement = VERSION;
			} else if (localName.toUpperCase().equals("TITLE")) {
				currentElement = TITLE;
			} else if (localName.toUpperCase().equals("BCKIMG")) {
				currentElement = BCKIMG;
			} else if (localName.toUpperCase().equals("BGCOLOR")) {
				currentElement = BGCOLOR;
			} else if (localName.toUpperCase().equals("UOMTYPE")) {
				currentElement = UOMTYPE;
			} else if (localName.toUpperCase().equals("UOMBASE")) {
				currentElement = UOMBASE;
			} else if (localName.toUpperCase().equals("UOMSIZE")) {
				currentElement = UOMSIZE;
			} else if (localName.toUpperCase().equals("NAME")) {
				currentElement = NAME;
			} else if (localName.toUpperCase().equals("WIDTH")) {
				currentElement = WIDTH;
			} else if (localName.toUpperCase().equals("SCALE")) {
				currentElement = SCALE;
			} else if (localName.toUpperCase().equals("COLOR")) {
				currentElement = COLOR;
			} else if (localName.toUpperCase().equals("STYLE")) {
				currentElement = STYLE;
			} else if (localName.toUpperCase().equals("ANGLE")) {
				currentElement = ANGLE;
			} else if (localName.toUpperCase().equals("FILL")) {
				currentElement = FILL;
			} else if (localName.toUpperCase().equals("FILLC")) {
				currentElement = FILLC;
			} else if (localName.toUpperCase().equals("VECTOR")) {
				currentElement = VECTOR;
				vector = new Point2D.Double(0, 0);
			} else if (localName.toUpperCase().equals("VECTORX")) {
				currentElement = VECTORX;
			} else if (localName.toUpperCase().equals("VECTORY")) {
				currentElement = VECTORY;
			} else if (localName.toUpperCase().equals("STARTANGLE")) {
				currentElement = STARTANGLE;
			} else if (localName.toUpperCase().equals("ENDANGLE")) {
				currentElement = ENDANGLE;
			} else if (localName.toUpperCase().equals("CLOSURE")) {
				currentElement = CLOSURE;
			} else if (localName.toUpperCase().equals("TEXT")) {
				currentElement = TEXT;
			} else if (localName.toUpperCase().equals("FONTNAME")) {
				currentElement = FONTNAME;
			} else if (localName.toUpperCase().equals("FONTSIZE")) {
				currentElement = FONTSIZE;
			} else if (localName.toUpperCase().equals("BOLD")) {
				currentElement = BOLD;
			} else if (localName.toUpperCase().equals("ITALIC")) {
				currentElement = ITALIC;
			} else if (localName.toUpperCase().equals("DRAWINGID")) {
				currentElement = DRAWINGID;
			} else if (localName.toUpperCase().equals("AUTOON")) {
				currentElement = AUTOON;
			} else if (localName.toUpperCase().equals("AUTOOFF")) {
				currentElement = AUTOOFF;
			} else if (localName.toUpperCase().equals("SELECTABLE")) {
				currentElement = SELECTABLE;				
			} else {
				currentElement = -1;
			}            
        }

        /** method of the DocumentHandler Interface. */
        public void endElement(String namespaceURI, String localName, String qName)
        {
            // Receive notification of the end of an element.
            //if (debug) System.out.println("Called endElement(name: " + localName + ")");

        	switch (currentElement) {
        		case (DRAWING) : {
        			drawing.setClean(true);
        		}
            	case (TITLE) : {
            		drawing.setTitle(buffer);
            		break;
            	}
            	case (VERSION) : {
            		drawing.setVersion(buffer);
            		break;
            	}
            	case (LAYER) : {
            		drawing.addLayer(curr_layer);
            		break;
            	}
            	case (RECTANGLE) : {
            		curr_layer.add(curr_shape);
            		break;
            	}
            	case (POLYGON) : {
            		curr_layer.add(curr_shape);
            		break;
            	}
            	case (ARC) : {
            		curr_layer.add(curr_shape);
            		break;
            	}
            	case (LINE) : {
            		curr_layer.add(curr_shape);
            		break;
            	}
            	case (FIGURE) : {
            		curr_layer.add(curr_shape);
            		break;
            	}
            	case (LABEL) : {
            		curr_layer.add(curr_shape);
            		break;
            	}
            	case (ID) : {
            		if (curr_shape == null){
            			drawing.setId(Long.parseLong(buffer));
            		} else {
            			curr_shape.setId(Long.parseLong(buffer));
            		}
            		break;
            	}
            	case (BCKIMG) : {
            		drawing.setBackgroundImage(buffer);
            		break;
            	}
            	case (BGCOLOR) : {
            		drawing.setBackGroundColor(Integer.parseInt(buffer));
            		break;
            	}
            	case (UOMTYPE) : {
            		drawing.setUomStandard(buffer);
            		break;
            	}
            	case (UOMBASE) : {
            		drawing.setUomBase(buffer);
            		break;
            	}
            	case (UOMSIZE) : {
            		drawing.setUomSize(Integer.parseInt(buffer));
            		break;
            	}
            	case (NAME) : {
            		if (curr_layer != null) {
            			curr_layer.setName(buffer);
            		}
            		break;
            	}
            	case (DRAWINGID) : {
            		((CadFigure)curr_shape).setDrawingId(Long.parseLong(buffer));
            		break;
            	}
            	case (SCALE) : {
            		((CadFigure)curr_shape).setScale(Double.parseDouble(buffer));
            		break;
            	}
            	case (COLOR) : {
            		curr_shape.setLineColor(Integer.parseInt(buffer));
            		break;
            	}
            	case (STYLE) : {
            		curr_shape.setStyle(Integer.parseInt(buffer));
            		break;
            	}
            	case (ANGLE) : {
            		curr_shape.setAngle(Double.parseDouble(buffer));
            		break;
            	}
            	case (FILL) : {
            		curr_shape.setFill(Integer.parseInt(buffer));
            		break;
            	}
            	case (FILLC) : {
            		curr_shape.setFillColor(Integer.parseInt(buffer));
            		break;
            	}
            	case (VECTORX) : {
            		vectorx = Double.parseDouble(buffer);
            		break;
            	}
            	case (VECTORY) : {
            		vectory = Double.parseDouble(buffer);
            		vector.setLocation(vectorx, vectory);
            		
            		if (curr_shape instanceof CadPolygon) {
            			((CadPolygon)curr_shape).getVectors().add(vector);
            		}
            		if (curr_shape instanceof CadLine) {
            			((CadLine)curr_shape).getVectors().add(vector);
            		}
            		break;
            	}
            	case (STARTANGLE) : {
            		((CadArc)curr_shape).setStartAngle(Double.parseDouble(buffer));
            		break;            	
            	}
            	case (ENDANGLE) : {
            		((CadArc)curr_shape).setEndAngle(Double.parseDouble(buffer));
            		break;            	
            	}
            	case (CLOSURE) : {
            		((CadArc)curr_shape).setClosure(Integer.parseInt(buffer));
            		break;            	
            	}
            	case (TEXT) : {
            		((CadLabel)curr_shape).setText(buffer);
            		break;
            	}
            	case (FONTNAME) : {
            		((CadLabel)curr_shape).setFontName(buffer);
            		break;
            	}
            	case (FONTSIZE) : {
            		((CadLabel)curr_shape).setFontSize(Integer.parseInt(buffer));
            		break;
            	}
            	case (BOLD) : {
            		((CadLabel)curr_shape).setBold(Boolean.getBoolean(buffer));
            		break;
            	}
            	case (ITALIC) : {
            		((CadLabel)curr_shape).setItalic(Boolean.getBoolean(buffer));
            		break;            	
            	}
            	case (AUTOON) : {
            		curr_layer.setAutoOn(Double.parseDouble(buffer));
            		break;            	
            	}
            	case (AUTOOFF) : {
            		curr_layer.setAutoOff(Double.parseDouble(buffer));
            		break;            	
            	}
            	case (SELECTABLE) : {
            		curr_layer.setSelectable(Boolean.getBoolean(buffer));
            		break;            	
            	}	
        	}
        }

        /** method of the DocumentHandler Interface. */
        public void ignorableWhitespace(char[] ch, int start, int length)
        {
            // Receive notification of ignorable whitespace in element content.
//            if (debug) System.out.println("Called ignorableWhitespace(ch:"
//                                          + new String(ch,start,length) +
//                             ",start: " + start + ",length: " + length + ")");
        }

        /** method of the DocumentHandler Interface. */
        public void processingInstruction(java.lang.String target,
                                   java.lang.String data)
        {
            // Receive notification of a processing instruction.
            if (debug) System.out.println("Called processingInstruction(target:"
                                          + target + ",data:" + data + ")");
        }

        /** method of the DocumentHandler Interface. */
        public void setDocumentLocator(Locator locator)
        {
            // Receive a Locator object for document events.
            if (debug) System.out.println("Called setDocumentLocator()");
            //loc = locator;
        }
        public void endPrefixMapping(String prefix) {
        }
        public void startPrefixMapping(String prefix, String uri) {
        }
    }

    public CadDrawingParser(CadDrawing drawing) throws InstantiationException
    {
    	this.drawing = drawing;
    	
        try
        {
          xmlreader = XMLReaderFactory.createXMLReader("org.apache.xerces.parsers.SAXParser");
        } catch (Exception e)
          {
            if (e instanceof InstantiationException)
                throw (InstantiationException) e;
            else
                throw new InstantiationException("Reason:" + e.toString());
          }

        docHandler = new DocHandler();
        xmlreader.setContentHandler(docHandler);
        
    }

    /**
      * method to parse an abml file and return a Vector of Address objects.
      * @param is  org.xml.sax.InputSource.
      * @returns A Vector of sams.chp2.Address objects.
      */
    public void parse(InputSource is) throws SAXException, IOException
    {
          xmlreader.parse(is);
    }


//    /** main() method for unit testing. */
	public static void main(String[] args) {
		CadDrawing drawing = null;
		try
        {
            InputSource input_source = new InputSource("../personal/drawings/1186107090103.xml");
            CadDrawingParser parser = new CadDrawingParser(drawing);
            parser.parse(input_source);
        } catch (Throwable t)
          {
            t.printStackTrace();
          }
    }
}