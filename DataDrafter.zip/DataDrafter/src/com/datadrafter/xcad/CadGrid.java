package com.datadrafter.xcad;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;

import com.datadrafter.utils.Utils;
import com.datadrafter.xcad.CadView.CadCanvas;

public class CadGrid { //extends CadShape {

	private int size = 12;
	private int tick = 1;
	public BufferedImage buff_image = null;
	
    public CadGrid() {
    }

    public boolean setSize(int size) {
    	if (this.size == size) return false;
    	this.size = size;
    	buff_image = null;
    	return true;
    }
    
    public void drawGrid(CadCanvas canvas) {
 
	  Graphics2D g2d = (Graphics2D)canvas.view.getDrawing().buff_image.getGraphics(); 
		  
	  double sizeadj = 32 * canvas.view.getScale();
	  double xadj    = (canvas.view.getOrigin().getX() % sizeadj);
	  double yadj    = (canvas.view.getOrigin().getY() % sizeadj);
	
	  // new Color(Integer.parseInt(Utils.getProperty("grid_color"))));
	  
	  double width = canvas.getWidth() > 0 ? canvas.getWidth() : canvas.getPreferredSize().getWidth();
	  double height = canvas.getHeight() > 0 ? canvas.getHeight() : canvas.getPreferredSize().getHeight();
	  
	  if (buff_image == null){

		  buff_image   = new BufferedImage((int)width, (int)height, BufferedImage.TYPE_INT_RGB);
		  Graphics2D grid_g = (Graphics2D)buff_image.getGraphics();

		  grid_g.setXORMode(Color.WHITE);
		  grid_g.setColor(Color.black); 

		  Point2D start = new Point2D.Double(xadj, yadj);
		  Point2D end = new Point2D.Double(width, height); 
    
		  int i = tick;
		  
		  while (start.getX() < end.getX() || start.getY() < end.getY()) {
			  if (i++ == tick) {
				  grid_g.setStroke(CadShape.getStroke(CadShape.LINE_SOLID, 1));
				  i = 0;
			  } else {
				  grid_g.setStroke(CadShape.getStroke(CadShape.LINE_DOTTED, 1));      	
			  }
		  
			  Line2D vline = new Line2D.Double(start.getX(), 0, start.getX(), height);
			  Line2D hline = new Line2D.Double(0, start.getY(), width, start.getY());
      
			  grid_g.draw(vline);
			  grid_g.draw(hline);
			  start.setLocation(start.getX() + sizeadj, start.getY() + sizeadj);
		  }
	  }	  

	  AlphaComposite ac = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.1f);
	  g2d.setComposite(ac);

	  g2d.drawImage(buff_image, 0, 0, null);
	  
	  ac = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1.0f);
		  g2d.setComposite(ac);  
    }

    public Point2D snapToGrid(Point2D p, CadView view) {

    	double sizeadj = size * view.getScale();

    	double xadj    = (view.getOrigin().getX() % sizeadj);
    	double yadj    = (view.getOrigin().getY() % sizeadj);	

    	int xtimes = (int)(p.getX() / sizeadj);
    	int ytimes = (int)(p.getY() / sizeadj);
    
    	double xremain = p.getX() - ((xtimes * sizeadj) + (xadj * view.getScale()));
    	double yremain = p.getY() - ((ytimes * sizeadj) + (yadj * view.getScale()));
    
    	if (xremain > sizeadj / 2.0) ++xtimes;
    	if (yremain > sizeadj / 2.0) ++ytimes;

    	p.setLocation(Utils.getFormattedDouble(xtimes * sizeadj + xadj), 
    				  Utils.getFormattedDouble(ytimes * sizeadj + yadj));
    	return p;
    }
}