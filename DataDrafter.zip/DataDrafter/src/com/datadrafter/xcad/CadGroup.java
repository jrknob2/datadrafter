package com.datadrafter.xcad;

public class CadGroup {

}
