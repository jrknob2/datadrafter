package com.datadrafter.xcad;

import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Arc2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.PrintWriter;
import java.util.ArrayList;

import com.datadrafter.utils.Utils;
import com.datadrafter.xcad.CadView.CadCanvas;

public class CadArc extends CadShape implements ICadComponent {

	double startAngle = 0.0; 
	double endAngle   = 360.0;
	int    closure    = 0;
		
	public CadArc() {
	}

	public CadArc(Point2D p1, Point2D p2) {
		vectors.add(0, p1);
		vectors.add(1, p2);		
	}

	public Shape getShape(CadView view) {
		
		double minX = view.getViewPoint(vectors.get(0)).getX() < view.getViewPoint(vectors.get(1)).getX() ?
										view.getViewPoint(vectors.get(0)).getX() : view.getViewPoint(vectors.get(1)).getX();
		
		double maxX = view.getViewPoint(vectors.get(0)).getX() > view.getViewPoint(vectors.get(1)).getX() ?
										view.getViewPoint(vectors.get(0)).getX() : view.getViewPoint(vectors.get(1)).getX();
					  
		double minY = view.getViewPoint(vectors.get(0)).getY() < view.getViewPoint(vectors.get(1)).getY() ?
										view.getViewPoint(vectors.get(0)).getY() : view.getViewPoint(vectors.get(1)).getY();
					
		double maxY = view.getViewPoint(vectors.get(0)).getY() > view.getViewPoint(vectors.get(1)).getY() ?
										view.getViewPoint(vectors.get(0)).getY() : view.getViewPoint(vectors.get(1)).getY();

	    double width  = maxX - minX;
		double height = maxY - minY;
		
		Rectangle2D rec = new Rectangle2D.Double(minX, minY, width, height);
		Arc2D arc = new Arc2D.Double(rec, 0, 360.0, 1); 	

		return arc;
	}
	
	public void paint(Graphics g, CadCanvas canvas) {
		
	    Graphics2D g2 = (Graphics2D)g;
	    Stroke orig_stroke = g2.getStroke();
	    
	    if (isSelected()) {
	    	g2.setStroke(bounds_stroke);
	    	g2.setColor(bounds_color);
	    	g2.draw((getShape(canvas.view).getBounds()));
	    }
	    
	    g2.setStroke(orig_stroke);	    
	    g2.setColor(default_color);
	    g2.draw((getShape(canvas.view)));
	    
	    if (!isSelected() && isMouseOver()) {
	    	Composite orig_comp = g2.getComposite();
	        g2.setComposite(makeComposite(0.5f));
	    	g2.fill(getShape(canvas.view));
	        g2.setComposite(orig_comp);	    	
	    }
	    
	    if (isSelected())
	    	drawVectors(g2, canvas.view);
	    
	}

	public boolean contains(Point2D point, CadView view) {
		return getShape(view).contains(point);
	}

	public void toXML(PrintWriter out) {
		out.write(toXML());
	}
	
	public String toXML() {	
		return "<arc>" +
			   	  "<id>" + getId() + "</id>" +
			      "<startangle>" + getStartAngle() + "</startangle>" +
			      "<endangle>"   + getEndAngle() + "</endangle>" +
			      "<closure>"    + getClosure() + "</closure>" +
			      commonAttribsToXML() +
			      vectorsToXML() +
			  "</arc>";
	}
	
	public double getStartAngle() {
		return startAngle;
	}
	
	public void setStartAngle(double startAngle) {
		this.startAngle = startAngle;
	}

	public double getEndAngle() {
		return endAngle;
	}

	public void setEndAngle(double endAngle) {
		this.endAngle = endAngle;
	}

	public int getClosure() {
		return closure;
	}

	public void setClosure(int closure) {
		this.closure = closure;
	}
	
	public boolean setDataField(String label, Object value) {
	  	if (label.equals("Line Color")) {
	  		return setLineColor(((Color)value).getRGB()); 
	  	}
	  	if (label.equals("Line Width")) {
	  		return setWidth(Double.parseDouble((String)value));
	  	}
	  	return false;
	}

	public Object[][] toTableData() {
	    Object[][] data = new Object[1][2];

	    data[0][0] = "Element Type";
	    data[0][1] = "Arc";

	    return data;
   }

	@Override
	public CadArc clone() {
	    CadArc clone = new CadArc();
	    clone.vectors = new ArrayList<Point2D>(vectors);
		clone.endAngle = endAngle;
		clone.closure = closure;
		clone.angle = angle;
		clone.bounds_color = bounds_color;
		clone.bounds_stroke = bounds_stroke;
		clone.color = color;
		clone.fill = fill;
		clone.fillc = fillc;
		clone.label = label;
		clone.id = Utils.getUniqueId();
		clone.style = style;
	    return clone;
	}	
}