package com.datadrafter.xcad;

import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.GeneralPath;
import java.awt.geom.Point2D;
import java.io.PrintWriter;
import java.util.ArrayList;

import com.datadrafter.utils.Utils;
import com.datadrafter.xcad.CadView.CadCanvas;

public class CadPolyLine extends CadShape implements ICadComponent {

	public CadPolyLine() {
	}

	public CadPolyLine(ArrayList vectors) {
		this.vectors = vectors;
	}

	public Shape getShape(CadView view) {
		// draw GeneralPath (polygon)
		GeneralPath polyline = new GeneralPath(GeneralPath.WIND_EVEN_ODD, vectors.size());

		polyline.moveTo(view.getViewPoint(vectors.get(0)).getX(), view.getViewPoint(vectors.get(0)).getY());

		for (int index = 1; index < vectors.size(); index++) {
			polyline.lineTo(view.getViewPoint(vectors.get(index)).getX(), view.getViewPoint(vectors.get(index)).getY());
		}

		return polyline;
	}

	public void paint(Graphics g, CadCanvas canvas) {
		Graphics2D g2 = (Graphics2D)g;
		Stroke orig_stroke = g2.getStroke();

		if (isSelected()) {
			g2.setStroke(bounds_stroke);
			g2.setColor(bounds_color);
			g2.draw((getShape(canvas.view).getBounds()));
		}

		g2.setStroke(orig_stroke);
		g2.setColor(new Color(getColor()));
		g2.draw((getShape(canvas.view)));

		if (!isSelected() && isMouseOver()) {
			Composite orig_comp = g2.getComposite();
			g2.setComposite(makeComposite(0.5f));
			g2.fill(getShape(canvas.view));
			g2.setComposite(orig_comp);
		}

		if (isSelected()) {
			drawVectors(g2, canvas.view);
			drawMidPoints(g2, canvas.view, false);
		}
	}

	public boolean contains(Point2D point, CadView view) {
		return getShape(view).contains(point);
	}

	public String toXML() {	
		return "<polyline>" +
			   	  "<id>" + getId() + "</id>" +
			      commonAttribsToXML() +
			      vectorsToXML() +
			   "</polyline>";
	}

	public boolean setDataField(String label, Object value) {
	  	if (label.equals("Line sColor")) {
	  		return setLineColor(((Color)value).getRGB()); 
	  	}
	  	return false;
	}
	
	
	public Object[][] toTableData() {
	    Object[][] data = new Object[1][2];

	    data[0][0] = "Element Type";
	    data[0][1] = "PolyLine";

	    return data;
   }	

	public CadPolyLine clone() {
	    CadPolyLine clone = new CadPolyLine();
	    clone.vectors = new ArrayList<Point2D>(vectors);
		clone.angle = angle;
		clone.bounds_color = bounds_color;
		clone.bounds_stroke = bounds_stroke;
		clone.color = color;
		clone.fill = fill;
		clone.fillc = fillc;
		clone.label = label;
		clone.id = Utils.getUniqueId();
		clone.style = style;
	    return clone;
	}			
}