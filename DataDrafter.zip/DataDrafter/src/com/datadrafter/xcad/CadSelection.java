package com.datadrafter.xcad;

import java.awt.Color;
import java.util.Iterator;

import com.datadrafter.events.GraphicsAction;

public class CadSelection {

	CadView view = null;
	
	public CadSelection(CadView view) {
		this.view = view;
	}
	
	public void setDataField(String label, Object value) {
		boolean changed = false;
		if (label.equals("Color")) changed = setColor(((Color)value).getRGB());
	    //if (label.equals("Layer")) changed = setLayer(value);

	    if (changed) GraphicsAction.fireGraphicsActionEvent(this, this, GraphicsAction.ELEM_MODIFIED);
    }
	
	public boolean setColor(int rgb) {
		boolean changed = false;
		Iterator iter = view.selectedShapes.iterator();
		while (iter.hasNext()) {
			CadShape shape = (CadShape)iter.next();
			if (shape.setLineColor(rgb)) changed = true;
		}
		return changed;
	}
	
	public Object[][] toTableData() {
	    Object[][] data = new Object[3][2];

	    data[0][0] = "Element Type";
	    data[0][1] = "Selection";
	    data[1][0] = "Color";
	    data[1][1] = Color.white;
	    data[2][0] = "Layer";
	    data[2][1] = "";

	    return data;
   }	
	
}
