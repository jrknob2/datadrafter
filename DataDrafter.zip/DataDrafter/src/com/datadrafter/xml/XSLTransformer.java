package com.datadrafter.xml;

import java.io.StringWriter;

import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

public class XSLTransformer {

	public XSLTransformer () {
	}
	
	public static String transform(String xmlfile, String xslfile) {
		
		StringWriter buff = new StringWriter();
		
        Source xmlSource = new StreamSource(xmlfile);
        Source xsltSource = new StreamSource(xslfile);
        
        Result result = new StreamResult(buff);
 
        // create an instance of TransformerFactory
        TransformerFactory transFact = TransformerFactory.newInstance();
 
        try {
			Transformer trans = transFact.newTransformer(xsltSource);
			trans.transform(xmlSource, result);
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			return e.getMessage();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}

		return buff.toString();
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String html = XSLTransformer.transform("scripts/test2.xml", "scripts/test2.xsl");
		System.out.println(html);
	}

}
