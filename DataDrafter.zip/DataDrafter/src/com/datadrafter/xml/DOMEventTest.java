/*
 * Created on May 22, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.datadrafter.xml;

/**
 * @author Terry Knoblock
 *
 * @
 */
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Text;
import org.w3c.dom.events.EventListener;
import org.w3c.dom.events.EventTarget;
import org.w3c.dom.events.MutationEvent;

public class DOMEventTest 
		implements EventListener
{
		/**
		 * 
		 * @param args
		 * @throws Exception
		 */
		public static void main(String[] args)
				throws Exception
		{
				new DOMEventTest();
		}
        
		/**
		 * 
		 * @throws Exception
		 */
		public DOMEventTest()
				throws Exception
		{
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder = factory.newDocumentBuilder();
                
				// Initialize document
				Document doc = builder.newDocument();
				doc.appendChild(doc.createElement("a"));
                
				// Alternative 1: register event listener on the document itself
				((EventTarget) doc).addEventListener("DOMCharacterDataModified", this, 
true);
				((EventTarget) doc).addEventListener("DOMNodeInserted", this, true);
				((EventTarget) doc).addEventListener("DOMNodeInsertedIntoDocument", 
this, true);
                
				// Manipulate document
				manipulateDocument(doc);
                
				//System.out.println("\n----------\n");
                
				// Initialize document
				doc = builder.newDocument();
				doc.appendChild(doc.createElement("a"));
                
				// Alternative 2: register event listener on the document element
				Element elt = doc.getDocumentElement(); 
				((EventTarget) elt).addEventListener("DOMCharacterDataModified", this, true);
				((EventTarget) elt).addEventListener("DOMNodeInserted", this, true);
				((EventTarget) elt).addEventListener("DOMNodeInsertedIntoDocument", this, true);
                
				// Manipulate document
				manipulateDocument(doc);
                
				//System.out.println("\n----------\n");
                
				//OutputFormat format = new OutputFormat(doc);
				//XMLSerializer output = new XMLSerializer(System.out, format);
				//output.serialize(doc);
		}

		void manipulateDocument(Document doc)
		{
				Element elt = doc.getDocumentElement();
				
				elt.appendChild(doc.createTextNode("111"));
				Text txt = (Text) elt.appendChild(doc.createTextNode("222"));
				txt.setData("333");
				
                
				elt = doc.createElement("b");
				elt.appendChild(doc.createElement("c")).appendChild(doc.createTextNode("444"));
				doc.getDocumentElement().appendChild(elt);
		}

		/**
		 * 
		 */
		public void handleEvent(org.w3c.dom.events.Event inEvt)
		{
				if (!(inEvt instanceof MutationEvent))
						return;
				MutationEvent evt = (MutationEvent) inEvt;
                
				StringBuffer res = new StringBuffer();
				res.append("[" + evt.getType() + "]\n");

				res.append("  prevValue:" + evt.getPrevValue() + "\n");
				res.append("  newValue:" + evt.getNewValue() + "\n");
				Node targetNode = (Node) evt.getTarget();
				if (targetNode != null)
				{
						res.append("  targetNodeType:");
						switch (targetNode.getNodeType())
						{
								case Node.ELEMENT_NODE: res.append("ELEMENT_NODE"); 
break;
								case Node.ATTRIBUTE_NODE: 
res.append("ATTRIBUTE_NODE"); break;
								case Node.TEXT_NODE: res.append("TEXT_NODE"); break;
								default: res.append("##OTHER");
						}
						res.append("\n");
						res.append("  targetNodeName:" + targetNode.getNodeName() + 
"\n");
				}
				Node relatedNode = evt.getRelatedNode();
				if (relatedNode != null)
						res.append("  relatedNodeName:" + relatedNode.getNodeName() + 
"\n");

				System.out.print(res.toString());       
		}
}
