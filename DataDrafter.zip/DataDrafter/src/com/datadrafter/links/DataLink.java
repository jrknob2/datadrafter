package com.datadrafter.links;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Vector;

import com.datadrafter.events.LinkAction;
import com.datadrafter.modeler.Template;
import com.datadrafter.modeler.Templates;
import com.datadrafter.utils.Utils;

public class DataLink {
	private long id 		= -1;
	private long parentId 	= -1;
	private long groupId 	= -1;
	private String name 	= "";
	private long typeId 	= -1;
	private long elementId	= -1;
	private long drawingId	= -1;
	private String dtitle   = "";
	private long savedvwId	= -1;
	
	//private boolean clean 	= true;
	private Vector members 	= new Vector();

	public static final int ID 			= 1;
	public static final int NAME 		= 2;
	public static final int TYPEID 		= 3;
	public static final int GROUPID 	= 4;
	public static final int MEMBER 		= 5;
	public static final int PARENTID 	= 6;
	public static final int DRAWINGID 	= 7;
	public static final int ELEMENTID 	= 8;
	public static final int SAVED_VIEW 	= 9;
	
	public DataLink() {
    this.id = Utils.getUniqueId();
  }

  public DataLink(long id, long groupId, long parentId, String name) {
    this.id = id;
    this.groupId = groupId;
    this.parentId = parentId;
    this.name = name;
  }

//  public void setClean(boolean clean) {
//    this.clean = clean;
//  }

//  public boolean isClean() {
//    return clean;
//  }

  public long getId() {
    return id;
  }

  protected void setId(long id) {
    if (this.id == id) {
      return;
    }
    this.id = id;
    LinkAction.fireObjectActionEvent(this, LinkAction.LINK_UPDATED);
    //clean = false;
  }

  public long getGroupId() {
    return groupId;
  }

  public void setGroupId(long groupId) {
    if (this.groupId == groupId) {
      return;
    }
    this.groupId = groupId;
    LinkAction.fireObjectActionEvent(this, LinkAction.LINK_UPDATED);
    //clean = false;
  }

  public void setGroupId(LinkGroup group) {
    if (groupId == group.getId()) {
      return;
    }
    groupId = group.getId();
    LinkAction.fireObjectActionEvent(this, LinkAction.LINK_UPDATED);
    //clean = false;
  }

  public long getParentId() {
    return parentId;
  }

  public void setParentId(long parentId) {
    if (this.parentId == parentId) {
      return;
    }
    this.parentId = parentId;
    LinkAction.fireObjectActionEvent(this, LinkAction.LINK_UPDATED);
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    if (this.name.equals(name)) {
      return;
    }
    this.name = name;
    LinkAction.fireObjectActionEvent(this, LinkAction.LINK_UPDATED);
    //clean = false;
  }

  public long getTypeId() {
    return typeId;
  }

  public void setTypeId(long typeId) {
    if (this.typeId == typeId) {
      return;
    }
    this.typeId = typeId;
    LinkAction.fireObjectActionEvent(this, LinkAction.LINK_UPDATED);
    //clean = false;
  }

  public String toString() {
    return name;
  }

  public Vector getMembers() {
    return members;
  }

  public void addMember(long id) {
    members.add(new Long(id));
    LinkAction.fireObjectActionEvent(this, LinkAction.LINK_UPDATED);
    //clean = false;
  }

  public void removeMember(long id) {
    int num_mems = getMembers().size();
    int i;
    for (i = 0; i < num_mems; i++) {
      if ( ( (Long) getMembers().get(i)).longValue() == id) {
        getMembers().remove(i);
        LinkAction.fireObjectActionEvent(this, LinkAction.LINK_UPDATED);
        //clean = false;
        break;
      }
    }
  }

  public void toXML(PrintWriter out) {
    out.print(toXML());
  }
  public String toXML() {
    String xmlString = "    <link>\n" +
                       "      <id>" + getId() + "</id>\n" +
                       "      <groupid>" + getGroupId() + "</groupid>\n" +
                       "      <parentid>" + getParentId() + "</parentid>\n" +
					   "      <name>" + getName() + "</name>\n" +
					   "      <drawingid>" + getDrawingId() + "</drawingid>\n" +
					   "      <elementid>" + getElementId() + "</elementid>\n" +
					   "      <savedviewid>" + getSavedViewId() + "</savedviewid>\n" +					   
					   "      <type>" + getTypeId() + "</type>\n";
    
    Iterator iter = members.iterator();
    while (iter.hasNext()) {
      xmlString += "      <member>" + ((Long)iter.next()).longValue() + "</member>\n";
    }

    xmlString += "    </link>\n";
    return xmlString;
  }

  public String toHtmlTable() {
    String html = "<font face=Tahoma size=2>" + getName() + "</font>";

    html += "<table border=1 cellpadding=0 cellspacing=0 style=border-collapse: collapse" +
                 " bordercolor=#111111 width=100% id=AutoNumber1>";

    html +=  "<tr><th width=50% bgcolor=#C0C0C0><font face=Tahoma size=2>Property</font></th>";
    html +=  "<th width=50% bgcolor=#C0C0C0><font face=Tahoma size=2>Value</font></th></tr>";

    html += "<tr>";
    html += "  <td width=50% nowrap><font face=Tahoma size=2><b>Type</b></font></td>";
    html += "  <td width=50% nowrap><font face=Tahoma size=2>Data Link</font></td>";
    html += "</tr><tr>";

    html += "<tr>";
    html += "  <td width=50% nowrap><font face=Tahoma size=2><b>Id</b></font></td>";
    html += "  <td width=50% nowrap><font face=Tahoma size=2>";
    html +=       getId() + "</font></td>";
    html += "</tr><tr>";

    html += "<tr>";
    html += "<td width=50% nowrap><font face=Tahoma size=2><b>Name</b></font></td>";
    html += "<td width=50% nowrap><font face=Tahoma size=2>" + getName() + "</font></td>";
    html += "</tr><tr>";

    html += "<tr>";
    html += "<td width=50% nowrap><font face=Tahoma size=2><b>Group Id</b></font></td>";
    html += "<td width=50% nowrap><font face=Tahoma size=2>" + groupId + "</font></td>";
    html += "</tr><tr>";

    html += "<tr>";
    html += "<td width=50% nowrap><font face=Tahoma size=2><b>Parent Link Id</b></font></td>";
    html += "<td width=50% nowrap><font face=Tahoma size=2>" + parentId + "</font></td>";
    html += "</tr><tr>";

    html += "<tr>";
    html += "<td width=50% nowrap><font face=Tahoma size=2><b>Template</b></font></td>";
    html += "<td width=50% nowrap><font face=Tahoma size=2>" + ((getTypeId() == -1) ? "-1" :
        Templates.getDetailTemplate(getTypeId()).getName()) + "</font></td>";
    html += "</tr><tr>";


    Iterator iter = members.iterator();
    //int i = 7;
    while (iter.hasNext()) {
      Long id = (Long) iter.next();
      html += "<tr>";
      html += "<td width=50% nowrap><font face=Tahoma size=2><b>Member</b></font></td>";
      html += "<td width=50% nowrap><font face=Tahoma size=2>" + DataLinks.getDataLink(id.longValue()).getName() +
              "</font></td>";
      html += "</tr><tr>";
    }

    return html;
  }

  public boolean setDataField(String label, Object value) {
    if (label.equals("Name")) {
      setName(value.toString());
    }
    else if (label.equals("Template")) {
      if (value.equals("None")) {
        setTypeId( -1);
      }
      else {
        Template dt = (Template) value;
        setTypeId(dt.getId());
      }
    } 
    else if (label.equals("Element Id")) {
    	setElementId(new Long(value.toString()).longValue());
    } else if (label.equals("Drawing Id")) {
    	setDrawingId(new Long(value.toString()).longValue());
    }
    return true; //clean;
  }

  public Object[][] toTableData() {
  	//int i = 0;
  	 	
  	Object[][] data = new Object[9][2];

    data[0][0] = "Link Type";
    data[0][1] = "Data Link";
    data[1][0] = "Id";
    data[1][1] = new Long(getId());
    data[2][0] = "Group Id";
    data[2][1] = new Long(groupId);
    data[3][0] = "Parent Link Id";
    data[3][1] = new Long(parentId);
    data[4][0] = "Name";
    data[4][1] = getName();
    data[5][0] = "Template";
    data[5][1] = getTypeId() == -1 ? "None" : Templates.getDetailTemplate(getTypeId()).getName();
    data[6][0] = "Child Links";
    data[6][1] = new Integer(members.size());
    data[7][0] = "Drawing Id";
    data[7][1] = new Long(getDrawingId());
    data[8][0] = "Element Id";
    data[8][1] = new Long(getElementId());
        	
    return data;
  }
  
  public int indexOf(DataLink link) {
  	int index = 0;
  	Iterator iter = members.iterator();
  	while (iter.hasNext()) {
  		long id =  ((Long)iter.next()).longValue();
  		 if (id == link.getId()) return index;
  		 ++index;
  	}
  	return -1;
  }  
	/**
	 * @return Returns the drawingId.
	 */
	public long getDrawingId() {
		return drawingId;
	}
	/**
	 * @param drawingId The drawingId to set.
	 */
	public void setDrawingId(long drawingId) {
		this.drawingId = drawingId;
	}
	/**
	 * @return Returns the elementId.
	 */
	public long getElementId() {
		return elementId;
	}
	/**
	 * @param elementId The elementId to set.
	 */
	public void setElementId(long elementId) {
		this.elementId = elementId;
	}
	/**
	 * @return Returns the savedvwId.
	 */
	public long getSavedViewId() {
		return savedvwId;
	}
	/**
	 * @param savedvwId The savedvwId to set.
	 */
	public void setSavedViewId(long savedvwId) {
		this.savedvwId = savedvwId;
	}
	/**
	 * @return Returns the dtitle.
	 */
	public String getDtitle() {
		return dtitle;
	}
	/**
	 * @param dtitle The dtitle to set.
	 */
	public void setDtitle(String dtitle) {
		this.dtitle = dtitle;
	}
}
