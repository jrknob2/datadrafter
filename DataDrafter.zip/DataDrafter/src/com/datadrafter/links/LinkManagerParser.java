package com.datadrafter.links;

import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Vector;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

public class LinkManagerParser
{
    public final static boolean debug;
	private Vector groups = null;
	
    static
    {
/*        String strDebug = System.getProperty("DEBUG");
        if (strDebug == null)
            strDebug = System.getProperty("debug");

        if (strDebug != null && strDebug.equalsIgnoreCase("true"))
            debug = true;
        else
            debug = false; */
        debug = false; 
    }

    private XMLReader xmlreader;
    private DocHandler docHandler;

    class DocHandler implements org.xml.sax.ContentHandler
    {
        /** locator object from parser. */
        //private Locator loc;

        /** Vector of addresses. */
        //private Vector members = null;
        /** Current element parsed. */
        private int currentElement;

        /** current Link Group */
        private Object    curr_object    = null;
        private LinkGroup curr_linkgroup = null;
        private DataLink  curr_datalink  = null;
        private String    buffer         = null;
        
        /** method of the DocumentHandler Interface. */
        public synchronized void characters(char[] ch, int start, int length)
        {
            buffer += new String(ch, start, length);
        }
        public void skippedEntity(String s) {
        }
        /** method of the DocumentHandler Interface. */
        public void startDocument()
        {
            // Receive notification of the beginning of the document.
            if (debug) System.out.println("Called startDocument()");
        }

        /** method of the DocumentHandler Interface. */
        public void endDocument()
        {
            // Receive notification of the end of the document.
            if (debug) System.out.println("Called endDocument()");
        }

        /** method of the DocumentHandler Interface. */
        public void startElement(String namespaceURI, String localName, String qName, Attributes atts)
        {
            // Receive notification of the start of an element.
            //if (debug) System.out.println("Called startElement(name:" + localName + ")");

        	buffer = new String();
        	
            if (localName.toUpperCase().equals("LINKGROUP")) {
              curr_object = new LinkGroup();
              curr_linkgroup = (LinkGroup)curr_object;
              curr_datalink = null;
            } else if (localName.toUpperCase().equals("LINK")) {
              curr_object = new DataLink();
              curr_datalink = (DataLink)curr_object;
            }
            if (curr_object instanceof LinkGroup) {
              if (localName.toUpperCase().equals("ID"))
                currentElement = LinkGroup.ID;
              else if (localName.toUpperCase().equals("NAME"))
                currentElement = LinkGroup.NAME;
              else if (localName.toUpperCase().equals("DRAWINGID"))
                currentElement = LinkGroup.DRAWINGID;
              else if (localName.toUpperCase().equals("TYPE"))
                currentElement = LinkGroup.TYPEID;
			  else if (localName.toUpperCase().equals("MEMBER"))
			    currentElement = LinkGroup.MEMBER;
              else
                currentElement = -1;
            } else if (curr_object instanceof DataLink) {
              if (localName.toUpperCase().equals("ID"))
                currentElement = DataLink.ID;
              else if (localName.toUpperCase().equals("NAME"))
                currentElement = DataLink.NAME;
              else if (localName.toUpperCase().equals("TYPE"))
                currentElement = DataLink.TYPEID;
              else if (localName.toUpperCase().equals("GROUPID"))
                currentElement = DataLink.GROUPID;
              else if (localName.toUpperCase().equals("PARENTID"))
                currentElement = DataLink.PARENTID;
              else if (localName.toUpperCase().equals("MEMBER"))
			    currentElement = DataLink.MEMBER;
              else if (localName.toUpperCase().equals("DRAWINGID"))
			    currentElement = DataLink.DRAWINGID;
              else if (localName.toUpperCase().equals("ELEMENTID"))
			    currentElement = DataLink.ELEMENTID;
              else if (localName.toUpperCase().equals("SAVEDVIEWID"))
			    currentElement = DataLink.SAVED_VIEW;
              else
                currentElement = -1;
            } else {
              return;
            }
        }

        /** method of the DocumentHandler Interface. */
        public void endElement(String namespaceURI, String localName, String qName)
        {
            // Receive notification of the end of an element.
            //if (debug) System.out.println("Called endElement(name: " + localName + ")");
            if (curr_object instanceof LinkGroup) {
                switch (currentElement) {
                  case LinkGroup.ID:
                    curr_linkgroup.setId(Long.parseLong(buffer));
   				    currentElement = -1;
                    break;
                  case LinkGroup.NAME:
                    curr_linkgroup.setName(buffer);
  				  	currentElement = -1;
                    break;
                  case LinkGroup.DRAWINGID:
                    curr_linkgroup.setDrawingId(Long.parseLong(buffer));
  				  	currentElement = -1;
                    break;
                  case LinkGroup.TYPEID:
                    curr_linkgroup.setTypeId(Long.parseLong(buffer));
  				  	currentElement = -1;
                    break;
  				  case LinkGroup.MEMBER:
  					curr_linkgroup.addMember(Long.parseLong(buffer));
  				  	currentElement = -1;
  				  	break;
                }
            } else if (curr_object instanceof DataLink) {
                switch (currentElement) {
                  case DataLink.ID:
                  	curr_datalink.setId(Long.parseLong(buffer));
  				  	currentElement = -1;
                    break;
                  case DataLink.NAME:
                    curr_datalink.setName(buffer);
  				  	currentElement = -1;
                    break;
                  case DataLink.TYPEID:
                    curr_datalink.setTypeId(Long.parseLong(buffer));
                  	currentElement = -1;
                    break;
                  case DataLink.GROUPID:
                    curr_datalink.setGroupId(Long.parseLong(buffer));
  				  	currentElement = -1;
                    break;
                  case DataLink.PARENTID:
                    curr_datalink.setParentId(Long.parseLong(buffer));
    				currentElement = -1;
                    break;
                  case DataLink.DRAWINGID:
                    curr_datalink.setDrawingId(Long.parseLong(buffer));
  				    currentElement = -1;
                    break;
                  case DataLink.ELEMENTID:
                    curr_datalink.setElementId(Long.parseLong(buffer));
  				    currentElement = -1;
                  case DataLink.SAVED_VIEW:
                    curr_datalink.setSavedViewId(Long.parseLong(buffer));
  				    currentElement = -1;
  				    break;
                  case DataLink.MEMBER:
                    curr_datalink.addMember(Long.parseLong(buffer));
  				    currentElement = -1;
                    break;
                }
            }

            if (localName.toUpperCase().equals("LINKGROUP")) {
            	//curr_linkgroup.setClean(true);
            	groups.addElement(curr_linkgroup);
                curr_object = new LinkGroup();            	
            } else if (localName.toUpperCase().equals("LINK")) {
            	//curr_datalink.setClean(true);
            	curr_linkgroup.addLink(curr_datalink);
            	//curr_linkgroup.setClean(true);
                curr_object = new LinkGroup();            	
            }
        }

        /** method of the DocumentHandler Interface. */
        public void ignorableWhitespace(char[] ch, int start, int length)
        {
            // Receive notification of ignorable whitespace in element content.
//            if (debug) System.out.println("Called ignorableWhitespace(ch:"
//                                          + new String(ch,start,length) +
//                             ",start: " + start + ",length: " + length + ")");
        }

        /** method of the DocumentHandler Interface. */
        public void processingInstruction(java.lang.String target,
                                   java.lang.String data)
        {
            // Receive notification of a processing instruction.
            if (debug) System.out.println("Called processingInstruction(target:"
                                          + target + ",data:" + data + ")");
        }

        /** method of the DocumentHandler Interface. */
        public void setDocumentLocator(Locator locator)
        {
            // Receive a Locator object for document events.
            if (debug) System.out.println("Called setDocumentLocator()");
            //loc = locator;
        }
        public void endPrefixMapping(String prefix) {
        }
        public void startPrefixMapping(String prefix, String uri) {
        }
    }

    public LinkManagerParser(URL url, Vector groups) throws InstantiationException
    {
    	this.groups = groups;
    	
        try
        {
          xmlreader = XMLReaderFactory.createXMLReader("org.apache.xerces.parsers.SAXParser");
        } catch (Exception e)
          {
            if (e instanceof InstantiationException)
                throw (InstantiationException) e;
            else
                throw new InstantiationException("Reason:" + e.toString());
          }

        docHandler = new DocHandler();
        xmlreader.setContentHandler(docHandler);
        
		try {
			InputStream is = url.openStream();
			InputSource source = new InputSource(is);
			this.parse(source);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		}
    }

    public LinkManagerParser(String filename, Vector groups) throws InstantiationException
    {
    	this.groups = groups;
    	
        try
        {
          xmlreader = XMLReaderFactory.createXMLReader("org.apache.xerces.parsers.SAXParser");
        } catch (Exception e)
          {
            if (e instanceof InstantiationException)
                throw (InstantiationException) e;
            else
                throw new InstantiationException("Reason:" + e.toString());
          }

        docHandler = new DocHandler();
        xmlreader.setContentHandler(docHandler);
        
		try {
            InputSource input_source = new InputSource(filename);
			this.parse(input_source);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		}
    }

    /**
      * method to parse an abml file and return a Vector of Address objects.
      * @param is  org.xml.sax.InputSource.
      * @returns A Vector of sams.chp2.Address objects.
      */
    public void parse(InputSource is) throws SAXException, IOException
    {
          xmlreader.parse(is);
    }

	public void createLinksFile(String filename) {
		try {
			new FileWriter(filename, true);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

//    /** main() method for unit testing. */
//	public static void main(String[] args) {
//		Vector groups = new Vector();
//		try
//        {
//            LinkManagerParser parser = 
//            	new LinkManagerParser("c:/datadrafter/links.xml", groups);
////            File f = new File(args[0]);
//            //InputSource is = new InputSource("c:/datadrafter/data/links.xml");
//            //parser.parse(is);
//        } catch (Throwable t)
//          {
//            t.printStackTrace();
//          }
//    }
	
	
}

