package com.datadrafter.links;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import java.util.Vector;

import javax.swing.tree.DefaultMutableTreeNode;

import com.datadrafter.data.AttributeValue;
import com.datadrafter.data.AttributeValues;
import com.datadrafter.modeler.Attrib;
import com.datadrafter.modeler.Attribs;
import com.datadrafter.modeler.Detail;
import com.datadrafter.modeler.Details;
import com.datadrafter.modeler.Template;
import com.datadrafter.modeler.Templates;

public class SearchCriteria {
	  private Vector prevFound = new Vector();
	  private DefaultMutableTreeNode lastStart = null;
	  private long		linkId = -1;
	  private long 		elementId = -1;
	  private String 	link_name = "";
	  private long 		typeId = -1;
	  private long 		attribId = -1;
	  private long 		detailId = -1;
	  private String 	value = "";
	  
  public SearchCriteria() {
  }

  public Vector getPrevFound() {
    return prevFound;
  }

  public DefaultMutableTreeNode getLastStart() {
    return lastStart;
  }

  public void setLastStart(DefaultMutableTreeNode lastStart) {
    this.lastStart = lastStart;
  }

  public String getName() {
    return link_name;
  }

  public void setName(String name) {
    this.link_name = name;
  }

  public long getTypeId() {
    return typeId;
  }

  public void setTypeId(long typeId) {
    this.typeId = typeId;
  }

  public long getDetailId() {
    return detailId;
  }

  public void setDetailId(long detailId) {
    this.detailId = detailId;
  }

  public long getAttribId() {
    return attribId;
  }

  public void setAttribId(long attribId) {
    this.attribId = attribId;
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public void setLastStartNode(DefaultMutableTreeNode lastStart) {
    this.lastStart = lastStart;
  }

  public boolean match(DataLink link) {
    boolean type_match = false;
    //boolean detail_match = false;
    //boolean attrib_match = false;
    //boolean value_match = false;
    
    AttributeValues values = new AttributeValues(link);
    if (link.getElementId() != -1 && link.getElementId() == getElementId()) return true;

    if (getName().length() != 0) {
        if (link_name.equals(link.getName())) return true;
    }
    
    if (getLinkId() != -1) {
    	if (linkId == link.getId()) return true;
    }
    
    if (link.getTypeId() == -1) return false;
    
    if (typeId != -1) {
    	if (values.getTemplate().getId() == link.getTypeId()) {
    		type_match = true;
    		if (detailId == -1 && attribId == -1 && value.equals("")) { 
    			return type_match;
    		}
    	}
    }
    
    AttributeValue value = values.getValue(detailId, attribId);
    if (value == null) return false;
    
    if (this.value.equals(value.getValue())) return true;
    
    return false;
  }

  public void setDataField(String label, Object value) {
    if (label.equals("Node Name")) {
      this.setName(value.toString());
    }
    else if (label.equals("Template")) {
      if (value.equals("None")) {
        setTypeId( -1);
      }
      else {
        Template dt = (Template) value;
        setTypeId(dt.getId());
      }
    }
    else if (label.equals("Detail")) {
      if (value.equals("None")) {
        setDetailId( -1);
      }
      else {
        Detail ad = (Detail) value;
        setDetailId(ad.getId());
      }
    }
    else if (label.equals("Attribute")) {
      if (value.equals("None")) {
        setAttribId( -1);
      }
      else {
        Attrib attrib = (Attrib) value;
        setAttribId(attrib.getId());
      }
    }
    else if (label.equals("Attribute Value")) {
      setValue( (String) value);
    }
  }
  public String toHtmlTable() {
    String html = "";

    html = "<table border=1 cellpadding=0 cellspacing=0 style=border-collapse: collapse" +
                 " bordercolor=#111111 width=20% id=AutoNumber1>";

    html +=  "<tr><th width=50% bgcolor=#C0C0C0><font face=Tahoma size=2>Attribute</font></th>";
    html +=  "<th width=50% bgcolor=#C0C0C0><font face=Tahoma size=2>Value</font></th></tr>";

    html += "<tr>";
    html += "  <td width=50% nowrap><font face=Tahoma size=2><b>Node Name</b></font></td>";
    html += "  <td width=50%><font face=Tahoma size=2>";
    html += "     <input type=text name=T1 value=" + getName() + "></font></td>";
    html += "</tr><tr>";

    html += "<tr>";
    html += "<td width=50% nowrap><font face=Tahoma size=2><b>Template</b></font></td>";
    html += "<td width=50%><font face=Tahoma size=2>" +
             ((getTypeId() == -1) ? "None" : Templates.getDetailTemplate(getTypeId()).getName()) +
            "</font></td>";
    html += "</tr><tr>";

    html += "<tr>";
    html += "<td width=50% nowrap><font face=Tahoma size=2><b>Detail</b></font></td>";
    html += "<td width=50%><font face=Tahoma size=2>" +
              ((getDetailId() == -1) ? "None" : Details.getAttributeDetail(getDetailId()).getName()) +
                "</font></td>";
    html += "</tr><tr>";

    html += "<tr>";
    html += "<td width=50% nowrap><font face=Tahoma size=2><b>Attribute</b></font></td>";
            html += "<td width=50%><font face=Tahoma size=2>" +
                ((getAttribId() == -1) ? "None" : Attribs.getAttribute(getAttribId()).getName()) +
                        "</font></td>";
    html += "</tr><tr>";

    html += "<tr>";
    html += "<td width=50% nowrap><font face=Tahoma size=2><b>Total Found</b></font></td>";
            html += "<td width=50%><font face=Tahoma size=2>" +
                new Integer(prevFound.size()) +
                        "</font></td>";
    html += "</tr><tr>";

    html += "<tr>";
    html += "<td width=50% nowrap><font face=Tahoma size=2><b>Last Found</b></font></td>";
            html += "<td width=50%><font face=Tahoma size=2>" +
                (prevFound.size() == 0 ? "None" : ((DefaultMutableTreeNode)
                                                   prevFound.get(prevFound.size() - 1)).toString()) +
                        "</font></td>";
    html += "</tr><tr>";

    html += "<tr>";
    html += "<td width=50% nowrap><font face=Tahoma size=2><b>Search Root</b></font></td>";
            html += "<td width=50%><font face=Tahoma size=2>" +
                (lastStart == null ? "Not Set" : lastStart.toString()) +
                        "</font></td>";
    html += "</tr><tr>";

    html += "</tr></table>";
    return html;
  }
  public Object[][] toTableData() {
    Object[][] data = new Object[8][2];

    data[0][0] = "Node Name";
    data[0][1] = getName();
    data[1][0] = "Template";
    data[1][1] = (getTypeId() == -1) ? "None" :
        Templates.getDetailTemplate(getTypeId()).getName();
    data[2][0] = "Detail";
    data[2][1] = (getDetailId() == -1) ? "None" :
        Details.getAttributeDetail(getDetailId()).getName();
    data[3][0] = "Attribute";
    data[3][1] = (getAttribId() == -1) ? "None" :
        Attribs.getAttribute(getAttribId()).getName();
    data[4][0] = "Attribute Value";
    data[4][1] = value;
    data[5][0] = "Total Found";
    data[5][1] = new Integer(prevFound.size());
    data[6][0] = "Last Found";
    data[6][1] = prevFound.size() == 0 ? "None" :
        ((DefaultMutableTreeNode) prevFound.get(prevFound.size() - 1)).
        toString();
    data[7][0] = "Search Root";
    data[7][1] = lastStart == null ? "Not Set" : lastStart.toString();

    return data;
  }
  /**
   * @return Returns the elementId.
   */
  public long getElementId() {
	return elementId;
  }
  /**
   * @param elementId The elementId to set.
   */
  public void setElementId(long elementId) {
  	this.elementId = elementId;
  }

public long getLinkId() {
	return linkId;
}

public void setLinkId(long linkId) {
	this.linkId = linkId;
}
}
