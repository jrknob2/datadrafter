package com.datadrafter.links;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Iterator;
import java.util.Vector;

import com.datadrafter.modeler.Template;
import com.datadrafter.modeler.Templates;
import com.datadrafter.utils.Utils;

public class DataLinks { //implements ObjectActionListener {
  public static int LINKGROUP = 0;
  public static int DATALINK  = 1;
  
  long test;
  
  private static Vector groups = new Vector();
  private static Vector found = new Vector();
  
  //private static String filename;
  private static boolean clean = true;
  
  public DataLinks(URL url) {
	  load(url);  
  }
  public DataLinks(String filename) {
	//DataLinks.filename = filename;
    load(filename);
  }


  public static Vector getGroups() {
    return groups;
  }
  public static void removeGroup(LinkGroup group) {
    groups.remove(group);
	clean = false;
  }

  public static LinkGroup getGroup(long groupId) {
    for (int i = 0; i < groups.size(); i++) {
      LinkGroup group = (LinkGroup) groups.get(i);
      if (group.getId() == groupId) {
        return group;
      }
    }
    return null;
  }
  public static Vector getLinks(String groupId) {
	  LinkGroup group = DataLinks.getGroup(Long.parseLong(groupId));
	  if (group == null) return null;
	  return group.getMembers();
	  //return DataLinks.getGroup(Long.parseLong(groupId)).getLinks();
  }
  public static Vector getLinks(LinkGroup group) {
    return DataLinks.getGroup(group.getId()).getLinks();
  }

  public static void load(URL url) {
	  groups.clear();
	  try {
		  new LinkManagerParser(url, DataLinks.groups);
	  } catch (InstantiationException e) {
		  e.printStackTrace();
	  }
  }
  public static void load(String filename) {
	groups.clear();
	try {
		new LinkManagerParser(filename, DataLinks.groups);
	} catch (InstantiationException ie) {
		ie.printStackTrace();
	}
  }

  public static void addGroup(LinkGroup group) {
    groups.add(groups.size(), group);
    clean = 	false;
  }

  public static int getGroupIndex(LinkGroup group) {
    return groups.indexOf(group);
  }

  public static int getGroupIndex(DataLink link) {
    for (int i = 0; i < groups.size(); i++) {
      LinkGroup group = (LinkGroup) groups.get(i);
      if (group.getId() == link.getGroupId()) {
        return i;
      }
    }
    return -1;
  }

  public static boolean isClean() {
  	return clean;
//  	if (clean == false) return false;
//  	Iterator giter = groups.iterator();
//  	while (giter.hasNext()) {
//  		LinkGroup group = (LinkGroup)giter.next();
//  		if (group.isClean() == false) return false;
//  		Iterator liter = group.getLinks().iterator();
//  		while (liter.hasNext()) {
//  			DataLink link = (DataLink)liter.next();
//  			if (link.isClean() == false) return false;
//  		}
//  	}
//  	return true;
  }

  public static void setClean(boolean value) {
  	clean = value; 
//  	clean = true;
//  	Iterator giter = groups.iterator();
//  	while (giter.hasNext()) {
//  		LinkGroup group = (LinkGroup)giter.next();
//  		group.setClean(true);
//  		Iterator liter = group.getLinks().iterator();
//  		while (liter.hasNext()) {
//  			DataLink link = (DataLink)liter.next();
//  			link.setClean(true);
//  		}
//  	}
  }

  public static DataLink findLinkByName(String name, boolean reset) {
  	if (reset) found.clear();
    for (int i = 0; i < groups.size(); i++) {
      LinkGroup group = (LinkGroup) groups.get(i);
      Iterator iter = group.getLinks().iterator();
      while (iter.hasNext()) {
		DataLink link = (DataLink)iter.next();
      	if (link.getName() == name) {
      	  if (found.indexOf(link) == -1) {
      		found.add(link);
      	  }
  		  return link;
      	}
      }
    }
    return null;
  }
  public static DataLink getDataLink(long id) {
    for (int i = 0; i < groups.size(); i++) {
      LinkGroup group = (LinkGroup) groups.get(i);
      Iterator iter = group.getLinks().iterator();
      while (iter.hasNext()) {
		DataLink link = (DataLink)iter.next();
      	if (link.getId() == id) return link;
      }
    }
    return null;
  }

  public static void toXML() {
    PrintWriter out = null;
    String xmldoc = "";

    try {
      xmldoc = "<links>\n";

      int size = groups.size();
      for (int i = 0; i < size; ++i) {
        LinkGroup lg = (LinkGroup)groups.get(i);
        xmldoc += lg.toXML();
      }
      xmldoc += "</links>\n";

      out = new PrintWriter(new FileWriter(Utils.getProperty("datadrafter.config.links")));
      //System.out.println("writing-> " + Utils.home_dir + Utils.getProperty("datadrafter.config.links"));
      out.print(xmldoc);
      out.flush();
      DataLinks.setClean(true);
    }
    catch (IOException ioe) {
    	ioe.printStackTrace();
    }
    finally {
      if (out != null) out.close();
    }
  }

  public static Vector getAllDataTypes(LinkGroup group) {
  	//if (group == null || group.getMembers().size() == 0) return null;
  	Vector types = new Vector();
  	
  	Iterator iter = group.getMembers().iterator();
  	while (iter.hasNext()) {
        long mem_id = ((Long) iter.next()).longValue();
        DataLink member = DataLinks.getDataLink(mem_id);
        Vector temp = getAllDataTypes(member);
  		if (temp != null) {
  			Iterator iter2 = temp.iterator();
  			while (iter2.hasNext()) {
  				Template template = (Template)iter2.next();
  				types.add(template);
  			}
  		}
    }
    return types;
  }

  public static Vector getAllDataTypes(DataLink link) {
  	if (link.getMembers() == null) return null;
  	
  	Vector types = new Vector();

    Iterator iter = link.getMembers().iterator();
    while (iter.hasNext()) {
      long mem_id = ((Long) iter.next()).longValue();
      DataLink member = DataLinks.getDataLink(mem_id);
      if (member.getTypeId() != -1) {
        Template template = Templates.getDetailTemplate(member.getTypeId());
        if (template != null) {
          if (types.indexOf(template) == -1) {
            types.add(template);
          }
        }
      }

      if (member.getMembers().size() > 0) {
        Vector temp = getAllDataTypes(member);
        if (temp != null) {
          Iterator iter2 = temp.iterator();
          while (iter2.hasNext()) {
            Template templ = (Template) iter2.next();
            if (types.indexOf(templ) == -1) {
              types.add(templ);
            }
          }
        }
      }
    }
    if (types.size() > 0) {
      return types;
    }
    return null;
  }

  	private static void getLinkPathsByType(String path, String[][] paths, Template templ, DataLink link) {

  		if (path.length() == 0)
  			path = link.getName();
  		
  		//System.out.println("link-> " + link.getName());
  		if (link.getTypeId() == templ.getId()) {
  			String new_path = new String(path);
  			for (int i = 0; i < paths.length; ++i) {
  				if (paths[i][1] == null) {
  					paths[i][0] = String.valueOf(link.getId());
  					paths[i][1] = new_path;
  					break;
  				}
  			}
  		}
  		
  		Iterator iter = link.getMembers().iterator();
  		while (iter.hasNext()) {
  			long mem_id = ( (Long) iter.next()).longValue();
  			DataLink member = DataLinks.getDataLink(mem_id);
  			String temp_path = new String(path + "->" + member.getName());
			getLinkPathsByType(temp_path, paths, templ, member);
			
  		}
  	}
  	
  	private static void getLinkPathsByType(String path, String[][] paths, Template templ, LinkGroup link) {
  		
  		if (path.length() == 0)
  			path = link.getName();
  		
  		//System.out.println("link-> " + link.getName());
  		if (link.getTypeId() == templ.getId()) {
  			System.out.println("type match-> " + link.getName());  			
  			String new_path = new String(path);
  			for (int i = 0; i < paths.length; ++i) {
  				if (paths[i][1] == null) {
  					paths[i][0] = String.valueOf(link.getId());
  					paths[i][1] = new_path;
  					break;
  				}
  			}
  		}

  		Iterator iter = link.getMembers().iterator();
  		while (iter.hasNext()) {
  			long mem_id = ( (Long) iter.next()).longValue();
  			DataLink member = DataLinks.getDataLink(mem_id);
  			String temp_path = new String(path + "->" + member.getName());
			getLinkPathsByType(temp_path, paths, templ, member);
			
  		}
  	}

  	public static String[][] getLinkPathsByType(Template templ, DataLink link) {
	  String[][] paths = new String[getDataTypeCount(templ, link)][2];
	  String     path = "";
  
	  getLinkPathsByType(path, paths, templ, link);
	  return paths;	  
  }

  	public static String[][] getLinkPathsByType(Template templ, LinkGroup link) {
  	  String[][] paths = new String[getDataTypeCount(templ, link)][2];
  	  String     path = "";
  	  
  	  getLinkPathsByType(path, paths, templ, link);
  	  return paths;	  
    }
  	
  public static int getDataTypeCount(Template templ, DataLink link) {
    int count = 0;

    Iterator iter = link.getMembers().iterator();
    while (iter.hasNext()) {
      long mem_id = ( (Long) iter.next()).longValue();
      DataLink member = DataLinks.getDataLink(mem_id);

      if (member.getTypeId() != -1) {
        Template template = Templates.getDetailTemplate(member.getTypeId());
        if (template != null) {
          if (templ.equals(template)) ++count;
        }
      }

      if (member.getMembers().size() > 0) {
        count += getDataTypeCount(templ, member);
      }
    }
    return count;
  }

  public static int getDataTypeCount(Template templ, LinkGroup group) {
    int count = 0;

    Iterator iter = group.getMembers().iterator();
    while (iter.hasNext()) {
      long mem_id = ( (Long) iter.next()).longValue();
      DataLink member = DataLinks.getDataLink(mem_id);

      if (member.getTypeId() != -1) {
        Template template = Templates.getDetailTemplate(member.getTypeId());
        if (template != null) {
          if (templ.equals(template)) ++count;
        }
      }

      if (member.getMembers().size() > 0) {
        count += getDataTypeCount(templ, member);
      }
    }
    return count;
  }

  public static String getTypeList(String path, LinkGroup group, long typeId) {
  	String html = "";
  	Iterator iter = group.getMembers().iterator();
	while (iter.hasNext()) {
		  long mem_id = ((Long) iter.next()).longValue();
		  DataLink member = DataLinks.getDataLink(mem_id);

		  if (member.getTypeId() == typeId) {
			html += "<font face=Tahoma size=2><a href=javascript:listItemSelected(\"" + member.getId() + "\");>" + path + ">" + member.getName() + "</a></f><br>";
		  }
		  if (member.getMembers().size() > 0) {
			html += getTypeList(path + ">" + member.getName(), member, typeId);
		  }
		}
  	return html;
  }

  public static String getTypeList(String path, DataLink link, long typeId) {	
	String html = "";
	Iterator iter = link.getMembers().iterator();
	while (iter.hasNext()) {
	  long mem_id = ((Long) iter.next()).longValue();
	  DataLink member = DataLinks.getDataLink(mem_id);

	  if (member.getTypeId() == typeId) {
		html += "<font face=Tahoma size=2><a href=javascript:listItemSelected(\"" + member.getId() + "\");>" + path + ">" + member.getName() + "</a></f><br>";
	  }
	  if (member.getMembers().size() > 0) {
		html += getTypeList(path + ">" + member.getName(), member, typeId);
	  }
	}
	return html;
  }
  public static DataLink findLinkByElementId(long elementId) {
    for (int i = 0; i < groups.size(); i++) {
      LinkGroup group = (LinkGroup) groups.get(i);
      Iterator iter = group.getLinks().iterator();
      while (iter.hasNext()) {
		DataLink link = (DataLink)iter.next();
      	if (link.getElementId() == elementId) {
  		  return link;
      	}
      }
    }
    return null;
  }

//public static DataLink getByElementId(long elementId) {
//	Iterator iter = found.iterator();
//	while (iter.hasNext()) {
//	  DataLink link = (DataLink)iter.next();
//	  System.out.println("link-> " + link.getName());
//  	  if (link.getElementId() == elementId)
//		return link;
//	}
//	return null;
//  }
}