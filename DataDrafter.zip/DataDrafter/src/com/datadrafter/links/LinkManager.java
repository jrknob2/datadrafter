package com.datadrafter.links;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

import com.datadrafter.events.LinkAction;
import com.datadrafter.events.ObjectAction;
import com.datadrafter.reports.ReportArea;
import com.datadrafter.reports.StandardReports;
import com.datadrafter.tables.TableEditor;
import com.datadrafter.utils.Utils;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class LinkManager extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel header = new JLabel();
	JTabbedPane tab = new JTabbedPane();

	public	LinkGroup 		current_group 		= null;
	public	LinkTree 		current_tree 		= null;
	private	SearchCriteria 	criters				= null;

	public TableEditor searchTable = new TableEditor(new String[] {"Criteria", "Value"});
	public TableEditor linkTable   = new TableEditor(new String[] {"Property", "Value"});
	public TableEditor groupTable  = new TableEditor(new String[] {"Property", "Value"});

  	//TableEditor prefsTable  = new TableEditor(new String[] {"Preference", "Value"});
  	
	JPanel treePanel         	= new JPanel(new BorderLayout());
  	JPanel linkPanel         	= new JPanel(new BorderLayout());
  	JPanel searchPanel       	= new JPanel(new BorderLayout());
  	JPanel filterPanel       	= new JPanel(new BorderLayout());
  	JPanel groupPanel        	= new JPanel(new BorderLayout());
  	JPanel treeHeaderPanel   	= new JPanel(new BorderLayout());
  	JPanel editorHeaderPanel 	= new JPanel(new BorderLayout());
  	JPanel searchHeaderPanel 	= new JPanel(new BorderLayout());
  	JPanel filterHeaderPanel 	= new JPanel(new BorderLayout());
  	JPanel groupHeaderPanel  	= new JPanel(new BorderLayout());

  	JToolBar treeToolBar 		= new JToolBar(JToolBar.HORIZONTAL);
  	JToolBar editorToolBar 		= new JToolBar(JToolBar.HORIZONTAL);
  	JToolBar searchToolBar 		= new JToolBar(JToolBar.HORIZONTAL);
  	JToolBar groupToolBar 		= new JToolBar(JToolBar.HORIZONTAL);
  	JToolBar filterToolBar 		= new JToolBar(JToolBar.HORIZONTAL);

  	public JComboBox treeGroupSelection	= new JComboBox(DataLinks.getGroups());
  	public JComboBox editGroupSelection = new JComboBox(DataLinks.getGroups());

  	ClassLoader cl = this.getClass().getClassLoader();
  	ImageIcon editIcon     = new ImageIcon(cl.getResource("icons/Edit16.gif"));
  	ImageIcon newIcon      = new ImageIcon(cl.getResource("icons/New16.gif"));
  	ImageIcon saveIcon     = new ImageIcon(cl.getResource("icons/Save16.gif"));
  	ImageIcon deleteIcon   = new ImageIcon(cl.getResource("icons/Delete16.gif"));
  	ImageIcon findIcon     = new ImageIcon(cl.getResource("icons/Find16.gif"));
  	ImageIcon findNextIcon = new ImageIcon(cl.getResource("icons/FindAgain16.gif"));
  	ImageIcon prefIcon     = new ImageIcon(cl.getResource("icons/Properties16.gif"));
  	ImageIcon upIcon       = new ImageIcon(cl.getResource("icons/Up16.gif"));
  	ImageIcon downIcon     = new ImageIcon(cl.getResource("icons/Down16.gif"));
  	ImageIcon helpIcon	   = new ImageIcon(cl.getResource("icons/Help16.gif"));
  	
  	JButton newLinkButton         = new JButton(newIcon);
  	JButton saveLinksButton       = new JButton(saveIcon);
  	JToggleButton editLinkButton  = new JToggleButton(editIcon);
  	JButton deleteLinkButton      = new JButton(deleteIcon);
  	JButton findLinkButton        = new JButton(findIcon);
  	JButton findNextButton        = new JButton(findNextIcon);
  	JButton newGroupButton        = new JButton(newIcon);
  	JButton deleteGroupButton     = new JButton(deleteIcon);
  	//JButton reportButton          = new JButton(reportIcon);
  	JButton newSearchButton       = new JButton(newIcon);
  	JButton upButton              = new JButton(upIcon);
  	JButton downButton            = new JButton(downIcon);
  	JButton helpButton            = new JButton(helpIcon);
  
  	public LinkManager(DataLinks links) {
  		
  		setBorder(BorderFactory.createEmptyBorder());
  		setLayout(new BorderLayout());
  		
  		header.setFont(new java.awt.Font("Tahoma", 1, 11));
  		header.setBorder(BorderFactory.createEtchedBorder());
  		header.setHorizontalAlignment(SwingConstants.CENTER);
  		header.setText("Link Manager");

  		newLinkButton.setToolTipText("New Link");
  		saveLinksButton.setToolTipText("Save Links");
  		deleteLinkButton.setToolTipText("Delete Link");
  		//reportButton.setToolTipText("Summary Report");
  		editLinkButton.setToolTipText("Edit Link");
  		deleteGroupButton.setToolTipText("Delete Group");
  		newGroupButton.setToolTipText("New Group");
  		findLinkButton.setToolTipText("Find");
  		findNextButton.setToolTipText("Find Next");
  		newSearchButton.setToolTipText("New Search");
  		upButton.setToolTipText("Move Link Up");
  		downButton.setToolTipText("Move Link Down");
  		helpButton.setToolTipText("Learn how to use Link Manager`");
  		
  		newLinkButton.addActionListener(new java.awt.event.ActionListener() {
  			public void actionPerformed(ActionEvent e) {
  				Object user_obj = current_tree.getCurrentlySelectedNode().getUserObject();
  				if (user_obj == null) return;

  				if (user_obj instanceof LinkGroup) {
  					DataLink new_link = new DataLink(Utils.getUniqueId(),
							   current_group.getId(), 
							   -1, "New Link " +
							   (current_group.getMembers().size() + 1));
  					current_group.addLink(new_link);
  					current_group.addMember(new_link.getId());
  					DefaultMutableTreeNode node = current_tree.addObject(current_tree.
  							getCurrentlySelectedNode(), new_link, true);
  					TreePath tp = new TreePath(node.getPath());
  					current_tree.setPath(tp);
  				} else if (user_obj instanceof DataLink) {
  					DataLink curr_link = (DataLink)user_obj;
  					DataLink new_link = new DataLink(Utils.getUniqueId(),
										   current_group.getId(), 
										   curr_link.getId(), "New Link " + 
										   (curr_link.getMembers().size() + 1));
  					current_group.addLink(new_link);
  					curr_link.addMember(new_link.getId());
  					DefaultMutableTreeNode node = current_tree.addObject(current_tree.
  							getCurrentlySelectedNode(), new_link, true);
  					node.setUserObject(new_link);
  					TreePath tp = new TreePath(node.getPath());
  					current_tree.setPath(tp);
  				} else {
  					JOptionPane.showMessageDialog(null,
  							"Must create a link group first",
							"Link Error",
							JOptionPane.ERROR_MESSAGE);
  				}

  			}
  		});
  		
  		saveLinksButton.addActionListener(new java.awt.event.ActionListener() {
  			public void actionPerformed(ActionEvent e) {
  				DataLinks.toXML();
  			}
  		});
  		deleteLinkButton.addActionListener(new java.awt.event.ActionListener() {
  			public void actionPerformed(ActionEvent e) {
  				System.out.println("current_tree-> " + current_tree);
  				if (current_tree == null) {
  					return;
  				}
  				Object obj = current_tree.getCurrentlySelectedNode().getUserObject();
  				System.out.println("selectedNode-> " + obj);
  					if (obj == null || obj instanceof LinkGroup) {
  						return;
  					}
  					//DataLink link = (DataLink) obj;
  					current_tree.removeCurrentNode();
  			}
  		});
//    reportButton.addActionListener(new java.awt.event.ActionListener() {
//      public void actionPerformed(ActionEvent e) {
//        generateReport();
//      }
//    });
  		upButton.addActionListener(new java.awt.event.ActionListener() {
  			public void actionPerformed(ActionEvent e) {
  				current_tree.moveNodeUp();
  			}
  		});
  		downButton.addActionListener(new java.awt.event.ActionListener() {
  			public void actionPerformed(ActionEvent e) {
  				current_tree.moveNodeDown();
  			}
  		});
  		findLinkButton.addActionListener(new java.awt.event.ActionListener() {
  			public void actionPerformed(ActionEvent e) {
  				criters.getPrevFound().clear();
  				boolean found = current_tree.findNode(criters);
  				searchTable.setDataObject(criters, criters.toTableData());
  			}
  		});
	    findNextButton.addActionListener(new java.awt.event.ActionListener() {
	      public void actionPerformed(ActionEvent e) {
	        //boolean found = current_tree.findAgain(search_criteria);
	        searchTable.setDataObject(criters, criters.toTableData());
	      }
	    });
	    newSearchButton.addActionListener(new java.awt.event.ActionListener() {
	      public void actionPerformed(ActionEvent e) {
	        criters = new SearchCriteria();
	        criters.setLastStart(current_tree.getCurrentlySelectedNode());
	        searchTable.setDataObject(criters, criters.toTableData());
	      }
	    });
	    newGroupButton.addActionListener(new java.awt.event.ActionListener() {
	      public void actionPerformed(ActionEvent e) {
	        LinkGroup new_group = new LinkGroup(Utils.getUniqueId(), 
	        						"New Group " + (DataLinks.getGroups().size() + 1));
	        DataLinks.addGroup(new_group);
	        editGroupSelection.setSelectedItem(new_group);
			treeGroupSelection.setSelectedItem(new_group);
	        groupTable.setDataObject(new_group, new_group.toTableData());
	        treeGroupSelection.validate();
	      }
	    });
	    deleteGroupButton.addActionListener(new java.awt.event.ActionListener() {
	      public void actionPerformed(ActionEvent e) {
	        LinkGroup group = (LinkGroup) editGroupSelection.getSelectedItem();
	
			if (group.getMembers().size() > 0) {
	          JOptionPane.showMessageDialog(null,
	              "Must remove all links from the group first",
	              "Delete Error",
	              JOptionPane.ERROR_MESSAGE);
	          return;
	        }
			
			DataLinks.removeGroup(group);
	        if (editGroupSelection.getItemCount() > 0)
	       		editGroupSelection.setSelectedIndex(0);
	      }
	    });
	    editLinkButton.addActionListener(new java.awt.event.ActionListener() {
	      public void actionPerformed(ActionEvent e) {
	        if (editLinkButton.isSelected()) {
	          treePanel.remove(treeHeaderPanel);
	          treePanel.add(linkPanel, BorderLayout.CENTER);
	          treePanel.validate();
	          linkPanel.repaint();
	        }
	        else {
	          treePanel.remove(linkPanel);
	          treePanel.add(treeHeaderPanel, BorderLayout.CENTER);
	          treePanel.validate();
	          treePanel.repaint();
	        }
	      }
	    });
	    treeGroupSelection.setName("treeGroupSelection");
	    treeGroupSelection.addActionListener(new java.awt.event.ActionListener() {
	      public void actionPerformed(ActionEvent e) {
	        LinkGroup selected_group = (LinkGroup) treeGroupSelection.getSelectedItem();
	        if (selected_group == null || selected_group.equals(current_group)) {
	          return;
	        }
	        current_group = selected_group;
	        if (current_tree != null) {
	          current_tree.clear();
	          current_tree.reload(current_group);
	          //groupTable.setDataObject(current_group, current_group.toTableData());
	        
	          LinkAction.fireObjectActionEvent(treeGroupSelection, current_group, LinkAction.GROUP_SELECTED);        }
	      }
	    });
	    
	    editGroupSelection.addActionListener(new java.awt.event.ActionListener() {
	      public void actionPerformed(ActionEvent e) {
	        LinkGroup group = (LinkGroup) editGroupSelection.getSelectedItem();
	        if (current_group == null) return;
	        groupTable.setDataObject(group, group.toTableData());
	      }
	    });
    
	    helpButton.setFocusable(false);
	    
	    treeToolBar.setAutoscrolls(true);
	  	treeToolBar.setFloatable(false);
	    treeToolBar.add(saveLinksButton);
	    treeToolBar.add(newLinkButton);
	    treeToolBar.add(editLinkButton);
	    treeToolBar.add(deleteLinkButton);
	    treeToolBar.add(upButton);
	    treeToolBar.add(downButton);
	    treeToolBar.add(helpButton);
	    
	    groupToolBar.add(newGroupButton);
	    groupToolBar.add(deleteGroupButton);
	
	    if (DataLinks.getGroups().size() > 0) {
	    	current_group = (LinkGroup) treeGroupSelection.getItemAt(0); //.getSelectedItem();
	    	groupTable.setDataObject(current_group, current_group.toTableData());
	    	current_tree = new LinkTree(current_group);
	    }
	    criters = new SearchCriteria();
	    // search_criteria.setLastStart(current_tree.getCurrentlySelectedNode());
	    linkPanel.add(linkTable, BorderLayout.CENTER);
	
	    treeHeaderPanel.add(treeGroupSelection, BorderLayout.NORTH);
	    treeHeaderPanel.add(current_tree, BorderLayout.CENTER);
	
	    treePanel.setBorder(BorderFactory.createEmptyBorder());
	    treePanel.add(treeToolBar, BorderLayout.NORTH);
	    treePanel.add(treeHeaderPanel, BorderLayout.CENTER);
	
	    groupHeaderPanel.add(groupToolBar, BorderLayout.NORTH);
	    groupHeaderPanel.add(editGroupSelection, BorderLayout.SOUTH);
	    groupPanel.add(groupHeaderPanel, BorderLayout.NORTH);
	    groupPanel.add(groupTable, BorderLayout.CENTER);
	
	    searchPanel.add(searchToolBar, BorderLayout.NORTH);
	    searchPanel.add(searchTable, BorderLayout.CENTER);
	    searchTable.setDataObject(criters, criters.toTableData());
	
	    // prefsTable.setDataObject(preferences, preferences.toTableData());
	    // prefsPanel.add(prefsTable, BorderLayout.CENTER);
	    searchToolBar.add(findLinkButton);
	    searchToolBar.add(findNextButton);
	    searchToolBar.add(newSearchButton);
	
	    tab.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
	    tab.setBorder(BorderFactory.createEmptyBorder());
	    tab.add(treePanel, "Tree");
	    tab.add(groupPanel, "Groups");
	    tab.add(searchPanel, "Search");
	    // tab.add(filterPanel, "Filter");
	    // tab.add(prefsPanel, "Preferences");
	
	    tab.addChangeListener(new javax.swing.event.ChangeListener() {
	      public void stateChanged(ChangeEvent e) {
	        Utils.tabStateChanged(tab);
	      }
	    });
	
	    add(header, BorderLayout.NORTH);
	    add(tab, BorderLayout.CENTER);
	    Utils.tabStateChanged(tab);
	  	}
	
		public JToolBar getToolBars() {
			JToolBar toolbar = new JToolBar();
			toolbar.addSeparator();
			toolbar.add(treeToolBar);
			toolbar.addSeparator();
			toolbar.add(groupToolBar);
			toolbar.addSeparator();
			toolbar.add(searchToolBar);
			return toolbar;
		}
  	
	  public Object getCurrentUserObject() {
	    DefaultMutableTreeNode node = current_tree.getCurrentlySelectedNode();
	    return node.getUserObject();
	  }
	
	  	public void generateReport() {
	  		StandardReports summary = new StandardReports(current_tree.getCurrentlySelectedNode(), 0);
			ReportArea report = new ReportArea(summary.title, summary.generateHTML());
	  		ObjectAction.fireObjectActionEvent(this, report, ObjectAction.NEW_REPORT);
	  	}
	
	  public LinkGroup getCurrentLinkGroup() {
			return current_group;
	  }
		/**
		 * @return Returns the linkTable.
		 */
		public TableEditor getLinkTable() {
			return linkTable;
		}
		/**
		 * @param linkTable The linkTable to set.
		 */
		public void setLinkTable(TableEditor linkTable) {
			this.linkTable = linkTable;
		}
		/**
		 * @return Returns the groupTable.
		 */
	//	public TableEditor getGroupTable() {
	//		return groupTable;
	//	}
		/**
		 * @param groupTable The groupTable to set.
		 */
	//	public void setGroupTable(TableEditor groupTable) {
	//		this.groupTable = groupTable;
	//	}
		/**
		 * @return Returns the current_group.
		 */
		public LinkGroup getCurrentGroup() {
			return current_group;
		}
		
		public void refreshLinkData() {
			Object linkobj = getCurrentUserObject();
			if (linkobj instanceof LinkGroup) {
				LinkGroup group = (LinkGroup)linkobj;
				//groupTable.setDataObject(group, group.toTableData());
			}
			if (linkobj instanceof DataLink) {
				DataLink link = (DataLink)linkobj;
				linkTable.setDataObject(link, link.toTableData());
			}
		}
		
		public JPanel getTreePanel() {return current_tree;}
	
		public JPanel getSearchPanel() {
			return searchPanel;
		}
	
		public void setSearchPanel(JPanel searchPanel) {
			this.searchPanel = searchPanel;
		}
}
