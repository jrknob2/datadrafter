package com.datadrafter.links;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Vector;

import com.datadrafter.events.LinkAction;
import com.datadrafter.modeler.Template;

public class LinkGroup {
  private long id;
  private String name = "";
  private long drawingId = -1;
  private long typeId = -1;
  //private boolean clean = true;
  private Vector links = new Vector();
  private Vector members = new Vector();
  //private LinkAction oa = new LinkAction();

  public static final int ID        = 1;
  public static final int NAME      = 2;
  public static final int DRAWINGID = 3;
  public static final int TYPEID    = 4;
  public static final int MEMBER    = 5;

  public LinkGroup(long id, String name) {
    this.id = id;
    this.name = name;
  }
  public LinkGroup() {
  }
  public long getId() {return id;}
  protected void setId(long id) {
    if (this.id == id) return;
    this.id = id;
    LinkAction.fireObjectActionEvent(this, LinkAction.LINK_UPDATED);
    //clean = false;
  }
  public void setDrawingId(long drawingId) {
    if (this.drawingId == drawingId) return;
    this.drawingId = drawingId;
    LinkAction.fireObjectActionEvent(this, LinkAction.LINK_UPDATED);
    //clean = false;
  }
  public long getDrawingId() {return drawingId;}

  public String getName() {return name;}
  public void setName(String name) {
    if (this.name.equals(name)) return;
    this.name = name;
    LinkAction.fireObjectActionEvent(this, LinkAction.LINK_UPDATED);
    //clean = false;
  }
  public void setTypeId(long typeId) {
    if (this.typeId == typeId) return;
    this.typeId = typeId;
    LinkAction.fireObjectActionEvent(this, LinkAction.LINK_UPDATED);
    //clean = false;
  }
//  public void setClean(boolean clean) {
//  	this.clean = clean;
//  }
  public long getTypeId() {return typeId;}
  public Vector getMembers() {return members;}
  public Vector getLinks() {return links;}
  //public boolean isClean() {return clean;}
  
  public String toString() {return name;}

  public void addMember(long id) {
	members.add(new Long(id));
	LinkAction.fireObjectActionEvent(this, LinkAction.LINK_UPDATED);
	//clean = false;
  }
  public void addLink(DataLink link) {
	links.add(link);
	LinkAction.fireObjectActionEvent(this, LinkAction.LINK_UPDATED);
	//clean = false;
  }
  public void removeLink(DataLink link) {
  	links.remove(link);
  	LinkAction.fireObjectActionEvent(this, LinkAction.LINK_UPDATED);
  	//clean = false;
  }
  public void removeMember(long id) {
	  System.out.println("removing link-> " + id);
  	int index = -1;
  	Iterator iter = members.iterator();
  	while (iter.hasNext()) {
  		Long member = (Long)iter.next();
  		System.out.println("member-> " + member.longValue());
  		if (member.longValue() == id) {
  			System.out.println("match!");
  			index = members.indexOf(member);
  			LinkAction.fireObjectActionEvent(this, LinkAction.LINK_UPDATED);
  			//clean = false;
  			continue;
  		}
  	}
  	if (index == -1) return;

	members.removeElementAt(index);
  }
   public void toXML(PrintWriter out) {
    out.print(toXML());
  }

  public String toXML() {
    String xmlString = "  <linkgroup>\n" +
                       "    <id>" + getId() + "</id>\n" +
                       "    <name>" + getName() + "</name>\n" +
                       "    <drawingid>" + getDrawingId() + "</drawingid>\n";

	Iterator iter = members.iterator();
	while (iter.hasNext()) {
	  xmlString += "    <member>" + ((Long)iter.next()).longValue() + "</member>\n";
	}
	
	iter = links.iterator();
	while (iter.hasNext()) {
	  DataLink link = (DataLink)iter.next();
	  xmlString += link.toXML();
	}

	xmlString += "  </linkgroup>\n";
    return xmlString;
  }

  public boolean setDataField(String label, Object value) {
    if (label.equals("Drawing Id")) {
      this.setDrawingId(Long.parseLong(value.toString()));
    } else if (label.equals("Group Name")) {
      this.setName(value.toString());
    } else if (label.equals("Template")) {
      Template dt = (Template)value;
      setTypeId(dt.getId());
    }
    return true; //clean;
  }
  public String toHtmlTable() {
    String html = "";

    html = "<table border=1 cellpadding=0 cellspacing=0 style=border-collapse: collapse" +
                 " bordercolor=#111111 width=20% id=AutoNumber1>";

    html +=  "<tr><th width=50% bgcolor=#C0C0C0><font face=Tahoma size=2>Property</font></th>";
    html +=  "<th width=50% bgcolor=#C0C0C0><font face=Tahoma size=2>Value</font></th></tr>";

    html += "<tr>";
    html += "  <td width=50% nowrap><font face=Tahoma size=2><b>Id</b></font></td>";
    html += "  <td width=50% nowrap><font face=Tahoma size=2>";
    html +=       getId() + "</font></td>";
    html += "</tr><tr>";

    html += "<tr>";
    html += "<td width=50% nowrap><font face=Tahoma size=2><b>Name</b></font></td>";
    html += "<td width=50% nowrap><font face=Tahoma size=2>" + getName() + "</font></td>";
    html += "</tr><tr>";

    html += "<tr>";
    html += "<td width=50% nowrap><font face=Tahoma size=2><b>Drawing Id</b></font></td>";
    html += "<td width=50% nowrap><font face=Tahoma size=2>" + getDrawingId() + "</font></td>";
    html += "</tr><tr>";

    html += "<tr>";
    html += "<td width=50% nowrap><font face=Tahoma size=2><b>Link Count</b></font></td>";
    html += "<td width=50% nowrap><font face=Tahoma size=2>" + DataLinks.getLinks(this).size() + "</font></td>";
    html += "</tr>";
    html += "</table>";
    return html;
  }

  public Object[][] toTableData() {
  	Object[][] data = new Object[5][2];

    data[0][0] = "Link Type";
    data[0][1] = "Group";
    data[1][0] = "Id";
    data[1][1] = new Long(getId());
    data[2][0] = "Group Name";
    data[2][1] = getName();
    data[3][0] = "Drawing Id";
    data[3][1] = new Long(getDrawingId());
    data[4][0] = "Link Count";
    data[4][1] = new Integer(DataLinks.getLinks(this).size());

    return data;
  }
  public int indexOf(DataLink link) {
  	int index = 0;
  	Iterator iter = members.iterator();
  	while (iter.hasNext()) {
  		long id = ((Long)iter.next()).longValue();
  		 if (id == link.getId()) return index;
  		 ++index;
  	}
  	return -1;
  }
}