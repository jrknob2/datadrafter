package com.datadrafter.links;

import java.io.IOException;
import java.io.PrintWriter;

//import com.datadrafter.utils.Utils;

public class LinkManagerPreferences {
  private boolean alwaysSearchFromRoot = false;
  //private boolean expandNodesOnSelection = false;
  private static boolean openDrawingsInNewWindows = false;
  //private boolean reuseActiveWindows = false;
  private boolean clean = false;

  public LinkManagerPreferences() {
  }
  public boolean getClean() {
    return clean;
  }

  public static boolean getOpenDrawingsInNewWindows() {
    return openDrawingsInNewWindows;
  }

  public void setOpenDrawingsInNewWindows(boolean newValue) {
    if (LinkManagerPreferences.openDrawingsInNewWindows == newValue) {
      return;
    }
	LinkManagerPreferences.openDrawingsInNewWindows = newValue;
    clean = false;
  }

  public boolean getAlwaysSearchFromRoot() {
    return alwaysSearchFromRoot;
  }

  public void setAlwaysSearchFromRoot(boolean newValue) {
    if (this.alwaysSearchFromRoot == newValue) {
      return;
    }
    this.alwaysSearchFromRoot = newValue;
    clean = false;
  }

  public void toFile(PrintWriter out) throws IOException {
    out.println(toString());
  }

  public String toString() {
    return "pref" + "|" + getAlwaysSearchFromRoot();
  }

  public boolean setDataField(String label, Object value) {
    if (label.equals("Always Search From Root")) {
      setAlwaysSearchFromRoot(((Boolean)value).booleanValue());
    } else if (label.equals("Open Drawings in New Windows")) {
      setOpenDrawingsInNewWindows(((Boolean)value).booleanValue());
    }
    return clean;
  }

  public Object[][] toTableData() {
    Object[][] data = new Object[3][2];

    data[0][0] = "Always Search From Root";
    data[0][1] = new Boolean(getAlwaysSearchFromRoot());
    data[1][0] = "Expand Nodes When Selected";
    data[1][1] = new Boolean(false);
    data[2][0] = "Open Drawings in New Windows";
    data[2][1] = new Boolean(getOpenDrawingsInNewWindows());

    return data;
  }
}
