package com.datadrafter.links;

/*
 * This code is based on an example provided by Richard Stanford,
 * a tutorial reader.
 */

import java.awt.BorderLayout;
import java.awt.datatransfer.StringSelection;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureListener;
import java.awt.dnd.DragSource;
import java.awt.dnd.DragSourceDragEvent;
import java.awt.dnd.DragSourceDropEvent;
import java.awt.dnd.DragSourceEvent;
import java.awt.dnd.DragSourceListener;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.util.Iterator;

import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import com.datadrafter.events.LinkAction;
import com.datadrafter.modeler.Template;
import com.datadrafter.modeler.Templates;

public class LinkTree extends JPanel implements DragSourceListener, DragGestureListener {
	/**
	 * 
	 */
	private static final long serialVersionUID  = 1L;
	private LinkGroup 				group		= null;
	public 	DefaultMutableTreeNode 	rootNode 	= new DefaultMutableTreeNode("Root Node");
	private DefaultMutableTreeNode 	curr_node 	= rootNode;
	private DefaultTreeModel 		treeModel 	= null;
	private JScrollPane 			scroll 		= new JScrollPane();
	private JTree 					tree 		= null;
	private DragSource 				dragSource 	= null;
	public static DataLink 			source 		= null;

	public LinkTree(LinkGroup group) {
		super.setBorder(BorderFactory.createEtchedBorder());
		this.group = group;
		treeModel = new DefaultTreeModel(rootNode);
		treeModel.addTreeModelListener(new MyTreeModelListener());
		tree = new JTree(treeModel);
		tree.setEditable(false);
		tree.setRootVisible(false);
		tree.setShowsRootHandles(false);
		tree.getSelectionModel().setSelectionMode(
				TreeSelectionModel.SINGLE_TREE_SELECTION);

		tree.addTreeSelectionListener(new TreeSelectionListener() {
			public void valueChanged(TreeSelectionEvent e) {
				this_valueChanged(e);
			}
		});

		rootNode.setUserObject(group);
		curr_node = rootNode;
		Iterator iter = group.getMembers().iterator();
		while (iter.hasNext()) {
			long id = ((Long) iter.next()).longValue();
			DataLink link = DataLinks.getDataLink(id);
			addObject(curr_node, link, true);
		}
		setLayout(new BorderLayout());
		scroll.getViewport().add(tree);
		add(scroll, BorderLayout.CENTER);

		dragSource = new DragSource();
		dragSource.createDefaultDragGestureRecognizer(tree, DnDConstants.ACTION_MOVE, this);

	}

	public JTree getTree() {
		return tree;
	}

	public DefaultTreeModel getModel() {
		return treeModel;
	}

	public Object getNodeObject() {
		DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree
				.getLastSelectedPathComponent();
		if (node == null) {
			node = rootNode;
		}
		return node.getUserObject();
	}

	public void addSelectionListener(TreeSelectionListener userListener) {
		tree.addTreeSelectionListener(userListener);
	}

	public TreeModel getTreeModel() {
		return treeModel;
	}

	public void reload(LinkGroup group) {
		clear();
		rootNode.setUserObject(group);
		curr_node = rootNode;
		Iterator iter = group.getMembers().iterator();
		while (iter.hasNext()) {
			//DefaultMutableTreeNode new_node = null;
			long id = ((Long) iter.next()).longValue();
			DataLink link = DataLinks.getDataLink(id);
			addObject(curr_node, link, true);
		}
	}

	/** Remove all nodes except the root node. */
	public void clear() {
		rootNode.removeAllChildren();
		treeModel.reload();
	}

	/** Remove the currently selected node. */
	public void removeCurrentNode() {
		DataLink curr_link = null;
		DataLink parent_link = null;

		TreePath currentSelection = tree.getSelectionPath();
		
		if (currentSelection != null) {
			DefaultMutableTreeNode currentNode = (DefaultMutableTreeNode) (currentSelection
					.getLastPathComponent());
			DefaultMutableTreeNode parent = (DefaultMutableTreeNode) (currentNode
					.getParent());
			if (parent != null) {
				curr_link = (DataLink) currentNode.getUserObject();
				if (curr_link.getMembers().size() > 0) {
					JOptionPane.showMessageDialog(this,
							"Must remove sub-items first", "Dependency error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}
				System.out.println("parent-> " + parent);
				if (parent.getUserObject() instanceof DataLink) {
					parent_link = (DataLink) parent.getUserObject();
					parent_link.removeMember(curr_link.getId());

				} else {
					group.removeMember(curr_link.getId());
					group.removeLink(curr_link);
				}
				treeModel.removeNodeFromParent(currentNode);
				LinkAction.fireObjectActionEvent(this, curr_link, LinkAction.LINK_DELETED);

				
				TreePath tp = new TreePath(parent.getPath());
				tree.setSelectionPath(tp);
				return;
			}
		}
	}

	/** Get the currently selected node */
	public DefaultMutableTreeNode getCurrentlySelectedNode() {
		return curr_node;
	}

	public DefaultMutableTreeNode addObject(Object child) {
		DefaultMutableTreeNode parentNode = null;
		TreePath parentPath = tree.getSelectionPath();

		if (parentPath == null) {
			parentNode = rootNode;
		} else {
			parentNode = (DefaultMutableTreeNode) (parentPath
					.getLastPathComponent());
		}

		return addObject(parentNode, child, true);
	}

	/**
	 * Add the user object to the provided node
	 * 
	 * @param parent
	 *            node to add the user object to
	 * 
	 *  
	 */
	public DefaultMutableTreeNode addObject(DefaultMutableTreeNode parent,
			Object child) {
		return addObject(parent, child, false);
	}

	public DefaultMutableTreeNode addObject(DefaultMutableTreeNode parent,
			Object userobj, boolean shouldBeVisible) {
		DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(userobj);

		if (parent == null) {
			parent = rootNode;
		}
		treeModel.insertNodeInto(childNode, parent, parent.getChildCount());

		// Make sure the user can see the lovely new node.
		if (shouldBeVisible) {
			tree.scrollPathToVisible(new TreePath(childNode.getPath()));
		}
		return childNode;
	}

	public void nodeSelected(TreeSelectionEvent e) {
		//System.out.println("node selected");
		curr_node = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
		if (curr_node == null) {
			LinkAction.fireObjectActionEvent(this, group, LinkAction.LINK_UNSELECTED);
			rootNode.setUserObject(group);
			this.setPath(new TreePath(rootNode));
			return;
		} else if (curr_node.getUserObject() instanceof LinkGroup) {
			curr_node = rootNode;
			LinkAction.fireObjectActionEvent(this, group, LinkAction.GROUP_SELECTED);			
		} else if (curr_node.getUserObject() instanceof DataLink) {
			DataLink link = (DataLink) curr_node.getUserObject();
			if (curr_node.getChildCount() == 0) loadMembers(curr_node);
			LinkAction.fireObjectActionEvent(link, link, LinkAction.LINK_SELECTED);
		}
		tree.scrollPathToVisible(new TreePath(curr_node.getPath()));
	}

	class MyTreeModelListener implements TreeModelListener {
		public void treeNodesChanged(TreeModelEvent e) {
			DefaultMutableTreeNode node;
			node = (DefaultMutableTreeNode) (e.getTreePath()
					.getLastPathComponent());
			/*
			 * If the event lists children, then the changed node is the child
			 * of the node we've already gotten. Otherwise, the changed node and
			 * the specified node are the same.
			 */
			try {
				int index = e.getChildIndices()[0];
				node = (DefaultMutableTreeNode) (node.getChildAt(index));
			} catch (NullPointerException exc) {
			}
		}

		public void treeNodesInserted(TreeModelEvent e) {
		}

		public void treeNodesRemoved(TreeModelEvent e) {
		}

		public void treeStructureChanged(TreeModelEvent e) {
		}
	}

	public void selectNextNode() {
		int child_count = curr_node.getChildCount();
		if (child_count > 0) {
			DefaultMutableTreeNode child = (DefaultMutableTreeNode) curr_node
					.getChildAt(0);
			setPath(new TreePath(child));
		}
	}

	public void loadMembers(DefaultMutableTreeNode node) {
		DefaultMutableTreeNode new_node = null;
		//DataLink link = null;

		Object user_obj = node.getUserObject();

		Iterator iter = (user_obj instanceof LinkGroup) ? ((LinkGroup) user_obj)
				.getMembers().iterator()
				: ((DataLink) user_obj).getMembers().iterator();

		while (iter.hasNext()) {
			long id = ((Long) iter.next()).longValue();
			DataLink member = DataLinks.getDataLink(id);
			//      member.setParentId(link.getId());
			new_node = addObject(node, member);
			new_node.setUserObject(member);
		}
	}

//	public LinkTree() {
//		System.out.println("dragSource does not work with this constructor");
//		//dropTarget = new DropTarget(this, this);
//		//dragSource = new DragSource();
//		//        dragSource.createDefaultDragGestureRecognizer(this,
//		// DnDConstants.ACTION_MOVE, this);
//
//		try {
//			jbInit();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

//	private void jbInit() throws Exception {
//	}

	public void setGroup(LinkGroup group) {
		this.group = group;
	}

	public void setPath(TreePath path) {
		tree.setSelectionPath(path);
		//    tree.expandPath(path);
	}

	public boolean findAgain(SearchCriteria criteria) {
		//DefaultMutableTreeNode start_node = null;

		DefaultMutableTreeNode node = findNode(criteria.getLastStart(),
				criteria);
		if (node != null) {
			criteria.getPrevFound().add(node);
			TreePath tp = new TreePath(node.getPath());
			tree.setSelectionPath(tp);
			return true;
		}
		return false;
	}

	public boolean findNode(SearchCriteria criters) {
		criters.setLastStart(curr_node);
		DefaultMutableTreeNode node = findNode(curr_node, criters);
		System.out.println("found node-> " + node);
		if (node != null) {
			criters.getPrevFound().add(node);
			TreePath tp = new TreePath(node.getPath());
			tree.setSelectionPath(tp);
			tree.expandPath(tp);
			return true;
		}
		return false;
	}

	public boolean findNode(Object obj, SearchCriteria criteria) {
		//criteria.setLastStart(rootNode);
		DefaultMutableTreeNode node = findNode(rootNode, criteria);

		if (node != null) {
			criteria.getPrevFound().add(node);
			TreePath tp = new TreePath(node.getPath());
			tree.setSelectionPath(tp);
			tree.expandPath(tp);
			return true;
		}
		return false;
	}

	public DefaultMutableTreeNode findNode(DefaultMutableTreeNode startNode, SearchCriteria criters) {
		Object obj = startNode.getUserObject();
		DataLink nlink = null;
		LinkGroup ngroup = null;
		int count_node = startNode.getChildCount();
		int count_mems = -1;

		if (criters.getPrevFound().indexOf(startNode) != -1) {
			return null;
		}

		if (obj instanceof DataLink) {
			nlink = (DataLink) startNode.getUserObject();
			count_mems = nlink.getMembers().size();
			if (criters.match(nlink)) {
				return startNode;
			}
		} else if (obj instanceof LinkGroup) {
			ngroup = (LinkGroup) obj;
			count_mems = ngroup.getMembers().size();
		}

		if (count_mems == 0) {
			return null;
		}
		
		for (int i = 0; i < count_mems; i++) {
			DefaultMutableTreeNode found = null;

			//System.out.println("start node-> " + startNode.getChildAt(i));
			if (i < count_node) { // existing node
				found = findNode((DefaultMutableTreeNode) startNode
						.getChildAt(i), criters);
				if (found != null) {
					return found;
				}
			} else { // new node
				Long link_id = (obj instanceof DataLink) ? (Long) nlink.getMembers().get(i) : (Long) ngroup.getMembers().get(i); 
				DataLink new_link = DataLinks.getDataLink(link_id.longValue());
				DefaultMutableTreeNode node = new DefaultMutableTreeNode(
						new_link);
				found = findNode(node, criters);
				if (found != null) {
					startNode.add(node);
					for (int k = 0; k < count_mems; k++) {
						if (k != i) {
							Long sib_id = (obj instanceof DataLink) ? (Long) nlink
									.getMembers().get(k)
									: new Long(((DataLink) DataLinks.getLinks(
											group).get(k)).getId());
							DataLink sib_link = DataLinks.getDataLink(sib_id
									.longValue());
							DefaultMutableTreeNode sib_node = new DefaultMutableTreeNode(
									sib_link);
							startNode.add(sib_node);
						}
					}
					return found;
				}
			}
		}
		return null;
	}

	public DefaultMutableTreeNode findNode(DefaultMutableTreeNode startNode, DataLink link) {
		System.out.println("startNode-> " + startNode);
		System.out.println("link-> " + link);
		DefaultMutableTreeNode node = null;

		if (startNode.equals(rootNode)) {
			node = walk(rootNode, link);
		} else {
			TreeNode[] nodes = startNode.getPath();
			DefaultMutableTreeNode searchRoot = (DefaultMutableTreeNode) nodes[1];
			node = walk(searchRoot, link);
		}
		return node;
	}

	protected DefaultMutableTreeNode walk(DefaultMutableTreeNode root, DataLink dlink) {

		//System.out.println("find root-> " + root);
		//System.out.println("cadlink -> " + cadlink);

		if (dlink == null)
			return null;

		DefaultMutableTreeNode node = null;
		int cc = root.getChildCount();
		if (cc == 0) {
			return null;
		}
		for (int i = 0; i < cc; i++) {
			node = (DefaultMutableTreeNode) root.getChildAt(i);
			//System.out.println("node -> " + node);
			DataLink data_link = (DataLink) node.getUserObject();
			//System.out.println("data_link -> " + data_link);
			if (dlink.getId() == data_link.getId()) {
				return node;
			}
			if (node.getChildCount() > 0) {
				node = walk(node, dlink);
				if (node != null) {
					return node;
				}
			}
		}
		return null;
	}

	public void this_valueChanged(TreeSelectionEvent e) {
		nodeSelected(e);
	}

	public void moveNodeUp() {
		int curr_index = -1;
		int before_index = -1;
		DefaultMutableTreeNode parent = (DefaultMutableTreeNode) (curr_node
				.getParent());
		if (parent != null) {
			int index = parent.getIndex(curr_node);
			if (index > 0) {
				DefaultMutableTreeNode before = (DefaultMutableTreeNode) parent
						.getChildBefore(curr_node);
				treeModel.removeNodeFromParent(before);
				treeModel.insertNodeInto(before, parent, index);
				DataLink curr_link = (DataLink) curr_node.getUserObject();
				DataLink before_link = (DataLink) before.getUserObject();
				Object parent_obj = parent.getUserObject();
				if (parent_obj instanceof LinkGroup) {
					LinkGroup group = (LinkGroup) parent_obj;
					curr_index = group.indexOf(curr_link);
					before_index = group.indexOf(before_link);
					group.getMembers().remove(curr_index);
					group.getMembers().add(before_index,
							new Long(curr_link.getId()));
				} else {
					DataLink parent_link = (DataLink) parent_obj;
					curr_index = parent_link.indexOf(curr_link);
					before_index = parent_link.indexOf(before_link);
					parent_link.getMembers().remove(curr_index);
					parent_link.getMembers().add(before_index,
							new Long(curr_link.getId()));
				}

			}
		}
	}

	public void moveNodeDown() {
		//Vector members = null;
		int curr_index = -1;
		int after_index = -1;

		DefaultMutableTreeNode parent = (DefaultMutableTreeNode) (curr_node
				.getParent());
		if (parent != null) {
			int index = parent.getIndex(curr_node);
			if (index + 1 < parent.getChildCount()) {
				DefaultMutableTreeNode after = (DefaultMutableTreeNode) parent
						.getChildAfter(curr_node);
				treeModel.removeNodeFromParent(after);
				treeModel.insertNodeInto(after, parent, index);
				DataLink curr_link = (DataLink) curr_node.getUserObject();
				DataLink after_link = (DataLink) after.getUserObject();
				Object parent_obj = parent.getUserObject();
				if (parent_obj instanceof LinkGroup) {
					LinkGroup group = (LinkGroup) parent_obj;
					curr_index = group.indexOf(curr_link);
					after_index = group.indexOf(after_link);
					group.getMembers().remove(curr_index);
					group.getMembers().add(after_index,
							new Long(curr_link.getId()));
				} else {
					DataLink parent_link = (DataLink) parent_obj;
					curr_index = parent_link.indexOf(curr_link);
					after_index = parent_link.indexOf(after_link);
					parent_link.getMembers().remove(curr_index);
					parent_link.getMembers().add(after_index,
							new Long(curr_link.getId()));
				}
			} else {

			}
		}
	}

	public void dragDropEnd(DragSourceDropEvent arg0) {
	}

	public void dragEnter(DragSourceDragEvent arg0) {
	}

	public void dragExit(DragSourceEvent arg0) {
	}

	public void dragOver(DragSourceDragEvent arg0) {
	}

	public void dropActionChanged(DragSourceDragEvent arg0) {
	}

	public void dragEnter(DropTargetDragEvent arg0) {
	}

	public void dragExit(DropTargetEvent arg0) {
	}

	public void dragOver(DropTargetDragEvent arg0) {
	}

	public void drop(DropTargetDropEvent arg0) {
	}

	public void dropActionChanged(DropTargetDragEvent arg0) {
	}

	public void dragGestureRecognized(DragGestureEvent dragGestureEvent) {
		//		DefaultMutableTreeNode oDefaultMutableTreeNode
		DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree
				.getLastSelectedPathComponent();
		source = (DataLink) node.getUserObject();
		Template templ = Templates.getDetailTemplate(source.getTypeId());
		//System.out.println("template-> " + templ);
		if (templ != null) {
			//System.out.println("drawingId-> " + templ.getDrawingId());
		}
		StringSelection text = new StringSelection(source.toString());
		dragSource.startDrag(dragGestureEvent, DragSource.DefaultLinkDrop,
				text, this);
	}

	class LinkTree_this_componentAdapter extends
			java.awt.event.ComponentAdapter {
		LinkTree adaptee;

		LinkTree_this_componentAdapter(LinkTree adaptee) {
			this.adaptee = adaptee;
		}
	}
}