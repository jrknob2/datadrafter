package com.datadrafter.links;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
import java.util.Vector;

public interface DataLinksInterface {
  public Vector getGroups();
  public void load(String filename);
  public Vector getLinks(LinkGroup group);

//  public Vector getAllDataTypes(DataLink link);

/*  public void removeGroup(LinkGroup group);
  public void removeLink(DataLink link);
  public void addGroup(LinkGroup group);
  public int getGroupIndex(LinkGroup group);
  public int getGroupIndex(DataLink link);
  public void addLink(DataLink link);
  public DataLink getDataLink(long id);
  public DataLink getDataLink(LinkGroup group, long id);
  public void toFile();
  public Vector getAllDataTypes(Object root_obj);
  public int getDataTypeCount(DetailTemplate templ, DataLink link); */
}