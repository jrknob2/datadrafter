/*
 * Created on May 7, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.datadrafter.project;

/**
 * @author Terry Knoblock
 *
 * @
 */
public class ProjectParser {

}
