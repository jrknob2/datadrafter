package com.datadrafter.gui;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;

public class TestVertTabs implements SwingConstants {
	public static void main(String[] args) {
		new TestVertTabs();
    }

	public TestVertTabs() {
		JFrame fr = new JFrame("Test");
		fr.getContentPane().add(testComponent());
		fr.setSize(new Dimension(400, 600));
		fr.setVisible(true);
	}
	JComponent testComponent() {
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(0,3));
		panel.add(makeTabpane(new Font("Tahoma", 1, 12), sEnglish, VTextIcon.ROTATE_RIGHT));
		//panel.add(makeTabpane(new Font("Osaka", 0, 12), sJapanese, VTextIcon.ROTATE_DEFAULT));
		//panel.add(makeTabpane(null, sEnglish, VTextIcon.ROTATE_NONE));
		return panel;
	}
	
	JTabbedPane makeTabpane(Font font, String[] strings, int rotateHint) {
		JTabbedPane panel = new JTabbedPane(LEFT);
		//Icon graphicIcon = UIManager.getIcon("FileView.computerIcon");
		if (font != null)
			panel.setFont(font);
		for (int i = 0; i < strings.length; i++) {
			VTextIcon textIcon = new VTextIcon(panel, strings[i], rotateHint);
			//CompositeIcon icon = new CompositeIcon(graphicIcon, textIcon);
			panel.addTab(null, textIcon, makePane(strings[i]));
		}
		return panel;
	}
	
	JPanel makePane(String toolTip) {
		JPanel p = new JPanel();
		p.setOpaque(false);
		return p;
	}
	
	static String[] sEnglish = {" Link Manager      ",
								" Data Editor       ",					
								" Graphics Designer ", 
			                    " Object Modeler    "};
	
	static String[] sJapanese = {"\u65e5\u672c\u8a9e", "\u5c45\u3068\u3001\u304d\u3087\u3068"};
}
