package com.datadrafter.gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class About extends JDialog implements ActionListener {

	private static final long serialVersionUID = 1L;
	protected JButton okButton;
	protected JLabel  appTitle;

  public About(JFrame parent, String appVersion, String copyRight) {
    super(parent, "About DataDrafter"); // By default the box is non-modal
    setResizable(false);

    // Workaround for modal about box bug in MacOS X 10.0.x
    // regardless of mrj.version (3.0/3.1/DP1-2)
    String version = System.getProperty("os.version");
    String osname = System.getProperty("os.name");

    setModal(true);

    this.getContentPane().setLayout(new BorderLayout(15, 15));
    this.setFont(new Font("SansSerif", Font.BOLD, 14));

    appTitle = new JLabel("<HTML><CENTER><B text=#333399>" + appVersion + "</B><P><P>&copy;&nbsp;" + copyRight + 
                          "<P><P>" + osname + "&nbsp;" + version + "</HTML>");
    JPanel textPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
    textPanel.add(appTitle);

    this.getContentPane().add(textPanel, BorderLayout.NORTH);

    okButton = new JButton("OK");
    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
    buttonPanel.add(okButton);
    okButton.addActionListener(this);
    this.getContentPane().add(buttonPanel, BorderLayout.SOUTH);
    this.pack();
  }

  public void actionPerformed(ActionEvent newEvent) {
    setVisible(false);
  }
}