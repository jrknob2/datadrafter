package com.datadrafter.gui.personal;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.WindowEvent;

import javax.swing.BorderFactory;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import com.datadrafter.xcad.CadDrawing;
import com.datadrafter.xcad.CadView;
import com.datadrafter.data.DataEditor;
import com.datadrafter.designer.GraphicsDesigner;
import com.datadrafter.events.AppEventHandler;
import com.datadrafter.events.GraphicsAction;
import com.datadrafter.events.LinkAction;
import com.datadrafter.events.ObjectAction;
import com.datadrafter.gui.StatusPanel;
import com.datadrafter.gui.custom.JTabbedPaneX;
import com.datadrafter.links.DataLinks;
import com.datadrafter.links.LinkManager;
import com.datadrafter.modeler.Attribs;
import com.datadrafter.modeler.Details;
import com.datadrafter.modeler.ObjectModeler;
import com.datadrafter.modeler.Templates;
import com.datadrafter.utils.Utils;

public class DataDrafter extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected DataLinks links     = null;
	protected Attribs   attribs   = null;
	protected Details   details   = null;
	protected Templates templates = null;

	GraphicsDesigner graphman   = null;
	LinkManager      linkman    = null;
	DataEditor       dataman    = null;
	ObjectModeler    modeler    = null;
	AppEventHandler  apphandler = null;
	CadDrawing       drawing    = null;
	CadView          view       = null;
	// UserGuides    guide      = null;
	
	String[] columns = { "Property", "Value" };

	public JTabbedPaneX content_tp = null;
	public JTabbedPane tools_tp = null;
	public JEditorPane editorPane = new JEditorPane();

	public JSplitPane leftsplit = null;
	public JSplitPane rightsplit = null;
	public JSplitPane mainsplit = null;

	public StatusPanel status = null;

	public static final int MODE_DESIGN      = 0;
	public static final int MODE_BROWSE      = 1;
	public static int       design_mode      = 0;
	public static boolean   TOOLTIPS_ENABLED = true;

	public DataDrafter() {
		super();
		content_tp = new JTabbedPaneX();
		content_tp.setBorder(BorderFactory.createEmptyBorder());

		tools_tp = new JTabbedPane();
		tools_tp.setBorder(BorderFactory.createEmptyBorder());
		
		try {
			attribs = new Attribs(Utils
					.getProperty("datadrafter.config.attribs"));
			details = new Details(Utils
					.getProperty("datadrafter.config.details"));
			templates = new Templates(Utils
					.getProperty("datadrafter.config.templates"));
			links = new DataLinks(Utils
					.getProperty("datadrafter.config.links"));
			//modeler = new ObjectModeler();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			System.exit(0);
		}

		setTitle("DataDrafter Personal Edition v1.4 �2010 All Rights Reserved.");
		setSize(1200, 800);

		// Create the menu bar
		JMenuBar menuBar = new JMenuBar();
		JMenu fileMenu = new JMenu("File");
		JMenu fileNewItem = new JMenu("New");
		JMenuItem newProject = new JMenuItem("Project");
		JMenuItem newDrawing = new JMenuItem("Drawing");
		JMenuItem fileExitItem = new JMenuItem("Exit");
		fileMenu.add(fileNewItem);
		fileNewItem.add(newProject);
		fileNewItem.add(newDrawing);
		fileMenu.addSeparator();
		fileMenu.add(fileExitItem);

		menuBar.add(fileMenu);

		JMenu helpMenu = new JMenu("Help");
		JMenuItem quickSubm = new JMenuItem("Quick Start Guide");
		JMenuItem welcomeSubm = new JMenuItem("Welcome");
		JMenuItem aboutSubm = new JMenuItem("About");
		menuBar.add(helpMenu);
		helpMenu.add(aboutSubm);
		helpMenu.add(quickSubm);
		helpMenu.add(welcomeSubm);
		
		quickSubm.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ObjectAction.fireObjectActionEvent("Quick Start Guide", "./config/html/quickstart.html", ObjectAction.MENU_HELP);
			}
		});

		welcomeSubm.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ObjectAction.fireObjectActionEvent("Welcome", "./config/html/welcome.html", ObjectAction.MENU_HELP);
			}
		});
		
		fileExitItem.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exitSubm_actionPerformed(e);
			}
		});

		dataman = new DataEditor();
		apphandler = new AppEventHandler();
		apphandler.addComponent(this);
		view = new CadView();
		view.setDrawing(drawing);
		apphandler.addComponent(view);
		graphman = new GraphicsDesigner();
		apphandler.addComponent(graphman);
		linkman = new LinkManager(links);
		apphandler.addComponent(linkman);
		status = new StatusPanel();
		apphandler.addComponent(status);
		dataman = new DataEditor();
		apphandler.addComponent(dataman);
		modeler = new ObjectModeler();
		apphandler.addComponent(modeler);
		// guide = new UserGuides();
		// apphandler.addComponent(guide);

		getContentPane().setLayout(new BorderLayout());
		ClassLoader cl = getClass().getClassLoader();
		
		//String[] columns = { "Property", "Value" };
		apphandler.addComponent(linkman.getLinkTable());
		
		tools_tp.addTab("Data Editor", dataman);
		tools_tp.addTab("Object Modeler", modeler);
		tools_tp.addTab("Graphics Designer", graphman);
		tools_tp.setSelectedIndex(0);
		
		leftsplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT, linkman, null);
		leftsplit.setBorder(BorderFactory.createEmptyBorder());
		rightsplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT, content_tp, tools_tp);
		rightsplit.setBorder(BorderFactory.createEmptyBorder());
		mainsplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftsplit, rightsplit);
		mainsplit.setBorder(BorderFactory.createEmptyBorder());

		leftsplit.setOneTouchExpandable(true);
		leftsplit.setDividerSize(3);
		
		rightsplit.setOneTouchExpandable(true);
		rightsplit.setDividerLocation(150);
		rightsplit.setDividerSize(3);
		rightsplit.setBorder(null);
		
		mainsplit.setOneTouchExpandable(true);
		mainsplit.setDividerLocation(175);
		mainsplit.setDividerSize(3);
		
		leftsplit.setDividerLocation(getHeight() / 2);
		rightsplit.setDividerLocation(getHeight() / 2);

		Utils.checkRegistrationKey();
		Utils.centerFrame(this);
		LinkAction.fireObjectActionEvent(linkman, linkman.getCurrentGroup(),
				LinkAction.GROUP_SELECTED);

		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		getContentPane().add(menuBar, BorderLayout.NORTH);
		getContentPane().add(mainsplit, BorderLayout.CENTER);
		getContentPane().add(status, BorderLayout.SOUTH);
		
		ObjectAction.fireObjectActionEvent("Welcome", "./config/html/welcome.html", ObjectAction.MENU_HELP);
		
		//main_tp.setBackgroundAt(0, new Color(0, 0, 0));
	}

	// Overridden so we can exit when window is closed
	protected void processWindowEvent(WindowEvent e) {
		super.processWindowEvent(e);
		if (e.getID() == WindowEvent.WINDOW_CLOSING) {
			GraphicsAction.fireGraphicsActionEvent(this, this,
					GraphicsAction.APP_CLOSING);
			LinkAction.fireObjectActionEvent(this, this, LinkAction.APP_CLOSING);
			System.exit(0);
		}
	}

	// File | Exit action performed
	public void exitSubm_actionPerformed(ActionEvent e) {
		System.exit(0);
	}

	public static void main(String[] args) {
		DataDrafter ddp = new DataDrafter();
		ddp.setVisible(true);
	}
}
