package com.datadrafter.gui.custom;

import java.awt.Component;
import java.awt.Insets;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JTabbedPane;
import javax.swing.UIManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.datadrafter.events.GraphicsAction;
import com.datadrafter.events.ObjectAction;
import com.datadrafter.gui.personal.DataDrafter;
import com.datadrafter.xcad.CadView;

public class JTabbedPaneX extends JTabbedPane
{
	public JTabbedPaneX()
	{
		super();
	    addChangeListener(new ChangeListener() {
	        public void stateChanged(ChangeEvent changeEvent) {
	          int index = getSelectedIndex();	          
	          if (getTabCount() > 0) {
	        	  for (int i=0; i < getTabCount(); i++)
	        	  {
	        		  Component comp = getComponentAt(index);
	        		  if (comp instanceof HTMLViewPane) {
	        			  ObjectAction.fireObjectActionEvent(this, comp, ObjectAction.TAB_CHANGED);
	        			  return;
	        		  }
	        		  if (comp instanceof CadView) {
	        			  ObjectAction.fireObjectActionEvent(this, comp, ObjectAction.TAB_CHANGED);
	        			  return;
	        		  }
	        	  }	        	  
	          }
	       }
	    });
	}	    
//		addMouseListener(new MouseListener()
//	      {
//			@Override
//			public void mouseClicked(MouseEvent e) {
//				JTabbedPaneX me = (JTabbedPaneX)e.getSource();
//				if (me.getTabCount() == 0) {
//					ObjectAction.fireObjectActionEvent("Quick Start Guide", "./config/html/quickstart.html", ObjectAction.MENU_HELP);
//				}
//				
//			}
//
//			@Override
//			public void mouseEntered(MouseEvent arg0) {
//				// TODO Auto-generated method stub
//				
//			}
//
//			@Override
//			public void mouseExited(MouseEvent arg0) {
//				// TODO Auto-generated method stub
//				
//			}
//
//			@Override
//			public void mousePressed(MouseEvent arg0) {
//				// TODO Auto-generated method stub
//				
//			}
//
//			@Override
//			public void mouseReleased(MouseEvent arg0) {
//				// TODO Auto-generated method stub
//				
//			}
// 	    	
//	    });
//	}  
  
	public void addXTab(String title, Component comp) {
		add(title, comp);
		setTabComponentAt(indexOfComponent(comp), createTabComponent(title));
  }
	  
  private JComponent createTabComponent(String title)
  {		
	  //final JLabel labelx = new JLabel("<html><b>X</b></html>");
	  ClassLoader cl = DataDrafter.class.getClassLoader();
	  ImageIcon xIcon = new ImageIcon(cl.getResource("icons/blackx.png"));
	  JButton xbutton = new JButton(); 
	  xbutton.setBackground(this.getBackground());
	  xbutton.setBorder(null);
	  xbutton.setIcon(xIcon);
	  xbutton.setOpaque(false);
	  xbutton.setSize(xIcon.getIconWidth(), xIcon.getIconHeight());
	  //labelx.setFocusable(false);
	  //labelx.setForeground(Color.WHITE);
	  //labelx.setBorder(BorderFactory.createEmptyBorder());
	  //labelx.setBackground(this.getBackground());
    
	  xbutton.addMouseListener(new MouseListener()
      {
		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
			removeXTab((JComponent)e.getSource());
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			//xIcon. .setForeground(Color.RED);
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
//			  labelx.setForeground(Color.WHITE);
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}
      }
    );
 
    JComponent tabComp = Box.createHorizontalBox();
    tabComp.add(new JLabel("<html><b>" + title + "</b></html>"));	
    tabComp.add(Box.createHorizontalStrut(6));
    tabComp.add(xbutton);
 
    return tabComp;
  }

  // TODO implement cool logo before release
//  public void paint(Graphics g) {
//	  super.paint(g);
//	  
//	  Graphics2D g2d = (Graphics2D)g;
//	  
//	  if (getTabCount() == 0) {
//		Rectangle2D rec = new Rectangle2D.Double(0, 0, getWidth(), getHeight());
//		g2d.setColor(new Color(153, 162, 167));
//		g2d.fill(rec);
//		Image image = Toolkit.getDefaultToolkit().getImage("./icons/cool_logo.jpg");
//		System.out.println("image-> " + image.getWidth(this));
//		g2d.drawImage(image, (getWidth()/2) - (image.getWidth(this)/2), (getHeight()/2) - (image.getHeight(this)/2), image.getWidth(this), image.getHeight(this), this);
//	  }
//  }

  
  private void removeXTab(JComponent comp) {
	  remove(indexOfTabComponent(comp.getParent()));
	  GraphicsAction.fireGraphicsActionEvent(this, null, GraphicsAction.VIEW_CLOSING);
  }
 
  public static void main(String[] args)
  {
    /* Insets for Metal/Ocean L&F - default is (0, 9, 1, 9) */
    UIManager.put("TabbedPane.tabInsets", new Insets(2, 6, 1, 1));
 
//    try
//    {
//      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
//    }
//    catch (Exception ex)
//    {
//      ex.printStackTrace();
//    }
//    /* Insets for Windows (XP) L&F - default is (0, 4, 1, 4) */
//    UIManager.put("abbedPane.tabInsets", new Insets(1, 4, 1, 1));
 
    new JTabbedPaneX();
  }
}