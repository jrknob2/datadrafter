package com.datadrafter.gui.custom;

import java.awt.Dimension;
import java.io.IOException;

import javax.swing.JEditorPane;
import javax.swing.JScrollPane;
import javax.swing.text.html.HTMLEditorKit;

import com.datadrafter.utils.Utils;

public class HTMLViewPane extends JScrollPane 
{
	public HTMLViewPane(String filepath) {
		
		JEditorPane editor = new JEditorPane();
		editor.setEditable(false);
		editor.setEditorKit(new HTMLEditorKit());

		try {
			String data = Utils.readFileAsString(filepath);
			editor.setText(data);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
				
		getViewport().add(editor);
		editor.setPreferredSize(new Dimension(getViewport().getSize()));
		validate();
	    
	}
}
