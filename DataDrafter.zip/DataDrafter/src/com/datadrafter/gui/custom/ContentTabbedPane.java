package com.datadrafter.gui.custom;

import javax.swing.JTabbedPane;

public class ContentTabbedPane extends JTabbedPane {

}
