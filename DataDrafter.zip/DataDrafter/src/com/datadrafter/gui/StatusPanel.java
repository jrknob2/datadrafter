package com.datadrafter.gui;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.geom.Point2D;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import com.datadrafter.utils.Utils;

public class StatusPanel extends JPanel { 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JPanel leftPanel   = new JPanel(new FlowLayout(FlowLayout.LEFT));
	JPanel middlePanel = new JPanel(new GridLayout(1, 2)); //GridLayout(1, 4));
	JPanel rightPanel  = new JPanel(new GridLayout(1, 1));
	
	JLabel middleLabel = new JLabel("", SwingConstants.LEFT);
	
//	JLabel commandLabel      = new JLabel("Command: ", SwingConstants.RIGHT);
//	JLabel commandDataLabel  = new JLabel("None", SwingConstants.LEFT);
//	JLabel actionLabel       = new JLabel("Action: ", SwingConstants.RIGHT);
//	JLabel actionDataLabel   = new JLabel("None", SwingConstants.LEFT);

	JLabel messageLabel      = new JLabel("Started", SwingConstants.LEFT);	
	JLabel screenXyLabel     = new JLabel("XY: ", SwingConstants.RIGHT);
	JLabel screenXyDataLabel = new JLabel("0:0", SwingConstants.LEFT);
//	JLabel scaleLabel        = new JLabel("Scale: ", SwingConstants.RIGHT);
//	JLabel scaleDataLabel    = new JLabel("1.0", SwingConstants.LEFT);
//	JLabel elementLabel      = new JLabel("Elem: ", SwingConstants.RIGHT);
//	JLabel elementDataLabel  = new JLabel("None", SwingConstants.LEFT);
	
	public StatusPanel() {

		setLayout(new GridLayout(1, 2));
		
		screenXyLabel.setFont(new Font(screenXyLabel.getFont().getName(), Font.BOLD, screenXyLabel.getFont().getSize()));
//		scaleLabel.setFont(new Font(scaleLabel.getFont().getName(), Font.BOLD, scaleLabel.getFont().getSize()));
//		commandLabel.setFont(new Font(commandLabel.getFont().getName(), Font.BOLD, commandLabel.getFont().getSize()));
//		actionLabel.setFont(new Font(actionLabel.getFont().getName(), Font.BOLD, actionLabel.getFont().getSize()));
//		elementLabel.setFont(new Font(elementLabel.getFont().getName(), Font.BOLD, elementLabel.getFont().getSize()));
		
		leftPanel.add(messageLabel);
		//middlePanel.add(this.middleLabel);
		
//		statePanel.add(commandLabel);
//		statePanel.add(commandDataLabel);
//		statePanel.add(actionLabel);
//		statePanel.add(actionDataLabel);		
		
//		graphicsPanel.add(elementLabel);
//		graphicsPanel.add(elementDataLabel);
		rightPanel.add(screenXyLabel);
		rightPanel.add(screenXyDataLabel);
//		graphicsPanel.add(scaleLabel);
//		graphicsPanel.add(scaleDataLabel);
		
		add(leftPanel);
		add(middlePanel);
		add(rightPanel);


		setBorder(BorderFactory.createRaisedBevelBorder());
		screenXyLabel.setToolTipText("Current mouse position in screen coordinates");
		//scaleLabel.setToolTipText("Current view scale");
		//commandLabel.setToolTipText("Current view command");
		//actionLabel.setToolTipText("Current view action");
		//elementLabel.setToolTipText("Current element type");
//		linkEventLabel.setToolTipText("Last link event");
//		graphicEventLabel.setToolTipText("Last graphics event");
		
//		commandDataLabel.setBorder(BorderFactory.createLoweredBevelBorder());
//		elementDataLabel.setBorder(BorderFactory.createLoweredBevelBorder());
//		screenDataLabel.setBorder(BorderFactory.createLoweredBevelBorder());
//		realDataLabel.setBorder(BorderFactory.createLoweredBevelBorder());
//		scaleDataLabel.setBorder(BorderFactory.createLoweredBevelBorder());

		//stateLabel.setBorder(BorderFactory.createLoweredBevelBorder());
		
//		eventPanel.setBorder(BorderFactory.createLoweredBevelBorder());
//		statePanel.setBorder(BorderFactory.createLoweredBevelBorder());
//		dataPanel.setBorder(BorderFactory.createLoweredBevelBorder());
		
//		Font font = screenLabel.getFont();
//		font = new Font(font.getFontName(), Font.BOLD, 10);
//		screenLabel.setFont(font);
//		realLabel.setFont(font);
//		scaleLabel.setFont(font);
//		commandLabel.setFont(font);
//		elementLabel.setFont(font);
//		graphicEventLabel.setFont(font);
//		linkEventLabel.setFont(font);
		
//		eventPanel.add(linkLabel);
//		eventPanel.add(linkEventLabel);
//		eventPanel.add(graphicLabel);
//		eventPanel.add(graphicEventLabel);
		
	}
	/**
	 * @param screenDataLabel The screenDataLabel to set.
	 */
	public void setScreenPoint(Point2D p) {
		screenXyDataLabel.setText(p.getX() + ":" + p.getY());
	}
//	public void setRealPoint(CadPoint cp) {
//		realXyDataLabel.setText(Utils.getFormattedDouble(cp.getX()) + ":" + Utils.getFormattedDouble(cp.getY()));
//	}
	
	/**
	 * @param elementDataLabel The elementDataLabel to set.
	 */
//	public void setElementDataLabel(String value) {
//		elementDataLabel.setText(value);
//	}
	/**
	 * @param actionDataLabel The actionDataLabel to set.
	 */
//	public void setActionDataLabel(String value) {
//		actionDataLabel.setText(value);
//	}
	/**
	 * @param messageLabel The messageLabel to set.
	 */
	public void setLeftLabel(String value) {
		messageLabel.setText(value);
	}
	/**
	 * @param middleLabel The middleLabel to set.
	 */
	public void setMiddleLabel(String value) {
		middleLabel.setText(value);
	}
/**
 * @param messageLabel The messageLabel to set.
 */
	public void setMessageLabel(String value) {
		messageLabel.setText(value);
	}
}
