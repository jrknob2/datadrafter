package com.datadrafter.gui;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyVetoException;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JTabbedPane;

import com.datadrafter.xcad.CadView;

/**
 * Menu component that handles the functionality expected of a standard
 * "Windows" menu for MDI applications.
 */
public class WindowMenu extends JMenu {
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTabbedPane desktop;
	private JMenuItem cascade = new JMenuItem("Cascade");
	private JMenuItem tile = new JMenuItem("Tile");
	private JMenuItem tilev = new JMenuItem("Tile Vertical");

	public WindowMenu(JTabbedPane desktop) {
		this.desktop = desktop;
		setText("Window");
//		//setBackground(getParent().getBackground());
//		cascade.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent ae) {
//				WindowMenu.this.desktop.cascadeFrames();
//			}
//		});
//		tile.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent ae) {
//				WindowMenu.this.desktop.tileFrames();
//			}
//		});
//		tilev.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent ae) {
//				WindowMenu.this.desktop.tileFramesVertically();
//			}
//		});
//    
//		addMenuListener(new MenuListener() {
//			public void menuCanceled(MenuEvent e) {}
//
//			public void menuDeselected(MenuEvent e) {
//				removeAll();
//			}
//
//			public void menuSelected(MenuEvent e) {
//				buildChildMenus();
//			}
//		});
	}

  /* Sets up the children menus depending on the current desktop state */
  private void buildChildMenus() {
	  int i;
	  ChildMenuItem menu;
	  int tabs = desktop.getTabCount();

	  for (i = 0; i < desktop.getTabCount(); i++) {
		  Component comp  = desktop.getComponentAt(i);
    	
		  if (comp instanceof CadView) {
			  CadView view = (CadView)comp;
			  menu = new ChildMenuItem(view.getDrawing().getTitle());
			  menu.addActionListener(new ActionListener() {
				  public void actionPerformed(ActionEvent ae) {
				  }
			  });
			  add(menu);
		  }
	  }
  }

  /* This JCheckBoxMenuItem descendant is used to track the child frame that corresponds
     to a given menu. */
  class ChildMenuItem extends JCheckBoxMenuItem {
    /**
	 * 
	 */
	private static final long serialVersionUID = -4226725255844328873L;
	private String title;

    public ChildMenuItem(String title) {
      super(title);
      this.title = title;
    }
  }
}