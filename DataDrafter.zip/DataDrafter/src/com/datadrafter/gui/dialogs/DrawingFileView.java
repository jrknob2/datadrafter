package com.datadrafter.gui.dialogs;

import java.io.File;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.filechooser.FileView;

/* ImageFileView.java is a 1.4 example used by FileChooserDemo2.java. */
public class DrawingFileView extends FileView {
    ImageIcon jpgIcon = FileViewUtils.createImageIcon("icons/jpgIcon.gif");
    ImageIcon gifIcon = FileViewUtils.createImageIcon("icons/gifIcon.gif");
    ImageIcon tiffIcon = FileViewUtils.createImageIcon("icons/tiffIcon.gif");

    public String getName(File f) {
        return null; //let the L&F FileView figure this out
    }

    public String getDescription(File f) {
        return null; //let the L&F FileView figure this out
    }

    public Boolean isTraversable(File f) {
        return null; //let the L&F FileView figure this out
    }

    public String getTypeDescription(File f) {
        String extension = FileViewUtils.getExtension(f);
        String type = null;

        if (extension != null) {
            if (extension.equals(FileViewUtils.jpeg) ||
                extension.equals(FileViewUtils.jpg)) {
                type = "JPEG Image";
            } else if (extension.equals(FileViewUtils.gif)){
                type = "GIF Image";
            } else if (extension.equals(FileViewUtils.tiff) ||
                       extension.equals(FileViewUtils.tif)) {
                type = "TIFF Image";
            }
        }
        return type;
    }

    public Icon getIcon(File f) {
        String extension = FileViewUtils.getExtension(f);
        Icon icon = null;

        if (extension != null) {
            if (extension.equals(FileViewUtils.jpeg) ||
                extension.equals(FileViewUtils.jpg)) {
                icon = jpgIcon;
            } else if (extension.equals(FileViewUtils.gif)) {
                icon = gifIcon;
            } else if (extension.equals(FileViewUtils.tiff) ||
                       extension.equals(FileViewUtils.tif)) {
                icon = tiffIcon;
            }
        }
        return icon;
    }
}
