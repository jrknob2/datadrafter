package com.datadrafter.gui.dialogs;

import java.io.File;

import javax.swing.filechooser.FileFilter;

/* ImageFilter.java is a 1.4 example used by FileChooserDemo2.java. */
public class ImageFilter extends FileFilter {

    //Accept all directories and all gif, jpg, tiff, or png files.
    public boolean accept(File f) {
        if (f.isDirectory()) {
            return true;
        }

        String extension = FileViewUtils.getExtension(f);
        if (extension != null) {
            if (extension.equals(FileViewUtils.tiff)||
                extension.equals(FileViewUtils.tif) ||
                extension.equals(FileViewUtils.gif) ||
                extension.equals(FileViewUtils.jpeg)||
                extension.equals(FileViewUtils.jpg) ||
				extension.equals(FileViewUtils.cad) ||
				extension.equals(FileViewUtils.svg)) {
                    return true;
            } else {
                return false;
            }
        }

        return false;
    }

    //The description of this filter
    public String getDescription() {
        return "Just Images";
    }
}
