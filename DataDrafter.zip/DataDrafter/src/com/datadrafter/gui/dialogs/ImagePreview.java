package com.datadrafter.gui.dialogs;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.geom.Rectangle2D;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFileChooser;

import com.datadrafter.xcad.CadDrawing;
import com.datadrafter.xcad.CadView;
import com.datadrafter.gui.personal.DataDrafter;

/* ImagePreview.java is a 1.4 example used by FileChooserDemo2.java. */
public class ImagePreview extends JComponent implements PropertyChangeListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	CadDrawing drawing = null;
	CadView	   view = null;
	ImageIcon thumbnail = null;
    File file = null;

    public ImagePreview(JFileChooser fc) {
        setPreferredSize(new Dimension(300, 300));
        fc.addPropertyChangeListener(this);
    }

    public void loadImage(Graphics g) {
        drawing = null;
        drawing = new CadDrawing(file.getPath());
        Rectangle2D bounds = drawing.getBounds();
        
   		view = new CadView(drawing);
   		view.setSize(getWidth(), getHeight());

   		double drawingx = drawing.getMaxX() > 0 ? drawing.getMaxX() : getWidth();
   		double drawingy = drawing.getMaxY() > 0 ? drawing.getMaxY() : getHeight();
   		
		double scalew = ((double)this.getWidth() / drawingx) - .02;
		double scaleh =  ((double)this.getHeight() / drawingy) - .02;

		double scale = scalew > scaleh ? scaleh : scalew;
        view.setScale(scale);
		view.redraw(); //setBufferedImage();
		g.drawImage(view.getDrawing().getBufferedImage(), 0, 0, 300, 300, null);
    }

    public void propertyChange(PropertyChangeEvent e) {
        String prop = e.getPropertyName();
    	String newfilename = null;
    	
        if (prop.equals("SelectedFileChangedProperty")) {
        	if (e.getNewValue().toString().equals("-1")) return;
        	if (e.getNewValue().toString().toUpperCase().indexOf(".CAD") == -1 &&
        	    e.getNewValue().toString().toUpperCase().indexOf(".XML") == -1) return;

        	newfilename = ((File)e.getNewValue()).getName();
        	file = new File("./drawings/" + newfilename);
       		if (this.getGraphics() != null)
       			loadImage(this.getGraphics());
        } else {
        	file = null;
        	repaint();
        }
    }

    protected void paintComponent(Graphics g) {
    	//System.out.println("paint component");
        if (file != null) {
        	loadImage(this.getGraphics());
        } else {
        	g.setColor(super.getBackground());
        	g.fillRect(0,0,this.getHeight(), this.getWidth());
        }
    }
}
