/*
 * Created on Jul 25, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.datadrafter.installer;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.swing.JOptionPane;

/**
 * @author Dad
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MyInstaller {

	private String jarFileLocation;
	//private String destDirectoryName;
	//private Class oClass;
	//private CodeSource codeSource;
    ZipFile zipfile = null;
    
	public MyInstaller () {
	}
	
	public boolean homeDirectoryExists(String home_dir) {
		File homedir = new File(home_dir);
		return homedir.exists();
	}
	
	public boolean createDirectories(String home_dir) {
		File homedir = new File(home_dir);
		// create the home directory
		try {
			homedir.mkdir();
		} catch (Exception ex) {
			JOptionPane.showInternalMessageDialog(null, ex.getMessage(), 
												  "Installation Error",
												  JOptionPane.ERROR_MESSAGE);
			return false;
		}
		// create the subdirectories
	   try {
	   		File sfcd = new File(homedir + "./config");
	   		sfcd.mkdirs();
	   		File sfdd = new File(homedir + "./data");
	   		sfdd.mkdirs();
	   		File sfdrd = new File(homedir + "./drawings");
	   		sfdrd.mkdirs();
	   		File sfsvg = new File(homedir + "./drawings/svg");
	   		sfsvg.mkdirs();
	   		File sfdocs = new File(homedir + "./docs");
	   		sfdocs.mkdirs();
	   } catch (Exception ex) {
	   		JOptionPane.showMessageDialog(null, ex.getMessage(), "Install Error",
		    							JOptionPane.ERROR_MESSAGE);
	    	return false;
	   }
	   return true;
	}

	public void extractMyFileFromJAR(String dest, String filename){
		try {
			ZipEntry entry = zipfile.getEntry(filename); //jar.getEntry(filename);
			File efile = new File(dest, filename);
			InputStream in = new BufferedInputStream(zipfile.getInputStream(entry));
			OutputStream out = new BufferedOutputStream(new FileOutputStream(efile));
			byte[] buffer = new byte[2048];
			for (;;)  {
				int nBytes = in.read(buffer);
				if (nBytes <= 0) break;
				out.write(buffer, 0, nBytes);
			}
			out.flush();
			out.close();
			in.close();
	    } catch (Exception e) {
	       e.printStackTrace();
	    }
	}
	
	public boolean copySupportFiles(String supportFileHomeDirectory) {

//	  	try {
//	  		new PrintWriter(new FileWriter("findme.txt"));
//	  	} catch (IOException e) {
//	  		e.printStackTrace();
//	  	}

		DialogStatus oDialogStatus = new DialogStatus("Copying Support Files");
	    oDialogStatus.jLabel1.setText("Copying Support Files");

		jarFileLocation = getClass().getProtectionDomain().getCodeSource().toString().substring(6, getClass().getProtectionDomain().getCodeSource().toString().indexOf("["));
		//jarFileLocation = jarFileLocation.replaceAll("file:/", "file://");
		ClassLoader cl = this.getClass().getClassLoader();
		Thread.currentThread().setContextClassLoader(cl);
	    
		//System.out.println("jar file-> " + jarFileLocation);
	    JOptionPane.showMessageDialog(null,
				"Jar File Location-> " + jarFileLocation,
				"Install Message",
				JOptionPane.ERROR_MESSAGE);
	    
	    Enumeration enumeration = null;
		
	    try {
	    	File ufile = new File(jarFileLocation);
	    	System.out.println("exists-> " + ufile.exists());
	    } catch (Exception ex) {
	    	System.out.println("file error-> " + ex.getMessage());
	    	System.exit(0);
	    	return false;
	    }
	    
	    try {
	    	zipfile = new ZipFile(new File(jarFileLocation), ZipFile.OPEN_READ);
	    	enumeration = zipfile.entries();
	    } catch (IOException ex) {
			JOptionPane.showMessageDialog(null, ex.getMessage(), "Install Message",
					JOptionPane.ERROR_MESSAGE);
			System.exit(0);
			return false;
	    }
	    
	    oDialogStatus.jProgressBar1.setMaximum(zipfile.size());
	   		
	   	int cnt = 0;
	   	while (enumeration.hasMoreElements()) {
	   		ZipEntry nextzipentry = (ZipEntry) enumeration.nextElement();
	   		cnt++;
	   		oDialogStatus.jProgressBar1.setValue(cnt);
	   		String check = nextzipentry.getName();
	   		check = check.toLowerCase();

	   		if (check.indexOf("readme_1.2.txt") != -1) {
	   			extractMyFileFromJAR(supportFileHomeDirectory + "/docs/", nextzipentry.getName());
	   		}else if (check.endsWith(".txt") || check.endsWith(".xml")) {
	   			extractMyFileFromJAR(supportFileHomeDirectory + "/config/", nextzipentry.getName());
	   		} else if (check.endsWith(".properties")) {
	   			extractMyFileFromJAR(supportFileHomeDirectory, nextzipentry.getName());      	
	  		} else if (check.endsWith(".dat")) {
	   			extractMyFileFromJAR(supportFileHomeDirectory + "/data/", nextzipentry.getName());
	   		} else if (check.endsWith(".cad")) {
	   			extractMyFileFromJAR(supportFileHomeDirectory + "/drawings/", nextzipentry.getName());
	   		}
	    }
	    
	    oDialogStatus.jProgressBar1.setValue(1000);
	    oDialogStatus.jLabel1.setText("Complete");
	    
	    try {
	    	Thread.sleep(1000);
	    	oDialogStatus.dispose();
	    } catch (InterruptedException ex) {
	       	ex.printStackTrace();    		
	    }
	    return true;
	 }
}


