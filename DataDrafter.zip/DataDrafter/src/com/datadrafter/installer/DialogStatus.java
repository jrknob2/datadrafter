package com.datadrafter.installer;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.SwingConstants;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class DialogStatus extends JFrame {
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  JPanel jPanel4 = new JPanel();
  JPanel jPanel5 = new JPanel();
  GridLayout gridLayout1 = new GridLayout();
  public JLabel jLabel1 = new JLabel();
  public JProgressBar jProgressBar1 = new JProgressBar();
  JLabel jLabel2 = new JLabel();

  public DialogStatus(String title) {
    setTitle(title);
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  public static void main(String[] args) {
    new DialogStatus("xxxxxxxxxxxxxxxx");
  }
  private void resizeWindow() {
    setSize(new Dimension(402, 115));
    Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
    setLocation( (screen.width - getSize().width) / 2, (screen.height - getSize().height) / 2);
    setVisible(true);
  }

  private void jbInit() throws Exception {
    this.getContentPane().setLayout(borderLayout1);
    jPanel1.setLayout(gridLayout1);
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 16));
    jLabel1.setForeground(Color.black);
    jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel1.setText("www.DataDrafter.com");
    gridLayout1.setRows(3);
    jLabel2.setText("   ");
    this.getContentPane().add(jPanel1, BorderLayout.CENTER);
    jPanel1.add(jLabel1, null);
    jPanel1.add(jLabel2, null);
    jPanel1.add(jProgressBar1, null);
    this.getContentPane().add(jPanel2, BorderLayout.SOUTH);
    this.getContentPane().add(jPanel3, BorderLayout.WEST);
    this.getContentPane().add(jPanel4, BorderLayout.EAST);
    this.getContentPane().add(jPanel5, BorderLayout.NORTH);
      resizeWindow();
    }
}