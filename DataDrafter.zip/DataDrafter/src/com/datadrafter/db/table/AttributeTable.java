/*
 * Created on Dec 29, 2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.datadrafter.db.table;

/****************************************************************************************** 
* Import Section  
*****************************************************************************************/  
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collection;


/****************************************************************************************** 
* start class definition  
* public Attribute()  
* public Collection findAll()  
* public getMethods()  
* public setMethods()  
* 
*****************************************************************************************/  
public class AttributeTable  {

/****************************************************************************************** 
* Global Variable Section  
*****************************************************************************************/  
private java.sql.Connection connection = null;
//private java.sql.PreparedStatement statement = null;
private java.sql.Statement stmt = null;
private java.lang.String sql = null;
private java.lang.String AttributeId;
private java.lang.String FileName;
private java.lang.String DetailId;
private java.lang.String AttId;
private java.lang.String Value;
private java.lang.String StatusId;
private java.lang.String ModifiedDate;
private java.lang.String CreateDate;

/****************************************************************************************** 
* Constuctor Section  
*****************************************************************************************/  
	public AttributeTable() {
	  try {
		this.setAttributeId(new java.lang.String (""));
		this.setFileName(new java.lang.String (""));
		this.setDetailId(new java.lang.String (""));
		this.setAttId(new java.lang.String (""));
		this.setValue(new java.lang.String (""));
		this.setStatusId(new java.lang.String (""));
		this.setModifiedDate(new java.lang.String (""));
		this.setCreateDate(new java.lang.String (""));
		;
	  }
	  catch (Exception ex) {
		ex.printStackTrace();
	  }
	  finally {
		;
	  }
	}

/****************************************************************************************** 
* Main use this for testing  
*****************************************************************************************/  
	public static void main(String[] args) {
	  //AttributeTable o = new AttributeTable();
	  //System.err.println("Table Size->" + o.findAll().size());
	}

/****************************************************************************************** 
* finder methods Section  
*****************************************************************************************/  
	public Collection findAll() {
	  ArrayList oArrayList = new ArrayList();
	  try {
		sql = "SELECT * FROM Attribute";
		connection = Db.getConnection("mysql");
		stmt = connection.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next()) {
		  AttributeTable o = new AttributeTable();
		  o.setAttributeId((java.lang.String)rs.getObject("AttributeId"));
		  o.setFileName((java.lang.String)rs.getObject("FileName"));
		  o.setDetailId((java.lang.String)rs.getObject("DetailId"));
		  o.setAttId((java.lang.String)rs.getObject("AttId"));
		  o.setValue((java.lang.String)rs.getObject("Value"));
		  o.setStatusId((java.lang.String)rs.getObject("StatusId"));
		  o.setModifiedDate((java.lang.String)rs.getObject("ModifiedDate"));
		  o.setCreateDate((java.lang.String)rs.getObject("CreateDate"));
		  oArrayList.add(o);
		}
	  }
	catch (Exception ex) {ex.printStackTrace();}
	finally {closeConnection(connection);}
	  return oArrayList;
	}

	public Collection findByFileName(java.lang.String FileName) {
	  ArrayList oArrayList = new ArrayList();
	  try {
		sql = "SELECT * FROM Attribute where FileName = '" + FileName + "'";
		connection = Db.getConnection("mysql");
		stmt = connection.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next()) {
		  AttributeTable o = new AttributeTable();
		  o.setAttributeId((java.lang.String)rs.getObject("AttributeId"));
		  o.setFileName((java.lang.String)rs.getObject("FileName"));
		  o.setDetailId((java.lang.String)rs.getObject("DetailId"));
		  o.setAttId((java.lang.String)rs.getObject("AttId"));
		  o.setValue((java.lang.String)rs.getObject("Value"));
		  o.setStatusId((java.lang.String)rs.getObject("StatusId"));
		  o.setModifiedDate((java.lang.String)rs.getObject("ModifiedDate"));
		  o.setCreateDate((java.lang.String)rs.getObject("CreateDate"));
		  oArrayList.add(o);
		}
	  }
	catch (Exception ex) {ex.printStackTrace();}
	finally {closeConnection(connection);}
	  return oArrayList;
	}

	public AttributeTable findByPrimayKey(java.lang.String AttributeId) {
	  AttributeTable o = null;
	  try {
		sql = "SELECT * FROM Attribute where AttributeId = '" + AttributeId + "'";
		connection = Db.getConnection("mysql");
		stmt = connection.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next()) {
		  o = new AttributeTable();
		  o.setAttributeId((java.lang.String)rs.getObject("AttributeId"));
		  o.setFileName((java.lang.String)rs.getObject("FileName"));
		  o.setDetailId((java.lang.String)rs.getObject("DetailId"));
		  o.setAttId((java.lang.String)rs.getObject("AttId"));
		  o.setValue((java.lang.String)rs.getObject("Value"));
		  o.setStatusId((java.lang.String)rs.getObject("StatusId"));
		  o.setModifiedDate((java.lang.String)rs.getObject("ModifiedDate"));
		  o.setCreateDate((java.lang.String)rs.getObject("CreateDate"));
		}
	  }
	catch (Exception ex) {ex.printStackTrace();}
	finally {closeConnection(connection);}
	  return o;
	}


	public AttributeTable findRecordByRowNumber(int myRow) {
	  AttributeTable o = null;
	  int x = 0;
	  try {
		sql = "SELECT * FROM Attribute";
		connection = Db.getConnection("mysql");
		stmt = connection.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next()) {
		  if(x != myRow) {
			x++;
			continue;
		  }
		  o = new AttributeTable();
		  o.setAttributeId((java.lang.String)rs.getObject("AttributeId"));
		  o.setFileName((java.lang.String)rs.getObject("FileName"));
		  o.setDetailId((java.lang.String)rs.getObject("DetailId"));
		  o.setAttId((java.lang.String)rs.getObject("AttId"));
		  o.setValue((java.lang.String)rs.getObject("Value"));
		  o.setStatusId((java.lang.String)rs.getObject("StatusId"));
		  o.setModifiedDate((java.lang.String)rs.getObject("ModifiedDate"));
		  o.setCreateDate((java.lang.String)rs.getObject("CreateDate"));
		return o;
		}
	  }
	catch (Exception ex) {ex.printStackTrace();}
	finally {closeConnection(connection);}
	  return o;
	}


/****************************************************************************************** 
* get Section  
*****************************************************************************************/  
	public java.lang.String getAttributeId() {
	  return AttributeId;
	}
	public java.lang.String getFileName() {
	  return FileName;
	}
	public java.lang.String getDetailId() {
	  return DetailId;
	}
	public java.lang.String getAttId() {
	  return AttId;
	}
	public java.lang.String getValue() {
	  return Value;
	}
	public java.lang.String getStatusId() {
	  return StatusId;
	}
	public java.lang.String getModifiedDate() {
	  return ModifiedDate;
	}
	public java.lang.String getCreateDate() {
	  return CreateDate;
	}

/****************************************************************************************** 
* set Section  
*****************************************************************************************/  
	  public void setAttributeId(java.lang.String AttributeId) {
		this.AttributeId = AttributeId;
	  }
	  public void setFileName(java.lang.String FileName) {
		this.FileName = FileName;
	  }
	  public void setDetailId(java.lang.String DetailId) {
		this.DetailId = DetailId;
	  }
	  public void setAttId(java.lang.String AttId) {
		this.AttId = AttId;
	  }
	  public void setValue(java.lang.String Value) {
		this.Value = Value;
	  }
	  public void setStatusId(java.lang.String StatusId) {
		this.StatusId = StatusId;
	  }
	  public void setModifiedDate(java.lang.String ModifiedDate) {
		this.ModifiedDate = ModifiedDate;
	  }
	  public void setCreateDate(java.lang.String CreateDate) {
		this.CreateDate = CreateDate;
	  }

/****************************************************************************************** 
* START DB Stuff  
*****************************************************************************************/  
  public void databaseSave() {
	String sql = "";
	try {
	AttributeTable o = new AttributeTable().findByPrimayKey(this.AttributeId);
	if (o != null) {
		databaseUpdate();
	  return;
	}
	  this.setAttributeId(createPKThisProgram());
	  sql = "INSERT INTO Attribute (";
	  sql += " AttributeId,FileName,DetailId,AttId,Value,StatusId,ModifiedDate,CreateDate";
	  sql += ") VALUES (";
	  sql += " '" + this.AttributeId + "','" + this.FileName + "','" + this.DetailId + "','" + this.AttId + "','" + this.Value + "','" + this.StatusId + "','" + this.ModifiedDate + "','" + this.CreateDate + "'";
	  sql += ");";
	  connection = Db.getConnection("mysql");
	  stmt = connection.createStatement();
	  stmt.execute(sql);
	}
  catch (Exception ex) {
//	new JOptionPane().showMessageDialog(new JFrame(),ex.toString().substring(23),"ERROR",JOptionPane.ERROR_MESSAGE);
	return;
  }
  finally {closeConnection(connection);}
//  new JOptionPane().showMessageDialog(new JFrame(),"Record Created","",JOptionPane.INFORMATION_MESSAGE);
  }


  private void databaseUpdate() {
	String sql = "";
	try {
	//AttributeTable o = new AttributeTable().findByPrimayKey(this.AttributeId);
	  sql = "UPDATE  Attribute SET ";
	  sql += "AttributeId = '" + this.AttributeId + "' ,"; 
	  sql += "FileName = '" + this.FileName + "' ,"; 
	  sql += "DetailId = '" + this.DetailId + "' ,"; 
	  sql += "AttId = '" + this.AttId + "' ,"; 
	  sql += "Value = '" + this.Value + "' ,"; 
	  sql += "StatusId = '" + this.StatusId + "' ,"; 
	  sql += "ModifiedDate = '" + this.ModifiedDate + "' ,"; 
	  sql += "CreateDate = '" + this.CreateDate + "' ";
	  sql += " WHERE AttributeId = '" + this.AttributeId + "' ";
	  connection = Db.getConnection("mysql");
	  stmt = connection.createStatement();
	  stmt.execute(sql);
	}
  catch (Exception ex) {
//	new JOptionPane().showMessageDialog(new JFrame(),ex.toString().substring(23),"ERROR",JOptionPane.ERROR_MESSAGE);
	return;
  }
  finally {closeConnection(connection);}
//  new JOptionPane().showMessageDialog(new JFrame(),"Record Updated","",JOptionPane.INFORMATION_MESSAGE);
  }


  public void deleteFromDatabase() {
	String sql = "";
	try {
	  sql = "DELETE FROM Attribute ";
	  sql += " WHERE  AttributeId = '" + this.AttributeId + "'";
	  connection = Db.getConnection("mysql");
	  stmt = connection.createStatement();
	  stmt.execute(sql);
	}
  catch (Exception ex) {
//	new JOptionPane().showMessageDialog(new JFrame(),ex.toString().substring(23),"ERROR",JOptionPane.ERROR_MESSAGE);
	return;
  }
  finally {closeConnection(connection);}
//  new JOptionPane().showMessageDialog(new JFrame(),"DELETED","",JOptionPane.INFORMATION_MESSAGE);
  }


  private String createPKThisProgram() {
	// THIS IS NOT A GOOD WAY BUT IT WORKS
	return new Integer(findAll().size()+1).toString();
  }


/****************************************************************************************** 
* END   DB Stuff  
*****************************************************************************************/  


/****************************************************************************************** 
* Close SQL Connection  
*****************************************************************************************/  
	public void closeConnection(Connection connection) {
	  try {
		if (connection != null) {
		  connection.close();
		}
	  }
	  catch (Exception ex) {ex.printStackTrace();}
	}

	public String toString() {
	  try {
		System.err.println("new Record->");
		System.err.println("getAttributeId ->" + getAttributeId());
		System.err.println("getFileName    ->" + getFileName());
		System.err.println("getDetailId    ->" + getDetailId());
		System.err.println("getAttId       ->" + getAttId());
		System.err.println("getValue       ->" + getValue());
		System.err.println("getStatusId    ->" + getStatusId());
		System.err.println("getModifiedDate->" + getModifiedDate());
		System.err.println("getCreateDate  ->" + getCreateDate());
	  }
	  catch (Exception ex) {
		ex.printStackTrace();
	  }
	  finally {
		;
	  }
	  return "";
	}


} // end class definition

