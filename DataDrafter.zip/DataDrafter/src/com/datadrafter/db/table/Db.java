/*
 * Created on Dec 29, 2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.datadrafter.db.table;

/**
 * @author 4site
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
//import java.util.*;
//import java.sql.Connection;
import java.sql.DriverManager;

public class Db {
	public static java.sql.Connection oConnection = null;
	public static void main(String[] args) {
		Db.getConnection("MYSQL");
		System.err.println("STOP");
	}
	
	public static java.sql.Connection getConnection(String DBType) {
		try {//ver 4.0.16
		  Class.forName("com.mysql.jdbc.Driver").newInstance();
		  String m_Server = "localhost";
		  String m_DatabaseName = "DataDrafter";
		  String m_Username = "DataDrafter";
		  String m_Password = "DataDrafter";
		  String url = "jdbc:mysql://" + m_Server + "/" + m_DatabaseName + "?user=" + m_Username + "&password=" + m_Password + "";
		  oConnection = DriverManager.getConnection(url);
		  //oConnection = DriverManager.getConnection("jdbc:mysql://localhost/test?user=monty&password=greatsqldb");
		  return oConnection;
		}
		catch (Exception e) {
		  e.printStackTrace();
		}
		return null;
	}	
}
