package com.datadrafter.events;

import java.util.EventObject;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class ObjectActionEvent extends EventObject {
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
//private Object source;
  private Object target;
  private int action;

  public ObjectActionEvent(Object source, Object target, int action) {
    super(source);
    this.target = target;
    this.action = action;
  }

  public Object getTarget() {
    return target;
  }

  public int getAction() {
    return action;
  }
}