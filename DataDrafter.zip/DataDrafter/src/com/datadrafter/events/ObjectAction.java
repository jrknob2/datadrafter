package com.datadrafter.events;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.EventListenerList;

import com.datadrafter.utils.Utils;

public class ObjectAction
    implements ChangeListener {
  private static boolean DEBUG = false;

  private static EventListenerList listenerList = new EventListenerList();
  	public static final int NEW_REPORT     = 0;
  	public static final int TAB_CHANGED    = 1;
  	//public static final int OBJ_MODIFIED   = 1;
  	public static final int MENU_BROWSE    = 2;
  	public static final int MENU_MAIN      = 3;
  	public static final int MENU_SEARCH    = 4;
  	public static final int MENU_HELP 	   = 5;
  
  public ObjectAction() {
  }

  public void stateChanged(ChangeEvent e) {
  }

  public static void addObjectActionListener(ObjectActionListener l) {
    if (Utils.getProperty("datadrafter.debug.events").equals("true")) {
      System.out.println("ObjectActionListener Registered-> " + l.getClass());
    }
    listenerList.add(ObjectActionListener.class, l);
  }

  public static void removeObjectActionListener(ObjectActionListener l) {
    listenerList.remove(ObjectActionListener.class, l);
  }

  public static void fireObjectActionEvent(Object source, Object payload,
                                             int command) {
    ObjectActionEvent evt = new ObjectActionEvent(source, payload, command);
    if (Utils.getProperty("datadrafter.debug.events").equals("true")) {
      System.out.println(
          "<<<<<<<<<<<<< ObjectActionEvent Fired >>>>>>>>>>>>>>>>");
      System.out.println("Source -> " + source.getClass().getName());
      System.out.println("Target -> " + payload.getClass().getName());
      System.out.println("Command-> " + command);
    }
    Object[] listeners = listenerList.getListenerList();
    for (int i = listeners.length - 2; i >= 0; i -= 2) {
      if (listeners[i] == ObjectActionListener.class) {
        if (DEBUG) {
          System.out.println("Listener-> " +
                             ( (ObjectActionListener) listeners[i + 1]).
                             getClass().getName());
        }
        ( (ObjectActionListener) listeners[i + 1]).shitHappens(evt);
      }
    }
  }
}
