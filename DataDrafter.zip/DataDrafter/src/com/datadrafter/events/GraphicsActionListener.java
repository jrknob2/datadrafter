package com.datadrafter.events;

import java.util.EventListener;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface GraphicsActionListener
    extends EventListener {
  public void shitHappens(GraphicsActionEvent e);
}