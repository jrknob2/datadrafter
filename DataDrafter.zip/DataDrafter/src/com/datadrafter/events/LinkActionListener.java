package com.datadrafter.events;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

import java.util.EventListener;

public interface LinkActionListener
    extends EventListener {
  public void shitHappens(LinkActionEvent e);
}