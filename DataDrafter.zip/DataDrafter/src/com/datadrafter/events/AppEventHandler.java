package com.datadrafter.events;

//import javax.swing.JComboBox;
//import javax.swing.tree.DefaultMutableTreeNode;

import java.awt.Component;
import java.awt.geom.Point2D;
import java.util.Vector;

import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.tree.DefaultMutableTreeNode;

import com.datadrafter.data.AttributeValues;
import com.datadrafter.data.DataEditor;
import com.datadrafter.designer.GraphicsDesigner;
import com.datadrafter.gui.StatusPanel;
import com.datadrafter.gui.custom.HTMLViewPane;
import com.datadrafter.gui.personal.DataDrafter;
import com.datadrafter.links.DataLink;
import com.datadrafter.links.DataLinks;
import com.datadrafter.links.LinkGroup;
import com.datadrafter.links.LinkManager;
import com.datadrafter.links.SearchCriteria;
import com.datadrafter.modeler.Attribs;
import com.datadrafter.modeler.Details;
import com.datadrafter.modeler.ObjectModeler;
import com.datadrafter.modeler.Template;
import com.datadrafter.modeler.Templates;
import com.datadrafter.reports.ReportArea;
import com.datadrafter.reports.ReportGenerator;
import com.datadrafter.tables.TableEditor;
import com.datadrafter.xcad.CadArc;
import com.datadrafter.xcad.CadDrawing;
import com.datadrafter.xcad.CadLine;
import com.datadrafter.xcad.CadPolygon;
import com.datadrafter.xcad.CadRectangle;
import com.datadrafter.xcad.CadShape;
import com.datadrafter.xcad.CadView;

public class AppEventHandler implements LinkActionListener, GraphicsActionListener, ObjectActionListener {

	public static int 		OPEN_REPORT = 1;
	
	static DataDrafter	mainwin	    = null;
	static LinkManager 			linkman  	= null;
	static GraphicsDesigner		graphman 	= null;
	static DataEditor			dataeditor	= null;
	static StatusPanel			statuspan	= null;
	static ObjectModeler    	modeler     = null;
	
	private CadView curr_view = null;
	
	public AppEventHandler() {
		LinkAction.addLinkActionListener(this);
		GraphicsAction.addGraphicsActionListener(this);
		ObjectAction.addObjectActionListener(this);
	}
	
	public void addComponent(Object obj) {
		
		if (obj instanceof DataDrafter) {
			mainwin = (DataDrafter)obj;
		}
		if (obj instanceof LinkManager) {
			linkman = (LinkManager)obj;
		}
		if (obj instanceof GraphicsDesigner) {
			graphman = (GraphicsDesigner)obj;
		}
		if (obj instanceof DataEditor) {
			dataeditor = (DataEditor)obj;
		}
		if (obj instanceof StatusPanel) {
			statuspan = (StatusPanel)obj;
		}
		if (obj instanceof ObjectModeler) {
			modeler = (ObjectModeler)obj;
		}		
	}
	
	public static LinkManager getLinkManager() {return linkman;}
	
	public void shitHappens(LinkActionEvent e) {
		switch (e.getAction()) {
			case (LinkAction.LINK_DELETED): {
			
				if (e.getTarget().getClass().getName().indexOf("DataLink") != -1) {
					DataLink link = (DataLink)e.getTarget();
					if (link.getDrawingId() != -1 && link.getElementId() != -1) {
						CadView view = (CadView)graphman.getViewTable().getCurrentObject();
						CadShape shape = view.getDrawing().getElementById(link.getElementId());
						//CadComponent comp = view.getDrawing().getElementById(link.getElementId());
						if (view.getSelectedShapes().remove(shape)) {
							//view.setBufferedImage();
							view.paint(view.getGraphics());
						}
					}
				}
				break;
			}
			
			case (LinkAction.LINK_SELECTED): {
				
				DataLink link = (DataLink)e.getTarget();
				String userMessage = "[Link Selected] " + link.getName();
				
				linkman.getLinkTable().getParent().validate();
				linkman.getLinkTable().getParent().repaint();
				
				/************************************************************\
				 * process any activity if a drawing is involved			* 
				\************************************************************/
				if (link.getDrawingId() != -1) {
					// check if drawing is already open or not
					openOrActivateDrawing(link.getDrawingId());
				
					if (link.getElementId() != -1) {
						curr_view.getSelectedShapes().clear();
						curr_view.getDrawing().select(curr_view.getSelectedShapes(), link.getElementId());
					}

					curr_view.repaint(); // .paint(curr_view.getGraphics());		    		
				}
			
				/************************************************************\
				 * process link manager										* 
				\************************************************************/

				linkman.linkTable.setDataObject(link, link.toTableData());
				
				/************************************************************\
				 * process data editor										* 
				\************************************************************/
				
				// update the data editor
		    	if (link.getTypeId() == -1) {
		    		dataeditor.clear();
		    		dataeditor.addLinkSummaryTab(link);       			
		    	} else {
		    		AttributeValues values = new AttributeValues(link);
		    		dataeditor.clear();
		    		dataeditor.setValues(values);
		    		dataeditor.addTabs(link);
		    	}
		    	
		    	statuspan.setMessageLabel(userMessage);
		    	
		    	break;				
			}
			
			case (LinkAction.DATA_MODIIED) : {
				System.out.println("data modified");
				dataeditor.getValues().setClean(false);
				break;
			}
			case (LinkAction.GROUP_SELECTED): {
				CadDrawing 	drawing = null;
		    
				LinkGroup 	group 	= (LinkGroup)e.getTarget();
				linkman.groupTable.setDataObject(group, group.toTableData());
		        
				dataeditor.clear();
				dataeditor.addGroupSummaryTab(group);
       		
				if (group.getDrawingId() == -1) return;

				openOrActivateDrawing(group.getDrawingId());
				       		
				break;
			}
			case (LinkAction.LINK_UPDATED): {
				DataLinks.setClean(false);
				linkman.refreshLinkData();
				break;
			}		
			case (LinkAction.DROP_LINKAGE) : {
				//System.out.println("drop linkage");
				Object linkobj = linkman.getCurrentUserObject();
				if (linkobj == null) return;
				if (linkobj instanceof LinkGroup) {  
					((LinkGroup)linkobj).setDrawingId(-1);
				}
				if (linkobj instanceof DataLink) {
					((DataLink)linkobj).setDrawingId(-1);
					((DataLink)linkobj).setElementId(-1);
				}
				linkman.refreshLinkData();
				break;
			}
			case (LinkAction.LINK_TO_ELEMENT) : {
				CadView view = (CadView)graphman.getViewTable().getCurrentObject();
				CadDrawing drawing = view.getDrawing();
				
				if (view.selectedShapes.size() > 1) {
						JOptionPane.showOptionDialog(null,
							"Can't link to multiple elements",
							"Link Error",
							JOptionPane.OK_OPTION,
							JOptionPane.ERROR_MESSAGE,
							null,
							null,
							null);
					return;
				}
		
				if (view.selectedShapes.size() == 0) {
						JOptionPane.showOptionDialog(null,
							"Nothing selected in the drawing",
							"Link Error",
							JOptionPane.OK_OPTION,
							JOptionPane.ERROR_MESSAGE,
							null,
							null,
							null);
					return;
				}
				
				CadShape cshape = (CadShape)view.selectedShapes.get(0);
		
				Object linkobj = linkman.getCurrentUserObject();
				if (linkobj == null) {
						JOptionPane.showOptionDialog(null,
							"No link selected",
							"Link Error",
							JOptionPane.OK_OPTION,
							JOptionPane.ERROR_MESSAGE,
							null,
							null,
							null);
					return;
				}
		
				if (linkobj instanceof LinkGroup) {
						JOptionPane.showOptionDialog(null,
							"Can't link an element to a group",
							"Link Error",
							JOptionPane.OK_OPTION,
							JOptionPane.ERROR_MESSAGE,
							null,
							null,
							null);
					return;
				}

				DataLink link = (DataLink)linkobj;
				link.setDrawingId(drawing.getId());
				link.setElementId(cshape.getId());
				LinkAction.fireObjectActionEvent(link, LinkAction.LINK_UPDATED);
				break;
			}
			case (LinkAction.LINK_TO_DRAWING) : {
				CadView view = (CadView)graphman.getViewTable().getCurrentObject();
				CadDrawing drawing = view.getDrawing();
				
		
				Object linkobj = linkman.getCurrentUserObject();
		
				if (linkobj == null) {
					//int n = 
						JOptionPane.showOptionDialog(null,
							"No link selected",
							"Link Error",
							JOptionPane.OK_OPTION,
							JOptionPane.ERROR_MESSAGE,
							null,
							null,
							null);
					return;
				}
		
				if (linkobj instanceof LinkGroup) {
					LinkGroup group = (LinkGroup)linkobj;
					group.setDrawingId(drawing.getId());
				}

				if (linkobj instanceof DataLink) {
					DataLink link = (DataLink)linkobj;
					link.setDrawingId(drawing.getId());
				}
				break;
			}
			case (LinkAction.APP_CLOSING) : {
		      if (!DataLinks.isClean()) {
		        Object[] options = {
		            "Yes", "No"};
		        int n = JOptionPane.showOptionDialog(null,
		            "There are Link Manager changes that have not been saved. " +
		            "Would you like to save these changes before exiting?",
		            "DataLinks Modified",
		            JOptionPane.YES_NO_OPTION,
		            JOptionPane.QUESTION_MESSAGE,
		            null,
		            options,
		            options[1]);
		        if (n == 0) {
		          DataLinks.toXML();
		        }
		      }
		      if (Attribs.isClean() == false || Details.isClean() == false || Templates.isClean() == false) {
		      	Object[] options = { "Yes", "No" };
				int n =	JOptionPane.showOptionDialog(
							null,
							"There are Object Modeler changes that have not been saved. "
						  + "Would you like to save these changes before exiting?",
							"Object Modeler Modified",
							JOptionPane.YES_NO_OPTION,
							JOptionPane.QUESTION_MESSAGE,
							null,
							options,
							options[1]);
				if (n == 0) {
					if (Attribs.getModified().size() > 0) {
						Attribs.toFile();
					}
					if (Details.getModified().size() > 0) {
						Details.toFile();
					}
					if (Templates.getModified().size() > 0) {
						Templates.toFile();
					}
				}
			  }
		      break;
			}
		}
	}
	

	public void shitHappens(GraphicsActionEvent e) {
	    switch (e.getAction()) {
	    	case (GraphicsAction.ELEM_SELECTED) : {	    		
	    		CadView view = (CadView)e.getSource();
    			CadShape shape = (CadShape)e.getTarget();
   				SearchCriteria criters = new SearchCriteria();
   				criters.setElementId(shape.getId());
   				linkman.current_tree.findNode(linkman.current_tree.rootNode.getUserObject(), criters);
   				graphman.resetElementEditor(shape);
   				break;
    		}
	    	case (GraphicsAction.OPEN_DRAWING) : {
	    		CadDrawing drawing = (CadDrawing)e.getTarget();
    			openOrActivateDrawing(drawing);
       			statuspan.setMessageLabel("[Drawing Opened] " + drawing.getTitle());
    			break;
	    	}
    		case (GraphicsAction.NEW_DRAWING): {
    			CadDrawing drawing = new CadDrawing();
    			drawing.setTitle("Untitled " + mainwin.content_tp.getTabCount());
    			drawing.setClean(true);
    			openOrActivateDrawing(drawing);
    			break;
    		}
    		case (GraphicsAction.DRAWING_MODIFIED): {
    			CadDrawing drawing = (CadDrawing)graphman.getDrawingTable().getCurrentObject();
    			if (drawing == null) return;
    			drawing.setClean(false);
    			graphman.resetDrawingEditor(drawing);
    			CadView view = (CadView)graphman.getViewTable().getCurrentObject();
    			graphman.resetViewEditor(view);
    			
    			if (view == null) return;
				view.paint(view.getGraphics());
    			break;
    		}
    		case (GraphicsAction.ELEM_DRAWN): {
    			String msg = "";
    			CadShape shape = (CadShape)e.getTarget();
    			if (shape instanceof CadLine) {
    				CadLine line = (CadLine)shape;
    				// TODO implement length for selected segments
    				//msg =  "[Length]"; // + Double.toString(line.getLength());
    			}
    			if (shape instanceof CadPolygon) {
    				CadPolygon poly = (CadPolygon)shape;
    				//msg = "[Area]" + Double.toString(poly.getArea());
    			}
    			if (shape instanceof CadRectangle) {
    				CadRectangle rec = (CadRectangle)shape;
    				// TODO implement area calculations for shapes
    				//msg = "[Area]" + Double.toString(rec.getArea());
    			}
    			if (shape instanceof CadArc) {
    				CadArc arc = (CadArc)shape;
    				//msg = "[Area]" + Double.toString(arc.getArea());
    			}
    			statuspan.setMiddleLabel(msg);
    			break;
    		}
    		case (GraphicsAction.ELEM_DELETED): {
    			graphman.resetElementEditor(null);
    			CadShape shape = (CadShape)e.getTarget();
    			CadDrawing drawing = (CadDrawing)e.getSource();
    			GraphicsAction.fireGraphicsActionEvent(this, drawing, GraphicsAction.DRAWING_MODIFIED);

    			SearchCriteria criters = new SearchCriteria();
				criters.setElementId(shape.getId());
				DefaultMutableTreeNode node = linkman.current_tree.findNode(linkman.current_tree.rootNode, criters);
				if (node != null) {
					DataLink link = (DataLink)node.getUserObject();
					link.setDrawingId(-1);
					link.setElementId(-1);
					link.setSavedViewId(-1);
					LinkAction.fireObjectActionEvent(link, LinkAction.LINK_UPDATED);
				}
    			break;
    		}
    		case (GraphicsAction.ELEM_MODIFIED): {
    			graphman.resetElementEditor((CadShape)graphman.getElementTable().getCurrentObject());
    			CadDrawing drawing = (CadDrawing)graphman.getDrawingTable().getCurrentObject();
    			GraphicsAction.fireGraphicsActionEvent(this, drawing, GraphicsAction.DRAWING_MODIFIED);
    			CadView view = (CadView)graphman.getViewTable().getCurrentObject();
    			if (view != null) {
    				//view.setBufferedImage();
    				view.paint(view.getGraphics());
    			}
    			break;
    		}
    		case (GraphicsAction.MOUSE_MOVED): {
    			if (e.getTarget() instanceof Point2D) {
    				Point2D p = (Point2D)e.getTarget();
    				statuspan.setScreenPoint(p);
    			}
    			
    			// TODO implement screen and view points calc in view
//    			if (e.getTarget() instanceof Point2D) {
//    				CadPoint cp = (CadPoint)e.getTarget();
//    				statuspan.setRealPoint(cp);
//    			}
    			break;
    		}
    		case (GraphicsAction.VIEW_MODIFIED): {
    			if (e.getSource() instanceof CadView) {
    				CadView view = (CadView)e.getSource(); 
    				graphman.resetViewEditor(view);
   					//view.setBufferedImage();
   					view.paint(view.getGraphics());
    			}
    			break;
    		}
    		case (GraphicsAction.VIEW_CLOSING): {
    			graphman.clearAllEditors();
    			statuspan.setMessageLabel("[View Closed]");
    			statuspan.setScreenPoint(new Point2D.Double(0.0, 0.0));
    			//statuspan.setRealPoint(new CadPoint(0.0, 0.0));
    			break;
    		}
    		case (GraphicsAction.ACTION_SET): {
    			int index = ((Integer)e.getTarget()).intValue();
    			statuspan.setMessageLabel("[Action Set]"); // "+  
    					// TODO implement action and command strings in cadview
    					//(String)CadView.validActions.get(index));
    			break;
    		}
    		case (GraphicsAction.CMD_POINTS_CLEARED): {
   				statuspan.setMiddleLabel("");
    			break;
    		}
    		case (GraphicsAction.COMMAND_SET): {
    			CadView view = (CadView)graphman.getViewTable().getCurrentObject();    			
    			String cmd = (String)e.getTarget();
    			if (cmd.equals("NONE"))
    				statuspan.setMiddleLabel("");
    			statuspan.setMessageLabel("[Command Set] " + cmd);
    			graphman.resetViewEditor(view);
    			break;
    		}
    		case (GraphicsAction.DOUBLE_CLICK): {
    			linkman.current_tree.selectNextNode();
    			break;
    		}
    		case (GraphicsAction.APP_CLOSING) : {
    			prepareToCloseDrawings();    			
    			break;
    		}
	    }
	}

	public void shitHappens(ObjectActionEvent e) {
		switch (e.getAction()) {
			case (ObjectAction.NEW_REPORT): {
				createOrActivateReport((TableEditor)e.getSource(), (AttributeValues)e.getTarget(), this.dataeditor.getItem());
				break;
			}
			
			case (ObjectAction.MENU_HELP): {
				String title = (String)e.getSource();
				String filep = (String)e.getTarget();
				
				System.out.println("title-> " + title);
				System.out.println("filep-> " + filep);
				
				openOrActivateHelp(title, filep);
				break;
			}			
			case (ObjectAction.TAB_CHANGED) : {
				Component comp = (Component)e.getTarget();
				System.out.println("tab changed-> " + comp.getClass());
				break;
			}
		}
	}
	
	private void openOrActiveDrawing(CadDrawing drawing) {
		boolean drawing_found = false;
		for (int i = 0; i < mainwin.content_tp.getTabCount(); i++) {
			Component comp = mainwin.content_tp.getComponentAt(i);
			if (comp instanceof CadView) {
				if (drawing.getId() == ((CadView)comp).getDrawing().getId()) {
					mainwin.content_tp.setSelectedIndex(i);
					graphman.resetEditors(((CadView)comp));
					curr_view = (CadView)comp;
					drawing_found = true;
				}
			}
		}
		
		// open a new drawing in a new tab
		if (!drawing_found) {
			CadView view = new CadView();
			view.setDrawing(drawing);
			mainwin.content_tp.addTab(drawing.getTitle(), view);
			curr_view = view;
		}		
	}

	private void openOrActivateDrawing(long id) {
		boolean drawing_found = false;
		for (int i = 0; i < mainwin.content_tp.getTabCount(); i++) {
			Component comp = mainwin.content_tp.getComponentAt(i);
			if (comp instanceof CadView) {
				if (id == ((CadView)comp).getDrawing().getId()) {
					mainwin.content_tp.setSelectedIndex(i);
					graphman.resetEditors(((CadView)comp));
					curr_view = (CadView)comp;
					drawing_found = true;
				}
			}
		}
		
		// open a new drawing in a new tab
		if (!drawing_found) {
			CadDrawing drawing = new CadDrawing(id);
			CadView view = new CadView(drawing);
			view.redraw();

			mainwin.content_tp.addXTab(view.getDrawing().getTitle(), view);
			mainwin.content_tp.setSelectedIndex(mainwin.content_tp.getTabCount() - 1);
			graphman.resetEditors(view);
			curr_view = view;
		}		
	}
	
	private void openOrActivateDrawing(CadDrawing drawing) {
		boolean drawing_found = false;
		for (int i = 0; i < mainwin.content_tp.getTabCount(); i++) {
			Component comp = mainwin.content_tp.getComponentAt(i);
			if (comp instanceof CadView) {
				if (drawing.getId() == ((CadView)comp).getDrawing().getId()) {
					mainwin.content_tp.setSelectedIndex(i);
					graphman.resetEditors(((CadView)comp));
					curr_view = (CadView)comp;
					drawing_found = true;
				}
			}
		}
		
		// open a new drawing in a new tab
		if (!drawing_found) {
			CadView view = new CadView(drawing);
			view.redraw();
			mainwin.content_tp.addXTab(view.getDrawing().getTitle(), view);
			mainwin.content_tp.setSelectedIndex(mainwin.content_tp.getTabCount() - 1);
			graphman.resetEditors(view);
			curr_view = view;
		}				
		curr_view.repaint();
	}

	private void prepareToCloseDrawings() {
		for (int i = 0; i < mainwin.content_tp.getTabCount(); i++) {
			Component comp = mainwin.content_tp.getComponentAt(i);
			if (comp instanceof CadView) {
				((CadView)comp).getDrawing().prepareToClose();
			}
		}		
	}
	private void openOrActivateHelp(String title, String filepath) {
		boolean report_found = false;
		if (mainwin.content_tp.getTabCount() > 0) {
			for (int i = 0; i < mainwin.content_tp.getTabCount(); i++) {
				Component comp = mainwin.content_tp.getTabComponentAt(i);
				Box box = (Box)comp;
				JLabel comp2 = (JLabel)box.getComponent(0);
				if (comp2.getText().contains(title)) {
					mainwin.content_tp.setSelectedIndex(i);
					return;
				}
			}
		}
		
		HTMLViewPane browser = new HTMLViewPane(filepath);
		mainwin.content_tp.addXTab(title, browser);
		mainwin.content_tp.setSelectedIndex(mainwin.content_tp.getTabCount() - 1);
	}
			
	public void createOrActivateReport(TableEditor editor, AttributeValues values, String title) { 
		
		String html = "";
  		String xml = "";
			
		if (mainwin.content_tp.getTabCount() > 0) {
			for (int i = 0; i < mainwin.content_tp.getTabCount(); i++) {
				Component comp = mainwin.content_tp.getTabComponentAt(i);
				Box box = (Box)comp;
				JLabel comp2 = (JLabel)box.getComponent(0);
				if (comp2.getText().contains(title)) {
					mainwin.content_tp.setSelectedIndex(i);
					return;
				}
			}
		}

  		xml = values == null ? ReportGenerator.TEST_XML : values.toXML();
			
		try {
			if (values != null) {
				html = ReportGenerator.transform(xml, ReportGenerator.DETAIL_XSL);
			} else {
				String templName = "Type Summary";
				Object[][] data = editor.getTable().getDataObject();
				if (data == null) return;
			
				Template template = null;
				
				xml = "<values>" +
						"<template>" +
							"<name>" + templName + "</name>" +
								"<detail>" +
									"<name>Summary</name>";
										
				for (int i = 0; i < data.length; i++) {
					template = (Template)data[i][0];
					//template = Templates.getDetailTemplate((String)data[i][0]);
					xml += "<value>" +
								"<name>" + data[i][0] + "</name>" +
								"<id>" + template.getId() + "</id>" +
								"<value>" + data[i][1] + "</value>" +
							"</value>";
				}
					
				xml += "</detail></template></values>";
				html = ReportGenerator.transform(xml, ReportGenerator.SUMMARY_XSL);
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return;
		}
			
		ReportArea report = new ReportArea(title, html);
		JScrollPane scroller = new JScrollPane();
		scroller.getViewport().add(report);
		scroller.validate();
		mainwin.content_tp.addXTab(report.getTitle(), report);
		mainwin.content_tp.setSelectedIndex(mainwin.content_tp.getTabCount() - 1);

	}

	public static String getActiveProject() {return linkman.getCurrentGroup().getName(); }
}
