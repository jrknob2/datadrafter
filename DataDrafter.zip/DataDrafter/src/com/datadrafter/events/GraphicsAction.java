package com.datadrafter.events;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.EventListenerList;

import com.datadrafter.utils.Utils;

public class GraphicsAction implements ChangeListener {
	private static boolean DEBUG = false;

  	private static EventListenerList listenerList = new EventListenerList();
  	public static final int NEW_DRAWING        = 0;
  	public static final int DRAWING_MODIFIED   = 1;
  	public static final int MOUSE_MOVED        = 2;
  	public static final int OPEN_DRAWING       = 3;
  	public static final int ELEM_SELECTED      = 4;
  	public static final int FRAME_ACTIVATED    = 5;
  	public static final int DOUBLE_CLICK       = 6;
  	public static final int FRAME_RESIZED      = 7;
  	public static final int VIEW_MODIFIED      = 8;
  	public static final int ACTION_SET         = 9;
  	public static final int VIEW_CLOSING       = 10;
  	public static final int COMMAND_SET        = 11;
  	public static final int ELEM_MODIFIED      = 12;
  	public static final int DRAWING_ATTR_MOD   = 13;
  	public static final int APP_CLOSING        = 14;
  	public static final int ELEM_DRAWN         = 15;
  	public static final int CMD_POINTS_CLEARED = 16;
  	public static final int ELEM_DELETED       = 17;
  	public static final int ELEM_ADDED         = 18;
  	
  	//public static final int DRAWIN_OPENED          = 0;
  	//public static final int ELEM_SELECTED          = 1;
  	//public static final int DRAWING_OPENED         = 2;
  	//public static final int VIEW_OPENED            = 3;
  	//public static final int OPEN_LINK              = 4;
  	//public static final int REDRAW                 = 5;
  	//public static final int UNDO                   = 6;
  	//public static final int CMD_SELECT             = 7;
  	//public static final int CMD_ZOOM_IN            = 8;
  	//public static final int CMD_ZOOM_OUT           = 9;
  	//public static final int REFRESH_DRAWING_EDITOR = 13;
  	//public static final int DRAWING_SAVED          = 14;
  	//public static final int VIEW_MODIFIED          = 15;
  	//public static final int VIEW_SELECTED        	 = 16;
  	//public static final int REFRESH_VIEW_EDITOR    = 17;
  	//public static final int REFRESH_ELEMENT_EDITOR = 18;
  	//public static final int REFRESH_LAYER_EDITOR   = 19;
  	//public static final int REFRESH_LINK_EDITOR    = 20;
  	//public static final int OBJ_MODIFIED           = 22;
  	//public static final int SAVE_ALL               = 23;
  	//public static final int STATE_CHANGED          = 24;
  	//public static final int FRAME_DEACTIVATED      = 26;
  	//public static final int FRAME_CLOSING          = 27;
  	//public static final int MOUSE_MOVED			 = 28;
  	//public static final int VIEW_COMMAND_CHANGED   = 29;
  
  public GraphicsAction() {
  }

  public void stateChanged(ChangeEvent e) {
  }

  public static void addGraphicsActionListener(GraphicsActionListener l) {
    if (Utils.getProperty("datadrafter.debug.events").equals("true")) {
      System.out.println("GraphicsActionListener Registered-> " + l.getClass());
    }
    listenerList.add(GraphicsActionListener.class, l);
  }

  public static void removeGraphicsActionListener(GraphicsActionListener l) {
    listenerList.remove(GraphicsActionListener.class, l);
  }

  public static void fireGraphicsActionEvent(Object source, Object payload,
                                             int command) {
    GraphicsActionEvent evt = new GraphicsActionEvent(source, payload, command);
    if (Utils.getProperty("datadrafter.debug.events").equals("true")) {
      System.out.println(
          "<<<<<<<<<<<<< GraphicsActionEvent Fired >>>>>>>>>>>>>>>>");
      System.out.println("Source -> " + source.getClass().getName());
      System.out.println("Target -> " + payload.getClass().getName());
      System.out.println("Command-> " + command);
    }
    Object[] listeners = listenerList.getListenerList();
    for (int i = listeners.length - 2; i >= 0; i -= 2) {
      if (listeners[i] == GraphicsActionListener.class) {
        if (DEBUG) {
          System.out.println("Listener-> " +
                             ( (GraphicsActionListener) listeners[i + 1]).
                             getClass().getName());
        }
        ( (GraphicsActionListener) listeners[i + 1]).shitHappens(evt);
      }
    }
  }
}
