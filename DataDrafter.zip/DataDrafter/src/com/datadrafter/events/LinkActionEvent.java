package com.datadrafter.events;

/**on
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */
import java.util.EventObject;

public class LinkActionEvent
    extends EventObject {
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private Object target;
  private int action;

  public LinkActionEvent(Object source, Object target, int action) {
    super(source);
    this.target = target;
    this.action = action;
  }

  public Object getTarget() {
    return target;
  }

  public int getAction() {
    return action;
  }
}
