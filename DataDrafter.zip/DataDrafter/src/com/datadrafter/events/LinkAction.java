package com.datadrafter.events;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.EventListenerList;

import com.datadrafter.utils.Utils;

public class LinkAction
    implements ChangeListener {
  private static boolean DEBUG = false;

  private static EventListenerList listenerList = new EventListenerList();
  public static final int LINK_SELECTED     = 0;
  public static final int LINK_UNSELECTED	= 1;
  public static final int GROUP_SELECTED    = 2;
  public static final int LINK_UPDATED		= 3;
  public static final int DROP_LINKAGE		= 4;
  public static final int LINK_TO_DRAWING	= 5;
  public static final int LINK_TO_ELEMENT	= 6;
  public static final int APP_CLOSING       = 7;
  public static final int DATA_MODIIED      = 8;
  public static final int LINK_DELETED      = 9;
  
//  public static final int OBJ_OPEN         = 1;
//  public static final int OBJ_SAVED        = 2;
//  public static final int OBJ_UNSELECTED   = 3;
//  public static final int OBJ_FIND         = 4;
//  public static final int OBJ_SELECT_ROOT  = 5;
//  public static final int OBJ_SEL_NEXT_LNK = 6;
//  public static final int OBJ_LINK_DELETED = 7;
//  public static final int OBJ_NODE_DELETED = 8;
//  public static final int OBJ_ADD_GROUP    = 10;
//  public static final int OBJ_MODIFIED     = 11;
//  public static final int OBJ_NEW_DATALINK = 12;
//  public static final int OBJ_OPEN_LINK    = 13;
//  public static final int OBJ_ADD          = 15;
//  public static final int SAVE_ALL         = 16;

  public LinkAction() {
  }

  public void stateChanged(ChangeEvent e) {
  }

  public static void addLinkActionListener(LinkActionListener l) {
    if (Utils.getProperty("datadrafter.debug.events").equals("true")) {
      System.out.println("LinkActionListener Registered-> " + l.getClass());
    }
    listenerList.add(LinkActionListener.class, l);
  }

  public static void removeObjectActionListener(LinkActionListener l) {
    listenerList.remove(LinkActionListener.class, l);
  }

  public static void fireObjectActionEvent(Object source, int action) {
    fireObjectActionEvent(source, null, action);
  }

  public static void fireObjectActionEvent(Object source, Object target,
                                           int action) {
    LinkActionEvent evt = new LinkActionEvent(source, target, action);

    if (Utils.getProperty("datadrafter.debug.events").equals("true")) {
      System.out.println(
          "<<<<<<<<<<<<<ObjectAction Event Fired >>>>>>>>>>>>>>>>");
      System.out.println("Source -> " + source.getClass().getName());
      System.out.println("Target -> " + target.getClass().getName());
      System.out.println("Command-> " + action);
    }
    Object[] listeners = listenerList.getListenerList();
    for (int i = listeners.length - 2; i >= 0; i -= 2) {
      if (listeners[i] == LinkActionListener.class) {
        if (DEBUG) {
          System.out.println("Listener-> " +
                             ( (LinkActionListener) listeners[i + 1]).
                             getClass().getName());
        }
        ( (LinkActionListener) listeners[i + 1]).shitHappens(evt);
      }
    }
  }
}