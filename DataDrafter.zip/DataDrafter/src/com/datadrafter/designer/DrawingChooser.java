package com.datadrafter.designer;

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDialog;

import com.datadrafter.utils.Utils;

public class DrawingChooser extends JDialog {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DrawingChooser() {
		
		//super((Frame)DataDrafter.getComponent(), "Drawing Chooser", true);
//		 Use a flow layout
		setLayout( new FlowLayout() );

		// Create an OK button
		Button ok = new Button ("OK");
		ok.addActionListener ( new ActionListener()
		{
			public void actionPerformed( ActionEvent e )
			{
				// Hide dialog
				setVisible(false);
			}
		});

		add( new Label ("Click OK to continue"));
		add( ok );
		// Show dialog
		pack();
		Utils.centerDialog(this);
		//setVisible(true);
	}
}
