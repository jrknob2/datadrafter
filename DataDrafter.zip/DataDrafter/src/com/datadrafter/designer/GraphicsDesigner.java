package com.datadrafter.designer;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.geom.Point2D;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import com.datadrafter.beans.XmlSerializer;
import com.datadrafter.beans.XmlSerializer.CadDrawingSerializer;
import com.datadrafter.events.GraphicsAction;
import com.datadrafter.gui.personal.DataDrafter;
import com.datadrafter.gui.custom.HTMLViewPane;
import com.datadrafter.gui.dialogs.ImagePreview;
import com.datadrafter.tables.TableEditor;
import com.datadrafter.utils.ExampleFileFilter;
import com.datadrafter.utils.Utils;
import com.datadrafter.xcad.CadArc;
import com.datadrafter.xcad.CadClipBoard;
import com.datadrafter.xcad.CadDrawing;
import com.datadrafter.xcad.CadFigure;
import com.datadrafter.xcad.CadLabel;
import com.datadrafter.xcad.CadLayer;
import com.datadrafter.xcad.CadLine;
import com.datadrafter.xcad.CadPolyLine;
import com.datadrafter.xcad.CadPolygon;
import com.datadrafter.xcad.CadRectangle;
import com.datadrafter.xcad.CadShape;
import com.datadrafter.xcad.CadView;
import com.datadrafter.xcad.ICadComponent;

public class GraphicsDesigner extends JPanel {

	private static final long serialVersionUID = 1L;
	JSplitPane splitter = new JSplitPane();
	JPanel leftPanel = new JPanel(new BorderLayout());
	JPanel rightPanel = new JPanel(new BorderLayout());
	// JPanel drawingHeaderPanel = new JPanel(new BorderLayout());
	// JPanel viewsHeaderPanel = new JPanel(new BorderLayout());
	// JPanel portalHeaderPanel = new JPanel(new BorderLayout());
	// JPanel layerHeaderPanel = new JPanel(new BorderLayout());
	JPanel drawingEditorPanel = new JPanel(new BorderLayout());
	JPanel viewsEditorPanel = new JPanel(new BorderLayout());
	JPanel elementEditorPanel = new JPanel(new BorderLayout());
	JPanel layersEditorPanel = new JPanel(new BorderLayout());
	JPanel portalEditorPanel = new JPanel(new BorderLayout());

	JComboBox layerSelection = new JComboBox();
	JComboBox viewSelection = new JComboBox();

	JToolBar commandsToolBar = new JToolBar(JToolBar.HORIZONTAL);
	JToolBar drawingToolBar = new JToolBar(JToolBar.HORIZONTAL);
	JToolBar viewToolBar = new JToolBar(JToolBar.HORIZONTAL);
	JToolBar elementToolBar = new JToolBar(JToolBar.HORIZONTAL);
	JToolBar viewsToolBar = new JToolBar(JToolBar.HORIZONTAL);
	JToolBar layersToolBar = new JToolBar(JToolBar.HORIZONTAL);

	JButton openDrawingButton = new JButton();
	JButton newDrawingButton = new JButton();
	JButton saveDrawingButton = new JButton();
	// JButton exportDrawingButton = new JButton();
	JButton layerOrderTopButton = new JButton();
	JButton layerOrderBottomButton = new JButton();
	JButton elementOrderFrontButton = new JButton();
	JButton elementOrderBackButton = new JButton();
	JButton selectButton = new JButton();
	JButton zoomInButton = new JButton();
	JButton zoomOutButton = new JButton();
	JButton panButton = new JButton();
	JButton copyElementButton = new JButton();
	JButton pasteElementButton = new JButton();
	JButton cutElementButton = new JButton();
	JButton deleteElementButton = new JButton();
	JButton newViewButton = new JButton();
	// JButton deleteViewButton = new JButton();
	JButton refreshViewButton = new JButton();
	JButton newLayerButton = new JButton();
	JButton deleteLayerButton = new JButton();
	JButton polylineButton = new JButton();

	JToggleButton helpButton = new JToggleButton();

	ImageIcon polylineIcon;
	ImageIcon openIcon;
	ImageIcon newIcon;
	ImageIcon saveIcon;
	// ImageIcon exportIcon;
	ImageIcon removeIcon;
	ImageIcon deleteIcon;
	ImageIcon addIcon;
	ImageIcon zoomInIcon;
	ImageIcon zoomOutIcon;
	ImageIcon selectIcon;
	ImageIcon panIcon;
	ImageIcon copyIcon;
	ImageIcon pasteIcon;
	ImageIcon cutIcon;
	ImageIcon refreshIcon;
	ImageIcon editIcon;
	ImageIcon elemZFrontIcon;
	ImageIcon elemZBackIcon;
	ImageIcon layerZFrontIcon;
	ImageIcon layerZBackIcon;
	ImageIcon helpIcon;

	String[] columns = { "Property", "Value" };

	protected TableEditor drawingTable = new TableEditor(columns);
	protected TableEditor viewTable = new TableEditor(columns);
	protected TableEditor elementTable = new TableEditor(columns);
	protected TableEditor layerTable = new TableEditor(columns);
	protected TableEditor viewsTable = new TableEditor(columns);

	JTabbedPane tab = new JTabbedPane();
	JLabel header = new JLabel();

	protected ClassLoader cl = null;

	public GraphicsDesigner() {

		setLayout(new BorderLayout());

		splitter.setOrientation(JSplitPane.VERTICAL_SPLIT);

//		header.setFont(new java.awt.Font("Dialog", 1, 11));
//		header.setBorder(BorderFactory.createRaisedBevelBorder());
//		header.setHorizontalAlignment(SwingConstants.CENTER);
//		header.setText("Graphics Designer");

		openDrawingButton.setToolTipText("Open Drawing");
		newDrawingButton.setToolTipText("New Drawing");
		saveDrawingButton.setToolTipText("Save Drawing");
		// exportDrawingButton.setToolTipText("Export SVG Drawing ");
		newViewButton.setToolTipText("New Saved View");
		deleteElementButton.setToolTipText("Delete Element");
		zoomInButton.setToolTipText("Zoom In");
		zoomOutButton.setToolTipText("Zoom Out");
		selectButton.setToolTipText("Select Element");
		panButton.setToolTipText("Pan");
		copyElementButton.setToolTipText("Copy Element");
		pasteElementButton.setToolTipText("Paste Element");
		cutElementButton.setToolTipText("Cut Element");
		deleteLayerButton.setToolTipText("Delete Layer");
		// deleteViewButton.setToolTipText("Delete View");
		newLayerButton.setToolTipText("New Layer");
		refreshViewButton.setToolTipText("Refresh Saved View");
		elementOrderFrontButton.setToolTipText("Move Element Towards Front");
		elementOrderBackButton.setToolTipText("Move Element Towards Back");
		layerOrderTopButton.setToolTipText("Move Layer Towards Front");
		layerOrderBottomButton.setToolTipText("Move Layer Towards Back");

		cl = DataDrafter.class.getClassLoader();

		newIcon = new ImageIcon(cl.getResource("icons/New16.gif"));
		copyIcon = new ImageIcon(cl.getResource("icons/Copy16.gif"));
		pasteIcon = new ImageIcon(cl.getResource("icons/Paste16.gif"));
		cutIcon = new ImageIcon(cl.getResource("icons/Cut16.gif"));
		openIcon = new ImageIcon(cl.getResource("icons/Open16.gif"));
		addIcon = new ImageIcon(cl.getResource("icons/Add16.gif"));
		deleteIcon = new ImageIcon(cl.getResource("icons/Delete16.gif"));
		saveIcon = new ImageIcon(cl.getResource("icons/Save16.gif"));
		// exportIcon = new ImageIcon(cl.getResource("icons/Export16.gif"));
		editIcon = new ImageIcon(cl.getResource("icons/Edit16.gif"));
		elemZFrontIcon = new ImageIcon(cl.getResource("icons/Up16.gif"));
		elemZBackIcon = new ImageIcon(cl.getResource("icons/Down16.gif"));
		layerZFrontIcon = new ImageIcon(cl.getResource("icons/Up16.gif"));
		layerZBackIcon = new ImageIcon(cl.getResource("icons/Down16.gif"));
		helpIcon = new ImageIcon(cl.getResource("icons/Help16.gif"));
		polylineIcon = new ImageIcon(cl.getResource("icons/polyline.png"));

		newDrawingButton.setIcon(newIcon);
		// exportDrawingButton.setIcon(exportIcon);
		copyElementButton.setIcon(copyIcon);
		pasteElementButton.setIcon(pasteIcon);
		cutElementButton.setIcon(cutIcon);
		openDrawingButton.setIcon(openIcon);
		elementOrderFrontButton.setIcon(elemZFrontIcon);
		elementOrderBackButton.setIcon(elemZBackIcon);
		layerOrderTopButton.setIcon(layerZFrontIcon);
		layerOrderBottomButton.setIcon(layerZBackIcon);
		helpButton.setIcon(helpIcon);
		polylineButton.setIcon(polylineIcon);

		helpButton.setFocusable(false);
		helpButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (splitter.getRightComponent() == null) {
					HTMLViewPane html_doc_pane = new HTMLViewPane(
							"./config/html/gd_howto.html");
					splitter.setRightComponent(html_doc_pane);
					splitter.setDividerLocation(splitter.getWidth() / 2);
				} else {
					Component rcomp = splitter.getRightComponent();
					splitter.remove(rcomp);
				}
			}
		});

		openDrawingButton
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(ActionEvent e) {
						JFileChooser jfc = new JFileChooser();
						jfc.setAccessory(new ImagePreview(jfc));
						ExampleFileFilter filter = new ExampleFileFilter();
						filter.addExtension("CAD");
						filter.addExtension("XML");
						jfc.setCurrentDirectory(new File("./drawings"));
						jfc.setFileFilter(filter);
						Utils.centerDialog(jfc);

						int cancel = jfc.showOpenDialog(new CadView());
						if (cancel == 1) {
							return;
						}
						String filename = Utils
								.getProperty("datadrafter.drawings.path")
								+ jfc.getSelectedFile().getName();
						CadDrawing drawing = new CadDrawing(filename);
						GraphicsAction.fireGraphicsActionEvent(this, drawing,
								GraphicsAction.OPEN_DRAWING);
					}
				});
		newDrawingButton.setEnabled(true);
		newDrawingButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GraphicsAction.fireGraphicsActionEvent(this, null,
						GraphicsAction.NEW_DRAWING);
			}
		});
		saveDrawingButton.setIcon(saveIcon);
		saveDrawingButton.setEnabled(true);
		saveDrawingButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CadDrawing drawing = (CadDrawing) drawingTable.getCurrentObject();
				if (drawing == null)
					return;

				try {									
					drawing.toXML("./drawings/" + drawing.getId() + ".XML");
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				drawingTable.setDataObject(drawing, drawing.toTableData());
			}	
		});
				
		// TODO: add svg export (professional)
		// exportDrawingButton.setEnabled(true);
		// exportDrawingButton
		// .addActionListener(new java.awt.event.ActionListener() {
		// public void actionPerformed(ActionEvent e) {
		// if (drawingTable.getCurrentObject() == null) {
		// JOptionPane.showMessageDialog(null,
		// "No drawing to export", "Information",
		// JOptionPane.INFORMATION_MESSAGE);
		// return;
		// }
		// PrintWriter out = null;
		// JFileChooser jfc = new JFileChooser();
		// ExampleFileFilter filter = new ExampleFileFilter("SVG");
		// // jfc.setCurrentDirectory(new File(Utils.getProperty(
		// // "datadrafter.default.filechooser.directory")));
		// jfc.setFileFilter(filter);
		// jfc.setDialogTitle("SVG Export");
		// //jfc.setDialogType(JFileChooser.SAVE_DIALOG);
		// Utils.centerDialog(jfc);
		// CadView view = (CadView) viewTable.getCurrentObject();
		//
		// int cancel = jfc.showDialog(view, "Save");
		// if (cancel == 1) {
		// return;
		// }
		// String filename = Utils
		// .getProperty("datadrafter.default.filechooser.directory")
		// + jfc.getSelectedFile().getName();
		//
		// CadDrawing drawing = (CadDrawing) drawingTable
		// .getCurrentObject();
		// if (drawing == null) {
		// return;
		// }
		// String xml = drawing.toSVG(view);
		//
		// try {
		// out = new PrintWriter(new FileWriter(filename));
		// out.print(xml);
		// out.flush();
		// } catch (IOException ioe) {
		// ioe.printStackTrace();
		// } finally {
		// out.close();
		// }
		//
		// }
		// });
		deleteLayerButton.setIcon(deleteIcon);
		deleteLayerButton.setEnabled(true);
		deleteLayerButton
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(ActionEvent e) {
						CadLayer layer = (CadLayer) layerSelection
								.getSelectedItem();
						if (layer == null)
							return;
						CadDrawing drawing = (CadDrawing) drawingTable
								.getCurrentObject();
						if (drawing == null)
							return;
						if (drawing.getLayers().remove(layer)) {
							// TODO: implement undo delete layer (personal)
							if (drawing.getLayers().size() > 0)
								layerSelection.setSelectedIndex(0);
							resetViewEditor((CadView) viewTable
									.getCurrentObject());
						}
					}
				});
		// TODO: implement saved views (professional)
		// deleteViewButton.setIcon(deleteIcon);
		// deleteViewButton.setEnabled(true);
		// deleteViewButton.addActionListener(new
		// java.awt.event.ActionListener() {
		// public void actionPerformed(ActionEvent e) {
		// SavedView saved_view = (SavedView) viewSelection
		// .getSelectedItem();
		// if (saved_view == null)
		// return;
		// CadDrawing drawing = (CadDrawing) drawingTable
		// .getCurrentObject();
		// if (drawing == null)
		// return;
		// if (drawing.getSavedViews().remove(saved_view)) {
		// drawing.getModified().add(saved_view);
		// if (drawing.getSavedViews().size() > 0)
		// viewSelection.setSelectedIndex(0);
		// }
		// }
		// });

		newLayerButton.setIcon(newIcon);
		newLayerButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CadDrawing drawing = (CadDrawing) drawingTable
						.getCurrentObject();
				if (drawing == null)
					return;
				CadLayer layer = new CadLayer(drawing);
				drawing.getLayers().add(layer);
				// drawing.getModified().add(layer);
				layerSelection.setSelectedItem(layer);
				resetViewEditor((CadView) viewTable.getCurrentObject());
			}
		});

		// refreshIcon = new ImageIcon(cl.getResource("icons/Refresh16.gif"));
		// refreshViewButton.setIcon(refreshIcon);
		//		
		// refreshViewButton.addActionListener(new
		// java.awt.event.ActionListener() {
		// public void actionPerformed(ActionEvent e) {
		// CadView view = (CadView) viewTable.getCurrentObject();
		// if (view == null) return;
		// //SavedView sv = (SavedView) viewsTable.getCurrentObject();
		// boolean updated = false;
		// if (sv.setOrigin(new Point2D.Double(view.getOrigin().getX(),
		// view.getOrigin().getY())))
		// updated = true;
		// if (sv.setHeight(view.getHeight()))
		// updated = true;
		// if (sv.setWidth(view.getWidth()))
		// updated = true;
		// if (sv.setScale(view.getScale()))
		// updated = true;
		// if (updated) {
		// GraphicsAction.fireGraphicsActionEvent(this, view,
		// GraphicsAction.DRAWING_MODIFIED);
		// viewsTable.setDataObject(sv, sv.toTableData());
		// }
		// }
		// });
		// newViewButton.setIcon(newIcon);
		// newViewButton.addActionListener(new java.awt.event.ActionListener() {
		// public void actionPerformed(ActionEvent e) {
		// saveNewView();
		// }
		// });
		// deleteIcon = new ImageIcon(cl.getResource("icons/Delete16.gif"));
		// ;
		// deleteElementButton.setIcon(deleteIcon);
		//		
		// deleteElementButton.addActionListener(new
		// java.awt.event.ActionListener() {
		// public void actionPerformed(ActionEvent e) {
		// CadDrawing drawing = (CadDrawing)drawingTable.getCurrentObject();
		// if (drawing == null) return;
		//
		// CadView view = (CadView)viewTable.getCurrentObject();
		// if (view == null) return;
		//
		// while (view.getSelection().size() > 0) {
		// CadShape shape = (CadShape)view.getSelection().get(0);
		// CadLayer layer = shape.getLayer();
		// view.getSelection().remove(0);
		// if (layer.remove(shape))
		// GraphicsAction.fireGraphicsActionEvent(drawing, shape,
		// GraphicsAction.ELEM_DELETED);
		// }
		// }
		// });

		zoomInIcon = new ImageIcon(cl.getResource("icons/ZoomIn16.gif"));
		zoomInButton.setIcon(zoomInIcon);
		zoomInButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CadView view = (CadView) viewTable.getCurrentObject();
				if (view == null) {
					return;
				}
				double step = Double.parseDouble(Utils
						.getProperty("datadrafter.graphics.zoomstep"));
				view.setAction(CadView.ACT_ZOOM_IN);
				Point2D oldcenter = view.getCenterPoint();
				view.setScale(view.getScale() + step);
				Point2D newcenter = view.getCenterPoint();
				Point2D difcenter = Utils.subtractPoints(oldcenter, newcenter);
				view.setOrigin(Utils.addPoints(view.getOrigin(), difcenter));
				resetViewEditor(view);
				view.redraw();
				// view.setBufferedImage();
				// view.paint(view.getGraphics());
			}
		});
		zoomOutIcon = new ImageIcon(cl.getResource("icons/ZoomOut16.gif"));
		;
		zoomOutButton.setIcon(zoomOutIcon);
		zoomOutButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CadView view = (CadView) viewTable.getCurrentObject();
				if (view == null) {
					return;
				}
				double step = Double.parseDouble(Utils
						.getProperty("datadrafter.graphics.zoomstep"));
				view.setScale(view.getScale() - step);
				resetViewEditor(view);
				// view.setBufferedImage();
				view.paint(view.getGraphics());
			}
		});
		selectIcon = new ImageIcon(cl.getResource("icons/select16.GIF"));
		selectButton.setIcon(selectIcon);
		selectButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CadView view = (CadView) viewTable.getCurrentObject();
				if (view == null)
					return;
				// view.setAction(CadView.ACT_NONE);
				view.points.clear();
				// view.tmp_act_pts_real.clear();
				view.setCommand(CadView.ACT_SELECT);
				// view.tmp_cmd_pts_real.clear();
			}
		});
		panIcon = new ImageIcon(cl.getResource("icons/Zoom16.gif"));
		;
		panButton.setIcon(panIcon);
		panButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CadView view = (CadView) viewTable.getCurrentObject();
				if (view == null)
					return;
				view.setAction(CadView.ACT_PAN);
			}
		});
		copyElementButton
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(ActionEvent e) {
						copyToClipboard();
					}
				});
		cutElementButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cutElement();
			}
		});
		pasteElementButton
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(ActionEvent e) {
						pasteFromClipboard();
					}
				});
		layerSelection.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CadLayer layer = (CadLayer) layerSelection.getSelectedItem();
				if (layer != null) {
					layerTable.setDataObject(layer, layer.toTableData());
				}
			}
		});
		elementOrderFrontButton
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(ActionEvent e) {
						CadLayer layer = (CadLayer) layerTable
								.getCurrentObject();
						if (layer == null)
							return;

						CadShape cshape = (CadShape) elementTable
								.getCurrentObject();

						if (layer.setOrder(cshape, 1))
							GraphicsAction.fireGraphicsActionEvent(this,
									cshape, GraphicsAction.VIEW_MODIFIED);
					}
				});
		elementOrderBackButton
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(ActionEvent e) {
						Object obj = elementTable.getCurrentObject();
						if (obj == null)
							return;

						CadShape shape = (CadShape) obj;
						CadLayer layer = shape.getLayer();

						if (layer.setOrder(shape, -1))
							GraphicsAction.fireGraphicsActionEvent(this, shape,
									GraphicsAction.VIEW_MODIFIED);
					}
				});
		layerOrderTopButton
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(ActionEvent e) {
						CadDrawing drawing = (CadDrawing) drawingTable
								.getCurrentObject();
						if (drawing == null)
							return;

						CadLayer layer = (CadLayer) layerTable
								.getCurrentObject();

						if (drawing.setLayerOrder(layer, 1)) {
							GraphicsAction.fireGraphicsActionEvent(this, layer,
									GraphicsAction.VIEW_MODIFIED);
						}
					}
				});
		layerOrderBottomButton
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(ActionEvent e) {
						CadDrawing drawing = (CadDrawing) drawingTable
								.getCurrentObject();
						if (drawing == null)
							return;

						CadLayer layer = (CadLayer) layerTable
								.getCurrentObject();

						if (drawing.setLayerOrder(layer, -1)) {
							GraphicsAction.fireGraphicsActionEvent(this, layer,
									GraphicsAction.VIEW_MODIFIED);
						}
					}
				});

		// helpDrawingButton
		// .addActionListener(new java.awt.event.ActionListener() {
		// public void actionPerformed(ActionEvent e) {
		// String html = "";
		// String line = "";
		//				
		// try {
		// BufferedReader in = new BufferedReader(new
		// FileReader("docs/html/gd_drawing.html"));
		// try {
		// while ((line = in.readLine()) != null) {
		// html += line;
		// }
		// ReportAreaMDI help = new ReportAreaMDI("Drawing Tab Help", html);
		// ObjectAction.fireObjectActionEvent(this, help,
		// ObjectAction.NEW_REPORT);
		// } catch (IOException e1) {
		// e1.printStackTrace();
		// }
		// } catch (FileNotFoundException e1) {
		// e1.printStackTrace();
		// }
		// }
		// });

		drawingToolBar.add(openDrawingButton, null);
		drawingToolBar.add(saveDrawingButton, null);
		drawingToolBar.add(newDrawingButton, null);
		// drawingToolBar.add(exportDrawingButton, null);
		drawingToolBar.add(helpButton, null);

		viewToolBar.add(selectButton, null);
		viewToolBar.add(zoomInButton, null);
		viewToolBar.add(zoomOutButton, null);
		viewToolBar.add(panButton, null);
		viewToolBar.add(pasteElementButton, null);
		// viewToolBar.add(helpViewButton, null);

		viewsToolBar.add(newViewButton, null);
		// viewsToolBar.add(deleteViewButton, null);
		viewsToolBar.add(refreshViewButton, null);
		// viewsToolBar.add(helpSavedViewsButton, null);

		elementToolBar.add(copyElementButton, null);
		elementToolBar.add(cutElementButton, null);
		elementToolBar.add(deleteElementButton, null);
		elementToolBar.add(elementOrderFrontButton, null);
		elementToolBar.add(elementOrderBackButton, null);
		// elementToolBar.add(helpElementButton, null);

		layersToolBar.add(deleteLayerButton, null);
		layersToolBar.add(newLayerButton, null);
		layersToolBar.add(layerOrderTopButton, null);
		layersToolBar.add(layerOrderBottomButton, null);

		commandsToolBar.add(polylineButton);

		drawingEditorPanel.add(drawingToolBar, BorderLayout.NORTH);
		drawingEditorPanel.add(drawingTable, BorderLayout.CENTER);

		//portalEditorPanel.add(portalHeaderPanel, BorderLayout.NORTH);
		portalEditorPanel.add(viewTable, BorderLayout.CENTER);

//		viewsHeaderPanel.add(viewsToolBar, BorderLayout.NORTH);
//		viewsHeaderPanel.add(viewSelection, BorderLayout.SOUTH);

		//viewsEditorPanel.add(viewsHeaderPanel, BorderLayout.NORTH);
		viewsEditorPanel.add(viewsTable, BorderLayout.CENTER);

		elementEditorPanel.add(elementToolBar, BorderLayout.NORTH);
		elementEditorPanel.add(elementTable, BorderLayout.CENTER);

//		layerHeaderPanel.add(layersToolBar, BorderLayout.NORTH);
//		layerHeaderPanel.add(layerSelection, BorderLayout.SOUTH);

		//layersEditorPanel.add(layerHeaderPanel, BorderLayout.NORTH);
		layersEditorPanel.add(layerTable, BorderLayout.CENTER);

		// CadLayer layer = (CadLayer) layerSelection.getSelectedItem();

		tab.setTabPlacement(SwingConstants.TOP);
		tab.add(drawingEditorPanel, "Drawing");
		tab.add(portalEditorPanel, "View");
		tab.add(elementEditorPanel, "Element");
		tab.add(layersEditorPanel, "Layers");
		tab.add(viewsEditorPanel, "Saved Views");

		tab.addChangeListener(new javax.swing.event.ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				Utils.tabStateChanged(tab);
			}
		});

		tab.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);

		JPanel headerPanel = new JPanel(new BorderLayout());
		headerPanel.add(header, BorderLayout.NORTH);
		headerPanel.add(drawingToolBar, BorderLayout.CENTER);

		leftPanel.add(headerPanel, BorderLayout.NORTH);
		leftPanel.add(tab, BorderLayout.CENTER);

		splitter = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, null);
		splitter.setAutoscrolls(true);
		splitter.setDividerSize(2);

		add(splitter, BorderLayout.CENTER);

		Utils.tabStateChanged(tab);
	}

	public JToolBar getToolBars() {
		JToolBar toolbar = new JToolBar();
		toolbar.addSeparator();
		toolbar.add(drawingToolBar);
		toolbar.addSeparator();
		toolbar.add(viewToolBar);
		toolbar.addSeparator();
		toolbar.add(viewsToolBar);
		toolbar.addSeparator();
		toolbar.add(elementToolBar);
		toolbar.addSeparator();
		toolbar.add(layersToolBar);
		return toolbar;
	}

	public void copyToClipboard() {
		CadView view = (CadView) viewTable.getCurrentObject();
		if (view == null)
			return;
		CadClipBoard.clear();
		CadClipBoard.add(view.getSelectedShapes());
		System.out.println("CadClipBoard-> " + CadClipBoard.size());
	}

	public void cutElement() {
		CadView view = (CadView) viewTable.getCurrentObject();
		if (view == null)
			return;
		CadClipBoard.clear();
		CadClipBoard.add(view.getSelectedShapes());
		view.getDrawing().delete(view.selectedShapes);
		// view.setBufferedImage();
		view.paint(view.getGraphics());
	}

	public void pasteFromClipboard() {
		CadDrawing drawing = (CadDrawing) drawingTable.getCurrentObject();
		CadView view = (CadView) viewTable.getCurrentObject();
		if (drawing == null || view == null)
			return;
		ArrayList elems = CadClipBoard.get();
		Iterator iter = elems.iterator();
		while (iter.hasNext()) {
			Object cshape = iter.next();
			((CadShape) cshape).move(new Point2D.Double(-10, -10));
			drawing.getActiveLayer().add((CadShape) cshape);
		}
		// view.setBufferedImage();
		view.paint(view.getGraphics());
	}

	// private void saveNewView() {
	// CadDrawing drawing = (CadDrawing) drawingTable.getCurrentObject();
	// if (drawing == null) return;
	//		
	// CadView view = (CadView) viewTable.getCurrentObject();
	// if (view == null) return;
	//		
	// int num_views = drawing.getSavedViews().size();
	//
	// SavedView sv = new SavedView(Utils.getUniqueId(), view.getOrigin(),
	// view.getScale(), "View " + ++num_views, view.getParent()
	// .getHeight(), view.getParent().getWidth());
	// drawing.addView(sv);
	// viewSelection.setSelectedItem(sv);
	// }

	// TODO: implement layer undo
	// public void undoLast()
	// CadDrawing drawing = (CadDrawing) drawingTable.getCurrentObject();
	// drawing.getActiveLayer().undo();
	// }

	public void resetEditors(CadView view) {
		clearAllEditors();
		resetDrawingEditor(view.getDrawing());
		resetViewEditor(view);
		resetElementEditor(null);
		resetLayersEditor(view.getDrawing().getLayers());
		// resetViewsEditor(view.getDrawing().getSavedViews());
	}

	public void clearAllEditors() {
		resetDrawingEditor(null);
		resetViewEditor(null);
		resetElementEditor(null);
		resetLayersEditor(null);
		// resetViewsEditor(null);
	}

	public void resetDrawingEditor(CadDrawing drawing) {
		drawingTable.setDataObject(null, new Object[0][0]);
		if (drawing != null) {
			drawingTable.setDataObject(drawing, drawing.toTableData());
			resetLayersEditor(drawing.getLayers());
			// resetViewsEditor(drawing.getSavedViews());
		}
	}

	public void resetViewEditor(CadView view) {
		viewTable.setDataObject(null, new Object[0][0]);
		if (view != null)
			viewTable.setDataObject(view, view.toTableData());
	}

	// public void resetViewsEditor(Vector views) {
	// SavedView saved_view = null;
	// //CadView view = null;
	//
	// viewsTable.setDataObject(views, new Object[0][0]);
	// viewsHeaderPanel.remove(viewSelection);
	// viewSelection = views == null ? new JComboBox() : new JComboBox(views);
	// viewsHeaderPanel.add(viewSelection, BorderLayout.SOUTH);
	//
	// // check to see if a previously selected saved view needs to be
	// // re-applied
	// //view = (CadView) viewTable.getCurrentObject();
	//
	// // if (views != null ) {
	// // if (view != null && view.last_saved_view != null) {
	// // viewSelection.setSelectedItem(view.last_saved_view);
	// // saved_view = view.last_saved_view;
	// // } else {
	// // viewSelection.setSelectedIndex(viewSelection.getItemCount() > 0 ? 0 :
	// // -1);
	// // saved_view = (SavedView) viewSelection.getSelectedItem();
	// // }
	// // }
	//
	// // saved_view = view.last_saved_view;
	// // System.out.println("last saved view-> " + saved_view);
	// // viewSelection.setSelectedItem(saved_view);
	//
	// if (saved_view != null)
	// viewsTable.setDataObject(saved_view, saved_view.toTableData());
	//
	// viewSelection.addActionListener(new java.awt.event.ActionListener() {
	// public void actionPerformed(ActionEvent e) {
	// SavedView last_saved_view = (SavedView) viewSelection
	// .getSelectedItem();
	// if (last_saved_view != null)
	// applySavedView(last_saved_view);
	// GraphicsAction.fireGraphicsActionEvent(this, this,
	// GraphicsAction.VIEW_MODIFIED);
	// }
	// });
	// viewsHeaderPanel.validate();
	// }

	public void resetLayersEditor(ArrayList layers) {
		layerTable.setDataObject(null, new Object[0][0]);
		//layerHeaderPanel.remove(layerSelection);
		layerSelection = layers == null ? new JComboBox() : new JComboBox(
				new Vector(layers));
		layerSelection.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CadLayer layer = (CadLayer) layerSelection.getSelectedItem();
				if (layer != null) {
					layerTable.setDataObject(layer, layer.toTableData());
				}
			}
		});
		layerSelection.setSelectedIndex(layerSelection.getItemCount() > 0 ? 0
				: -1);
		//layerHeaderPanel.add(layerSelection, BorderLayout.SOUTH);
		//layerHeaderPanel.validate();
	}

	public void resetElementEditor(CadShape shape) {
		elementTable.setDataObject(null, new Object[0][0]);
		if (shape != null) elementTable.setDataObject(shape,((ICadComponent)shape).toTableData());

//		if (cadShape instanceof CadLine) {
//			CadLine line = (CadLine) cadShape;
//			elementTable.setDataObject(line, line.toTableData());
//		} else if (cadShape instanceof CadPolyLine) {
//			CadPolyLine lseg = (CadPolyLine) cadShape;
//			elementTable.setDataObject(lseg, lseg.toTableData());
//		} else if (cadShape instanceof CadArc) {
//			CadArc arc = (CadArc) cadShape;
//			elementTable.setDataObject(arc, arc.toTableData());
//		} else if (cadShape instanceof CadPolygon) {
//			CadPolygon poly = (CadPolygon) cadShape;
//			elementTable.setDataObject(poly, poly.toTableData());
//		} else if (cadShape instanceof CadRectangle) {
//			CadRectangle rect = (CadRectangle) cadShape;
//			elementTable.setDataObject(rect, rect.toTableData());
//		} else if (cadShape instanceof CadFigure) {
//			CadFigure item = (CadFigure) cadShape;
//			elementTable.setDataObject(item, item.toTableData());
//		} else if (cadShape instanceof CadLabel) {
//			CadLabel symb = (CadLabel) cadShape;
//			elementTable.setDataObject(symb, symb.toTableData());
//		} else {
//			elementTable.setDataObject(null, new Object[0][0]);
//		}
	}

	// public void applySavedView(SavedView saved_view) {
	// if (saved_view != null) {
	// viewsTable.setDataObject(saved_view, saved_view.toTableData());
	// CadView view = (CadView) viewTable.getCurrentObject();
	// if (view == null)
	// return;
	// view.setSavedView(saved_view);
	// view.setBufferedImage();
	// view.paint(view.getGraphics());
	// }
	// }

	/**
	 * @return Returns the viewTable.
	 */
	public TableEditor getElementTable() {
		return elementTable;
	}

	/**
	 * @return Returns the viewTable.
	 */
	public TableEditor getViewTable() {
		return viewTable;
	}

	/**
	 * @return Returns the drawingTable.
	 */
	public TableEditor getDrawingTable() {
		return drawingTable;
	}
}