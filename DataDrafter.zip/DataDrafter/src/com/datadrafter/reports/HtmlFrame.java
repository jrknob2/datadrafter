package com.datadrafter.reports;

import java.io.IOException;

import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLFrameHyperlinkEvent;

import com.datadrafter.utils.Utils;

//import com.datadrafter.utils.Utils;
/**
 * Html Demo
 *
 * @version 1.7 02/06/13
 * @author Jeff Dinkins
 */
public class HtmlFrame extends JFrame {
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JEditorPane help;

  /**
   * main method allows us to run as a standalone demo.
   */
	public static void main(String[] args) {
		HtmlFrame demo = new HtmlFrame("");
		demo.setSize(800, 500);
		demo.setVisible(true);
	}

	public HtmlFrame(String html) {
		//try {
			help = new JEditorPane();
			help.setEditable(false);
			help.setContentType("text/html");
			this.setSize(800, 600);
			Utils.centerFrame(this);
			help.addHyperlinkListener(createHyperLinkListener());
			//JScrollPane scroller = new JScrollPane();
			//Viewport vp = scroller.getViewport();
			//vp.add(help);
			//this.getContentPane().add(scroller, BorderLayout.CENTER);
			this.getContentPane().add(help);
			help.setText(html);
			//help.paint(help.getGraphics());
		//}
		//catch (MalformedURLException e) {
			//e.printStackTrace();
		//}
		//catch (IOException e) {
			//e.printStackTrace();
		//}
	}

  	public void setText(String html) {
		help.setText(html);
  	}
  	
  	public HyperlinkListener createHyperLinkListener() {
    return new HyperlinkListener() {
      public void hyperlinkUpdate(HyperlinkEvent e) {
        if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
            System.out.println("hyper link event");
        	if (e instanceof HTMLFrameHyperlinkEvent) {
            ( (HTMLDocument) help.getDocument()).processHTMLFrameHyperlinkEvent(
                (HTMLFrameHyperlinkEvent) e);
          }
          else {
            try {
              help.setPage(e.getURL());
            }
            catch (IOException ioe) {
            	ioe.printStackTrace();
            }
          }
        }
      }
    };
  }
}
