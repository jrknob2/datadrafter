/*
 * Created on Mar 13, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.datadrafter.reports;

/**
 * @author Terry Knoblock
 *
 * @
 */
import java.util.Iterator;
import java.util.Vector;

import com.datadrafter.data.AttributeValues;
import com.datadrafter.links.DataLink;
import com.datadrafter.links.DataLinks;
import com.datadrafter.modeler.Template;

public class WebReports {
	
    public WebReports() {
	} 
	
	public String tabLayout(DataLink link, int start_tab, int num_tabs, int tab) {
		AttributeValues values = new AttributeValues(link);
		return values.toHTMLTable(start_tab, num_tabs, tab);
	}
	public String typeCount(DataLink link) {
		Vector types = DataLinks.getAllDataTypes(link);
		String html = ""; //"<p>&nbsp;</p>";
		
		html += "<b><font class=reportTitle>";
		html += "<br>Type Summary for " + link.getName() + "</font></b>";
		html += "<table border=1 nowrap>";
		html += "<tr style=background-color:#555555>";
		html += "  <td width=30% nowrap><font class=tableHeader><b>Types</b></font></td>";
		html += "  <td width=70% nowrap><font class=tableHeader><b>Total</b></font></td>";
		html += "</tr>";
		if (types != null) {
		  Iterator iter = types.iterator();
		  while (iter.hasNext()) {
			Template template = (Template) iter.next();
			//html += "<tr>";
			html += "<tr><td width=\"77%\"><font class=tableData><a href=javascript:typeSelected(\"" + template.getId() + "\");>";
			html += "<font size=\"2\">" + template.getName() + "</a><font size=\"1\"> </font></font>";
			html += "<td width=\"23%\"><font class=tableData>";
			html += DataLinks.getDataTypeCount(template, link) + "</font></td></tr>";
		  }
		} else {
		  html += "  <tr>";
		  html += "    <td width=100% colspan=2>";
		  html += "    <font class=tableData>No Data</font></td>";
		  html += "  </tr>";
		}

		html += "</table><br>";
		
		return html;
	}
}
