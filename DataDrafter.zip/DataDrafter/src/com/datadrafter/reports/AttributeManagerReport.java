package com.datadrafter.reports;

import java.util.Date;
import java.util.Enumeration;

import javax.swing.JFrame;

import com.datadrafter.modeler.Attrib;
import com.datadrafter.modeler.Detail;
import com.datadrafter.modeler.Template;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
public class AttributeManagerReport
    extends JFrame {
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
Template template;
  String html;

  public AttributeManagerReport(Template template) {
    this.template = template;
  }

  public String generateHTML() {
//      htmlTop();
    html = "<font face=Tahoma>";
    html += "<p><font size=5>Attribute Manager Report</p>";
    html += new Date(System.currentTimeMillis());
    html += "<hr>";
    html = "<font face=Tahoma>";
    html += "<b>template-&gt;&nbsp;</b>" + template.getName() + "<br>\n";

    Enumeration details_enum = template.getDetails().elements();
    while (details_enum.hasMoreElements()) {
      Detail detail = (Detail) details_enum.nextElement();
      html += "&nbsp;&nbsp;<b>detail-&gt;&nbsp;</b>" + detail.getName() +
          "<br>\n";

      Enumeration attribs_enum = detail.getAttributes().elements();
      while (attribs_enum.hasMoreElements()) {
        Attrib attrib = (Attrib) attribs_enum.nextElement();
        html += "&nbsp;&nbsp;&nbsp;&nbsp;<b>attribute-&gt;&nbsp;</b>" +
            attrib.getName() + "<br>\n";
      }
    }
    html += "</font>&nbsp;";
//        htmlBottom();
    return html;
  }

//  private void htmlTop() {
//    html = "<html>\r\n ";
//    html = html.concat("<head>\r\n ");
//    html = html.concat("<title></title>\r\n ");
//    html = html.concat(
//        "<script id=\"clientEventHandlersJS\" language=\"javascript\">\r\n ");
//    html = html.concat("<!--\r\n ");
//    html = html.concat("\r\n ");
//    html = html.concat("function Button1_onclick() {\r\n ");
//    html = html.concat("	document.print();\r\n ");
//    html = html.concat("}\r\n ");
//    html = html.concat("\r\n ");
//    html = html.concat("//-->\r\n ");
//    html = html.concat("		</script>\r\n ");
//    html = html.concat("</head>\r\n");
//    html = html.concat("<body>\r\n");
//    html = html.concat("<form name=\"form1\">\r\n");
//    html = html.concat("<INPUT type=\"button\" value=\"Print\" NAME=\"Button1\" onclick=\"return Button1_onclick()\">\r\n");
//  }
//
//  private void htmlBottom() {
//    html = html.concat("</form>\r\n");
//    html = html.concat("</body>\r\n</html>\r\n");
//
//  }
}
