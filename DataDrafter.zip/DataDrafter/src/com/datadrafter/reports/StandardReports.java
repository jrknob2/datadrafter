package com.datadrafter.reports;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.tree.DefaultMutableTreeNode;

import com.datadrafter.data.AttributeValues;
import com.datadrafter.links.DataLink;
import com.datadrafter.links.DataLinks;
import com.datadrafter.links.LinkGroup;
import com.datadrafter.modeler.Detail;
import com.datadrafter.modeler.Template;
import com.datadrafter.modeler.Templates;

public class StandardReports {
  String          html;
  Object          root_obj;
  DataLink        root_link;
  AttributeValues values;
  Vector          types;
  public String   title;
  String          sel_name;
  String          sel_ltype;
  String          sel_id;
  String          sel_dtype;
  int             tab;
  
  public StandardReports(DefaultMutableTreeNode node, int tab) {
    initialize((Object)node, tab);
  }
  public StandardReports(LinkGroup group, int tab) {
    initialize((Object)group, tab);
  }
  public StandardReports(DataLink link, int tab) {
    initialize((Object)link, tab);
  }
  public StandardReports(Object obj, int tab) {
    initialize(obj, tab);
  }
  public StandardReports(Object obj) {
    initialize(obj);
  }
  public StandardReports(Template template) {
    html = "<html>";
    html += "<head>";
    html += "<body bgcolor=#CCCCCC>";
    html +=
        "<p><font size=4><b><font face=Tahoma>Detail Template Report</font></b><br>";
    html += "<font size=3>" + new Date(System.currentTimeMillis()) + "<br>";
    title = "Detail Template Report";
  }

  public String generateHTML(Template templ) {
    html += "<table border=0 cellpadding=0 cellspacing=0 width=100%>";
    html += "  <tr bgcolor=#006666>";
    html += "    <td><font face=Tahoma color=#FFFFFF><b>" + templ.getName() +
        "</b></font></td>";
    html += "  </tr>";
    html += "  <tr bgcolor=#000000>";
    html += "    <td style=border-left-color: #11111111; border-left-width: 1; border-bottom-style: none; border-bottom-width: medium>";
    html += "    <font face=Tahoma color=#FFFFFF><b>Id</b></font></td>";
    html += "    <td style=border-left-color: #11111111; border-left-width: 1; border-bottom-style: none; border-bottom-width: medium>";
    html +=
        "    <font face=Tahoma color=#FFFFFF><b>Total Details</b></font></td>";
    html += "  </tr>";
    html += "  <tr bgcolor=#FFFFFF>";
    html += "    <td>" + templ.getId() + "</td>";
    html += "    <td>" + templ.getDetails().size() + "</td>";
    html += "  </tr> ";
    html += "</table>&nbsp;";

    html += "<table border=0 cellpadding=0 cellspacing=0 width=100%>";
    html += "  <tr bgcolor=#006666>";
    html += "    <td><font face=Tahoma color=#FFFFFF><b>" + templ.getName() +
        "</b></font></td>";
    html += "  </tr>";
    html += "  <tr bgcolor=#000000>";
    html += "    <td style=border-left-color: #11111111; border-left-width: 1; border-bottom-style: none; border-bottom-width: medium>";
    html +=
        "    <font face=Tahoma color=#FFFFFF><b>Detail Name</b></font></td>";
    html += "    <td style=border-left-color: #11111111; border-left-width: 1; border-bottom-style: none; border-bottom-width: medium>";
    html +=
        "    <font face=Tahoma color=#FFFFFF><b>Number of Attributes</b></font></td>";
    html += "  </tr>";

    int total = 0;
    Enumeration details_enum = templ.getDetails().elements();
    while (details_enum.hasMoreElements()) {
      Detail detail = (Detail) details_enum.nextElement();
      html += "<tr bgcolor=#FFFFFF>";
      html += "  <td>" + detail.getName() + "</td>";
      html += "  <td>" + detail.getAttributes().size() + "</td>";
      html += "</tr> ";
      total += detail.getAttributes().size();
    }

    html += "  <tr bgcolor=#000000>";
    html += "    <td style=border-left-color: #11111111; border-left-width: 1; border-bottom-style: none; border-bottom-width: medium>";
    html +=
        "    <font face=Tahoma color=#FFFFFF><b>Total Attributes</b></font></td>";
    html += "    <td style=border-left-color: #11111111; border-left-width: 1; border-bottom-style: none; border-bottom-width: medium>";
    html += "    <font face=Tahoma color=#FFFFFF>" + total + "</font></td>";
    html += "  </tr>";

    html += "</table>";

    return html;
  }

  public void initialize(Object object, int tab) {
    this.tab = tab;
    if (object instanceof DefaultMutableTreeNode) {
      root_obj = ( (DefaultMutableTreeNode) object).getUserObject();
    }
    else {
      root_obj = object;
    }

    if (root_obj instanceof LinkGroup) {
      LinkGroup group = (LinkGroup) root_obj;
      types = DataLinks.getAllDataTypes(group);
      root_link = (DataLink) DataLinks.getLinks(group).get(0);
      sel_name = group.getName();
      sel_ltype = "Link Group";
      sel_id = Long.toString(group.getId());
      sel_dtype = "Template: " +
          (group.getTypeId() == -1 ? "Not Defined" :
           Templates.getDetailTemplate(group.getTypeId()).getName());
    } else { // must be a datalink
      root_link = (DataLink) root_obj;
      sel_name = root_link.getName();
      sel_ltype = "Data Link";
      sel_id = Long.toString(root_link.getId());
      sel_dtype = "Template: " + (root_link.getTypeId() == -1 ? "Not Defined" :
           Templates.getDetailTemplate(root_link.getTypeId()).getName());
      types = DataLinks.getAllDataTypes(root_link);
    }
    values = new AttributeValues(root_link);

    title = sel_ltype + " Summary Report";
  }

  public void initialize(Object object) {
    if (object instanceof DefaultMutableTreeNode) {
      root_obj = ( (DefaultMutableTreeNode) object).getUserObject();
    }
    else {
      root_obj = object;
    }

    if (root_obj instanceof LinkGroup) {
      LinkGroup group = (LinkGroup) root_obj;
      root_link = (DataLink) DataLinks.getLinks(group).get(0);
      sel_name = group.getName();
      sel_ltype = "Link Group";
      sel_id = Long.toString(group.getId());
      sel_dtype = "Template: " +
          (group.getTypeId() == -1 ? "Not Defined" :
           Templates.getDetailTemplate(group.getTypeId()).getName());
    } else { // must be a datalink
      root_link = (DataLink) root_obj;
      sel_name = root_link.getName();
      sel_ltype = "Data Link";
      sel_id = Long.toString(root_link.getId());
      sel_dtype = "Template: " + (root_link.getTypeId() == -1 ? "Not Defined" :
           Templates.getDetailTemplate(root_link.getTypeId()).getName());
    }
    values = new AttributeValues(root_link);

    title = sel_ltype + " Summary Report";
//    types = DataLinks.getAllDataTypes(root_obj);
  }

  public String getTitle() {
    return title;
  }
  
//  public static String toTypeList(long linkId, long typeId) {
//	//String html = "<font face=Tahoma size=\"2\">" + new Date(System.currentTimeMillis()) + "</f><br>";  	
//	DetailTemplate templ = DetailTemplates.getDetailTemplate(typeId);
//	DataLink link = DataLinks.getDataLink(linkId);
//	
//	String html = "<font face=Tahoma size=\"2\">Locations of type " + templ.getName() + " found in " + link.getName() + "</f><br>";
//	  	
//  	return html + DataLinks.getDataTypeList("", linkId, typeId);
//  }
  public String generateHTML() {
//    String html;

    html = "<html>";
    html += "<head>";
    html += "<body bgcolor=#CCCCCC>";

//    html += "<p><font size=2><b><font face=Tahoma>" + title +
//        "</font></b><font face=Tahoma><br>";
    //html += "<font size=2>" + new Date(System.currentTimeMillis()) + "<br>";

//    html += "<table border=0 cellpadding=0 cellspacing=0 width=100%>";
//    html += "  <tr width=100%>";
//    html += "    <td width=100% colspan=4 bgcolor=#006666 style=border-left-color: #11111111; border-left-width: 1; border-right-color: #111111; border-right-width: 1>";
//    html += "    <font face=Tahoma color=#FFFFFF><b>" + sel_dtype +
//        "</b></font></td>";
//    html += "  </tr>";
//    html += "  <tr width=100% bgcolor=#000000>";
//    html += "    <td style=border-left-color: #11111111; border-left-width: 1; border-bottom-style: none; border-bottom-width: medium>";
//    html += "    <font face=Tahoma color=#FFFFFF><b>Name</b></font></td>";
//    html += "    <td style=border-left-color: #11111111; border-left-width: 1; border-bottom-style: none; border-bottom-width: medium>";
//    html += "    <font face=Tahoma color=#FFFFFF><b>Link Id</b></font></td>";
//    html += "  </tr>";
//    html += "  <tr width=100%>";
//    html += "    <td width=50% style=border-style: none; border-width: small bgcolor=#FFFFFFFF>" +
//        sel_name + "</td>";
//    html += "    <td width=50% style=border-style: none; border-width: small bgcolor=#FFFFFFFF>" +
//        sel_id + "</td>";
//    html += "  </tr> ";
//    	
//    html += "</table>&nbsp;";

	if (root_link.getTypeId() != -1 && tab > 0)
    	html += values.toHTMLTable(1, 10, tab);

    //html += "<p>&nbsp;</p>";
	html += "<b><font face=Tahoma size=3 color=#000000><br>Count Summary</font></b>";
	html += "<table border=1 cellpadding=0 cellspacing=0 width=\"60%\" style=\"border-collapse: collapse\" bordercolor=\"#111111\">";
	html += "<tr style=background-color:#AAAAAA>";    
	html += "<td width=\"77%\" style=background-color:#AAAAAA>";
	html += "<font face=Tahoma size=\"3\"><b>Template</b></font></td>";    
	html += "<td width=\"23%\" bgcolor=#C0C0C0>";
	html += "<font face=Tahoma size=\"3\"><b>Total</b></font></td></tr>";
	if (types != null) {
	  Iterator iter = types.iterator();
	  while (iter.hasNext()) {
		Template template = (Template) iter.next();
		//html += "<tr>";
	    html += "<tr><td width=\"77%\"><font face=\"Tahoma\"><a href=" + template.getId() + ">";
        html += "<font size=\"3\">" + template.getName() + "</a><font size=\"3\"> </font></font>";
        html += "<td width=\"23%\"><font face=\"Tahoma\" size=\"3\">";
        html += DataLinks.getDataTypeCount(template, root_link) + "</font></td></tr>";      }
	} else {
      html += "  <tr>";
      html += "    <td width=100% colspan=2>";
      html += "    <font face=Tahoma size=1 color=#00000000>No Data</font></td>";
      html += "  </tr>";
    }

    html += "</table>";

    html += "</font>&nbsp;";
    html += "</body>";
    html += "</html>";

    return html;

  }
}
