package com.datadrafter.reports;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

public class ReportGenerator {

	public static String DETAIL_XSL = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
		"<xsl:stylesheet version=\"1.0\" " +
		"xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\">" +
		"<xsl:output method=\"html\" encoding=\"UTF-8\"/>" +
		"<xsl:template match=\"/\">" +
		"<html>" +
		  "<body>" +
		    "<h2>" +
		    	"<xsl:value-of select=\"values/templateName\"/> : " +
		    	"<xsl:value-of select=\"values/linkName\"/>" +
		    "</h2>" +
		    
		    "<xsl:for-each select=\"values/detail\">" +
		    	"<h3><xsl:value-of select=\"name\"/></h3>" +
		    	"<table bgcolor=\"#FFFFFF\" width=\"100%\" border=\"0\" cellpadding=\"10\" cellspacing=\"10\">" +
	    			"<xsl:for-each select=\"attribvalue\">" +
	    				"<tr align=\"left\" valign=\"top\">" +
	    					"<td><xsl:value-of select=\"attribname\"/></td>" +
	    					"<td><xsl:value-of select=\"value\"/></td>" +
	    				"</tr>" +
	    			"</xsl:for-each>" +
		    	"</table>" +
    		"</xsl:for-each>" +
		  "</body>" +
		  "</html>" +
		"</xsl:template>" +
		"</xsl:stylesheet>";

	public static String SUMMARY_XSL = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
					"<xsl:stylesheet version=\"1.0\" " +
					"xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\">" +
					"<xsl:output method=\"html\" encoding=\"UTF-8\"/>" +
					"<xsl:template match=\"/\">" +
					"<html>" +
					"<body>" +
					"<h2>Summary: " +
					"<xsl:value-of select=\"values/template/name\"/>" +
					"</h2>" +

					"<h3>" +
					"<xsl:value-of select=\"values/template/detail/name\"/>" +
					"</h3>" +

					"<table width=\"100%\" border=\"0\" cellpadding=\"10\" cellspacing=\"0\">" +
							"<tr>" +
								"<th align=\"left\">Types</th>" +
								"<th align=\"left\">Count</th>" +
							"</tr>" +
							"<xsl:for-each select=\"values/template/detail/value\">" +
								"<tr align=\"left\" valign=\"top\">" +
									"<td><a>" +
										"<xsl:attribute name=\"href\">Summary</xsl:attribute>" +
									    "<xsl:value-of select=\"name\"/></a></td>" +
									"<td><xsl:value-of select=\"value\"/></td>" +
								"</tr>" +
							"</xsl:for-each>" +
						"</table>" +
						"</body>" +
						"</html>" +
						"</xsl:template>" +
						"</xsl:stylesheet>";


	public static String PATH_XSL = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
									"<xsl:stylesheet version=\"1.0\" " +
									"xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\">" +
									"<xsl:output method=\"html\" encoding=\"UTF-8\"/>" +
									"<xsl:template match=\"/\">" +
									"<html>" +
									"<body>" +
									"<h2>Matching Links for : " +
									"<xsl:value-of select=\"paths/name\"/>" +
									"</h2>" +
									"<table width=\"100%\" border=\"0\" cellpadding=\"10\" cellspacing=\"0\">" +
										"<tr>" +
											"<th align=\"left\">Links</th>" +
									"</tr>" +
									"<xsl:for-each select=\"paths/path\">" +
										"<tr align=\"left\" valign=\"top\">" +
										"<td><a>" +
										"<xsl:attribute name=\"href\">" +
										"<xsl:value-of select=\"id\"/></xsl:attribute>" +
										"<xsl:value-of select=\"path\"/></a></td>" +
									"</tr>" +
									"</xsl:for-each>" +
									"</table>" +
									"</body>" +
									"</html>" +
									"</xsl:template>" +
									"</xsl:stylesheet>";
	
	
	public static String TEST_XML = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
	 								"<message>No Data</message>";

	public ReportGenerator() throws Exception {
		
	}

	public static String transform(String xml, String xsl) throws Exception {
		xml = xml.replaceAll("&", "&amp;");
		
	    StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
	    	    
	    Source xmlSource = new StreamSource(new StringReader(xml));
        Source xslSource = new StreamSource(new StringReader(xsl));
        
        TransformerFactory factory = TransformerFactory.newInstance();
        Transformer transformer = factory.newTransformer(xslSource);
        transformer.transform(xmlSource, result);

        return writer.getBuffer().toString();
	}
	
	public static void main(String args[]) {

		try {
			System.out.println(ReportGenerator.transform(ReportGenerator.TEST_XML, ReportGenerator.DETAIL_XSL));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}				
	}
}
