package com.datadrafter.reports;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
import java.awt.BorderLayout;
import java.awt.Rectangle;

import javax.swing.JEditorPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.Element;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLFrameHyperlinkEvent;

import com.datadrafter.events.AppEventHandler;
import com.datadrafter.links.DataLink;
import com.datadrafter.links.DataLinks;
import com.datadrafter.links.LinkGroup;
import com.datadrafter.links.LinkManager;
import com.datadrafter.links.SearchCriteria;
import com.datadrafter.modeler.Template;
import com.datadrafter.modeler.Templates;

//import com.datadrafter.events.*;
//import com.datadrafter.links.*;

public class ReportArea extends JPanel { /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JScrollPane scroller = new JScrollPane();
	private JEditorPane htmlPane = new JEditorPane();
	String              html     = "";
	String				title	 = null;
	
	public ReportArea(String title, String html) {
		this.title = title;
		htmlPane.setEditable(false);
  		htmlPane.setContentType("text/html");
  		htmlPane.addHyperlinkListener(createHyperLinkListener());
  		scroller.setAutoscrolls(false);

  		setSize(600, 500);
    	setLayout(new BorderLayout());
   		htmlPane.setText(html);
   		scroller.getViewport().add(htmlPane);
   		add(scroller, BorderLayout.CENTER);
  		htmlPane.scrollToReference("top");
	}

	public String getTitle() {
		return title;
	}

  	public HyperlinkListener createHyperLinkListener() {
  		return new HyperlinkListener() {
  			public void hyperlinkUpdate(HyperlinkEvent e) {
  				if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
					LinkManager linkman = AppEventHandler.getLinkManager();
  					String[][] paths = null;
  					String descr = e.getDescription();
  					
  					if (!descr.equals("Summary")) {
  	    				SearchCriteria criters = new SearchCriteria();
  	    				criters.setLinkId(Long.parseLong(descr));
  	    				linkman.current_tree.findNode(linkman.current_tree.rootNode.getUserObject(), criters);
  	    				return;
  					}
  					
  					try { 
  						Element elem = e.getSourceElement(); 
  						Document doc = elem.getDocument(); 
  						int start = elem.getStartOffset(); 
  						int end = elem.getEndOffset();
  						String name = doc.getText(start, end-start);
  						Template template = Templates.getDetailTemplate(name);
  						
 						
						try {
							DataLink link = (DataLink)linkman.getCurrentUserObject();
							paths = DataLinks.getLinkPathsByType(template, link);
						} catch (ClassCastException e1) {
							LinkGroup link = (LinkGroup)linkman.getCurrentUserObject();
							paths = DataLinks.getLinkPathsByType(template, link);							
						}
						
						String xml = "<paths>\n<name>" + template.getName() + "</name>\n";
						for (int i = 0; i < paths.length; i++) {
							xml += "<path>\n" + 
								   		"<id>" + paths[i][0] + "</id>\n" +
								   		"<path>" + paths[i][1] + "</path>\n" +
								   "</path>\n";
							//System.out.println("path-> " + path);
						}
						xml += "</paths>";
						
						try {
							html = ReportGenerator.transform(xml, ReportGenerator.PATH_XSL);
							setText(html);
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
 						
  					} catch(BadLocationException ex){ 
  			            ex.printStackTrace(); 
  			        } 


//  					Element elem = e.getSourceElement();
//  					AttributeSet attribs = elem.getAttributes();
//  					Enumeration enumer = attribs.getAttributeNames();
//  					
//  					while (enumer.hasMoreElements()) {
//  						Object obj = enumer.nextElement();
//  						System.out.println("obj-> " + obj.getClass().getName());
//  					}
  					if (e instanceof HTMLFrameHyperlinkEvent) {
  						((HTMLDocument)htmlPane.getDocument()).processHTMLFrameHyperlinkEvent(
  								(HTMLFrameHyperlinkEvent)e);
  					}
  				}
  			}
  		};
  	}

  	public void setText(String html) {
	  	//System.out.println("setting report text");
	  	htmlPane.setText(html);
    	Rectangle r = new Rectangle(0, 0, 1, 1);
    	scrollRectToVisible(r);
  	}

  	public JEditorPane getHtmlPane() {
  		return htmlPane;
  	}
}
