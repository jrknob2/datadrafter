//package com.datadrafter.firehouse;
//
///**
// * <p>Title: </p>
// * <p>Description: </p>
// * <p>Copyright: Copyright (c) 2003</p>
// * <p>Company: </p>
// * @author not attributable
// * @version 1.0
// */
//
//import java.io.BufferedReader;
//import java.io.FileReader;
//import java.io.IOException;
//import java.sql.Connection;
//import java.sql.DatabaseMetaData;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
//import java.sql.ResultSetMetaData;
//import java.sql.SQLException;
//import java.sql.SQLWarning;
//import java.sql.Statement;
//import java.util.Iterator;
//import java.util.NoSuchElementException;
//import java.util.StringTokenizer;
//import java.util.Vector;
//
//import com.datadrafter.modeler.Attrib;
//import com.datadrafter.utils.Utils;
//
//public class FirehouseInterface {
//  DatabaseMetaData dma = null;
//  Connection con = null;
//  Vector tables = new Vector();
//  Vector attribs = new Vector();
//  Vector details = new Vector();
//  Vector templates = new Vector();
//
//  public FirehouseInterface() {
//    try {
//      String url = Utils.getProperty("datadrafter.interfaces.firehouse.url");
//      Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
//      con = DriverManager.getConnection(url, "user", "password");
//
//      checkForWarning(con.getWarnings());
//
//      loadTables();
//      // Get the DatabaseMetaData object and display
//      // some information about the connection
//
//      dma = con.getMetaData();
//      System.out.println("Connected-> " + dma.getURL());
//      System.out.println("Driver-> " + dma.getDriverName());
//      System.out.println("Version-> " + dma.getDriverVersion());
//    }
//    catch (Exception ex) {
//    	ex.printStackTrace();
//    }
//  }
//
//  public Vector getAttributes() {
//    Statement stmt = null;
//    ResultSet rs = null;
//
//    int j = 1;
//    Iterator iter = tables.iterator();
////System.out.println("tables.size()-> " + tables.size());
//    while (iter.hasNext()) {
//      try {
//        String query = "SELECT * FROM " + (String) iter.next() + " WHERE 1=2";
////        System.out.println("query-> " + query);
//        stmt = con.createStatement();
//        rs = stmt.executeQuery(query);
//        dispResultSet(rs);
//
//        ResultSetMetaData rsmd = rs.getMetaData();
//        int numCols = rsmd.getColumnCount();
//        for (int i = 1; i <= numCols; i++) {
//          Attrib attrib = new Attrib(j,
//                                           rsmd.getColumnLabel(i).toUpperCase(),
//                                           rsmd.getColumnLabel(i).toUpperCase());
//          attribs.add(attrib);
//        }
//        ++j;
//
//        rs.close();
//        stmt.close();
//      }
//      catch (SQLException ex) {
//        System.out.println("\n*** SQLException caught ***\n");
//        while (ex != null) {
//          System.out.println("SQLState: " + ex.getSQLState());
//          System.out.println("Message:  " + ex.getMessage());
//          System.out.println("Vendor:   " + ex.getErrorCode());
//          ex = ex.getNextException();
//          System.out.println("");
//        }
//      }
//      catch (java.lang.Exception ex) {
//      	ex.printStackTrace();
//      }
//    }
//    return attribs;
//  }
//
//  public Vector getDetails() {
//    Statement stmt = null;
//    ResultSet rs = null;
//
//    try {
////      dma.getTables()
////      rs = dma.getTables("", "", "", new String[] {"TABLE"});
////      dispResultSet (rs);
//
////      rs.close();
////      stmt.close();
//      con.close();
//
//    }
//    catch (SQLException ex) {
//      System.out.println("\n*** SQLException caught ***\n");
//      while (ex != null) {
//        System.out.println("SQLState: " + ex.getSQLState());
//        System.out.println("Message:  " + ex.getMessage());
//        System.out.println("Vendor:   " + ex.getErrorCode());
//        ex = ex.getNextException();
//        System.out.println("");
//      }
//    }
//    catch (java.lang.Exception ex) {
//      ex.printStackTrace();
//    }
//    return details;
//  }
//
//  private boolean checkForWarning(SQLWarning warn) throws SQLException {
//    boolean rc = false;
//    if (warn != null) {
//      System.out.println("\n *** Warning ***\n");
//      rc = true;
//      while (warn != null) {
//        System.out.println("SQLState: " + warn.getSQLState());
//        System.out.println("Message:  " + warn.getMessage());
//        System.out.println("Vendor:   " + warn.getErrorCode());
//        System.out.println("");
//        warn = warn.getNextWarning();
//
//      }
//    }
//    return rc;
//  }
//
//  private void dispResultSet(ResultSet rs) throws SQLException {
//    int i;
//
//    ResultSetMetaData rsmd = rs.getMetaData();
//    int numCols = rsmd.getColumnCount();
////System.out.println("numCols-> " + numCols);
//    while (rs.next()) {
//      for (i = 1; i <= numCols; i++) {
//
//        System.out.println(rs.getString("TABLE_NAME"));
//      }
//      System.out.println("");
//    }
//  }
//
//  public void loadTables() {
//    String filename = Utils.getProperty(
//        "datadrafter.interfaces.firehouse.tables");
//    String line = null;
//    String sBuff = null;
//    StringTokenizer st;
//    String token;
//    BufferedReader in = null;
//
//    try {
//      in = new BufferedReader(new FileReader(filename));
//      while (true) {
//        line = in.readLine();
//        if (line == null || line.length() == 0) {
//          break;
//        }
//        sBuff = "";
//        st = new StringTokenizer(line, "|");
//        token = st.nextToken();
//        tables.add(new String(token));
//      }
//    }
//    catch (IOException ioe) {
//    	ioe.printStackTrace();
//    }
//    catch (NumberFormatException nfe) {
//    	nfe.printStackTrace();
//    }
//    catch (NoSuchElementException nse) {
//    	nse.printStackTrace();
//    }
//    finally {
//      try {
//        in.close();
//      }
//      catch (IOException ioe) {
//        ioe.printStackTrace();
//      }
//    }
//  }
//}