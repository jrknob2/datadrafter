package com.datadrafter.utils;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Shape;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;

import com.datadrafter.xcad.CadLine;

public class Utils {
  public static Properties props = null;
  public static String props_file = "datadrafter.properties";
  public static DecimalFormat df = null;
  private static String codeBase = "";
  //public static String home_dir = "";
  
  private static long last_id = -1;
//  private static JarResources jar = new JarResources("Resources.jar");

  public Utils() {
  }

  /*******************************************************************\
   *
   \*******************************************************************/
  public static boolean DEBUG = true;
  /*******************************************************************\
   *   \*******************************************************************/
  public static String getClassName(Class c) {
	    String FQClassName = c.getName();
	    int firstChar;
	    firstChar = FQClassName.lastIndexOf ('.') + 1;
	    if ( firstChar > 0 ) {
	      FQClassName = FQClassName.substring ( firstChar );
	      }
	    return FQClassName;
  }
  public static void centerDialog(JFileChooser frame) {
    //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    frame.setLocation( (screenSize.width - frameSize.width) / 2,
                      (screenSize.height - frameSize.height) / 2);
  }

  public static void centerDialog(JDialog frame) {
    //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    frame.setLocation( (screenSize.width - frameSize.width) / 2,
                      (screenSize.height - frameSize.height) / 2);
  }

  /*******************************************************************\
   *
   \*******************************************************************/
  public static void centerWindow(Window win, int width, int height) {
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    win.setLocation( (d.width - width) / 2, (d.height - height) / 2);
  }

  /*******************************************************************\
   *
   \*******************************************************************/
  public static void centerFrame(JFrame frame) {
    //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    frame.setLocation( (screenSize.width - frameSize.width) / 2,
                      (screenSize.height - frameSize.height) / 2);
  }

  /*******************************************************************\
   *
   \*******************************************************************/
  public static void handleError(Component parent, Exception e) {
    Cursor cursor = null;

    if (parent != null) {
      cursor = parent.getCursor();
      parent.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }
    ErrorDialog dialog = new ErrorDialog(null, "Error", true, e);
    if (e.getMessage().length() == 0) {
      dialog.errorTextArea.setText(e.toString());
    }
    else {
      dialog.errorTextArea.setText(e.getMessage());
    }
    dialog.setVisible(true);
    if (parent != null) {
      parent.setCursor(cursor);
    }
  }

  /*******************************************************************\
   *le
   \*******************************************************************/
  public static Point2D getMidPoint(CadLine line) {
    double x1 = line.getVectors().get(0).getX();
    double x2 = line.getVectors().get(1).getX();
    double y1 = line.getVectors().get(0).getY();
    double y2 = line.getVectors().get(1).getY();

    double x3 = Utils.getFormattedDouble((x1 + x2) / 2);
    double y3 = Utils.getFormattedDouble((y1 + y2) / 2);

    return new Point2D.Double(x3, y3);
  }

  public static Point2D addPoints(Point2D p1, Point2D p2) {
    return new Point2D.Double(Utils.getFormattedDouble(p1.getX() + p2.getX()), 
    						  Utils.getFormattedDouble(p1.getY() + p2.getY()));
  }

  public static Point2D subtractPoints(Point2D p1, Point2D p2) {
    return new Point2D.Double(Utils.getFormattedDouble(p1.getX() - p2.getX()), 
    						  Utils.getFormattedDouble(p1.getY() - p2.getY()));
  }

  public static Point2D movePoint(Point p1, Point vec) {
    return addPoints(p1, vec);
  }

  public static double distanceBetween(Point2D p1, Point2D p2) {
    Point2D p3 = subtractPoints(p1, p2);
    return Utils.getFormattedDouble(Math.sqrt(p3.getX() * p3.getX() + p3.getY() * p3.getY()));
  }

//  public static Point2D getUnitVector(Point2D p1, Point2D p2) {
//    double length = distanceBetween(p1, p2);
//    return new Point2D.Double(p2.getX() / length, p2.getY() / length);
//  }

  public static double getDotProduct(Point2D p1, Point2D p2) {
    return Utils.getFormattedDouble(p1.getX() * p2.getX() + p1.getY() * p2.getY());
  }

  public static double getAngle(Point2D p1, Point2D p2) {
    return Utils.getFormattedDouble(Math.acos(getDotProduct(p1, p2)));
  }
  
  public static int angle(int ax, int ay, int bx, int by)
  {
	double result;
	double dx = bx -ax;
	double dy=by-ay; 
	result = (Math.atan2(dx , dy )) * 180 / 3.14;
	result = result - 90;
	if (result < 0)
   {
	result = result + 360;
   }
	return (int)result;
  } 

//  public static CadPoint multiplyPoint(CadPoint p1, double scale) {
//    return new CadPoint(p1.getX() * scale, p1.getY() * scale);
//  }

//  public static Point2D multiplyPoint(Point2D p1, double scale) {
//    return new Point2D.Double(p1.getX() * scale, p1.getY() * scale);
//  }

//  public static CadPoint dividePoint(CadPoint p1, double scale) {
//    return new CadPoint(p1.getX() / scale, p1.getY() / scale);
//  }

//  public static Point2D dividePoint(Point2D p1, double scale) {
//    return new Point2D.Double(p1.getX() / scale, p1.getY() / scale);
//  }

  public static Point2D toReal(Point2D p, Point2D offset, double scale) {
    p = subtractPoints(p, offset);
    return new Point2D.Double(Utils.getFormattedDouble(p.getX() / scale),
                        Utils.getFormattedDouble(p.getY() / scale));
  }
  
  public static Point2D toScreen(Point2D cp, Point2D offset, double scale) {
    Point2D p = addPoints(cp, offset);
    return new Point2D.Double(Utils.getFormattedDouble(p.getX() * scale), 
    						  Utils.getFormattedDouble(p.getY() * scale));
  }

//  public static CadPoint toReal(Point2D p, Point2D offset, double scale) {
//    Point2D p1 = addPoints(p, offset);
//    Point2D p2 = multiplyPoint(p1, scale);
//    return new CadPoint(p1.getX(), p1.getY());
//  }

//  public static Point2D toScreen(CadPoint cp, CadPoint offset, double scale) {
//    CadPoint cp1 = addPoints(cp, offset);
//    CadPoint cp2 = multiplyPoint(cp1, scale);
//    return new Point2D.Double(cp2.getX(), cp2.getY());
//  }

  public static String getProperty(String property) {

  	//System.out.println("props-> " + props);
  	if (props == null) {

//  	  	PrintWriter out = null;
//  	  	try {
//  	  		out = new PrintWriter(new FileWriter("findme.txt"));
//  	  		out.write("Here I am!");
//  	  		out.close();
//  	  	} catch (IOException e) {
//  	  		e.printStackTrace();
//  	  	}
//  	  	
  	  	//System.out.println("opening properties file-> " + home_dir + "/" + props_file);
//  	  	out.println("home_dir-> " + home_dir);
//  	  	out.println("props_file-> " + props_file);
//  	  	out.println("props-> " + props);
  	  	openPropertiesFile();
//  	  	out.println("props-> " + props);
//  	  	out.println("props-> " + props);
//  	  	out.println("property-> " + props.getProperty(property));
//  	  	out.close();

  	}
	//System.out.println("property-> " + property);
  	//System.out.println("property value-> " + props.getProperty(property));
    return props.getProperty(property);
  }
//  public static String getDirAndFiles () {
//    String message = "";  
//  	File dir1 = new File (home_dir);
//
//      try {
//        message = "Current dir : " + dir1.getCanonicalPath() + "/n";
//        if (true) return message;
//        }
//      catch(Exception e) {
//        message = e.getMessage();
//      }
//      message += "Files:/n";
//
//      	String[] children = dir1.list();
//      	    if (children == null) {
//      	        // Either dir does not exist or is not a directory
//      	    } else {
//      	        for (int i=0; i<children.length; i++) {
//      	            // Get filename of file or directory
//      	            message += children[i] + "/n";
//      	        }
//      	    }
//
//      return message;
//  }
  
  public static String getProps() {
  	openPropertiesFile();
  	return props.toString();
  	//return home_dir + "/" + props_file;
  }
  private static void openPropertiesFile() {
  	//String filename = null;
    try {
		FileInputStream fis = new FileInputStream("./" + props_file);
		props = new Properties();
		props.load(fis);
    }
    catch (Exception ex) {
    	try {
    		//System.out.println("getCodeBase()-> " + getCodeBase());
    		URL url = new URL("http://www.datadrafter.com/demo/applet/" + props_file);
    		InputStream is = url.openStream() ; 
    		props = new Properties();
    		props.load(is);
    	} catch (MalformedURLException e) {
    		e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
     }
  }

  public static void resizeColumns(JTable table) {
    TableColumn col = null;
    TableModel tableModel = table.getModel();
    Font font = table.getFont();
    //int columns = tableModel.getColumnCount();
    int rows = tableModel.getRowCount();
    int maxLength = 0;
    String sbuff;

    col = table.getColumnModel().getColumn(0);

    for (int row = 0; row < rows; row++) {
      Object obj = tableModel.getValueAt(row, 0);
      if (obj instanceof String) {
        sbuff = (String) obj;
        if ( (sbuff.length() * font.getSize()) > maxLength) {
          maxLength = sbuff.length() * font.getSize();
        }
      }
    }
    col.setPreferredWidth(maxLength / 3);
  }

  public static long getUniqueId() {
    long id = System.currentTimeMillis();
    while (id == last_id) {
      id = System.currentTimeMillis();
    }
    last_id = id;
    return id;
  }

  public static void tabStateChanged(JTabbedPane tab) {
    int i = tab.getSelectedIndex();
    for (int j = 0; j < tab.getTabCount(); j++) {
      if (j == i) {
        tab.setForegroundAt(i, Color.black);
        tab.setBackgroundAt(i, Color.white);
      }
      else {
        tab.setBackgroundAt(j, Color.darkGray);
        tab.setForegroundAt(j, Color.white);
      }
    }
  }

  public static Polygon getPolygon(ArrayList vectors) {
    int[] xvalues = new int[vectors.size()];
    int[] yvalues = new int[vectors.size()];
    Iterator iter = vectors.iterator();

    int i = 0;
    while (iter.hasNext()) {
      Point2D cp = (Point) iter.next();
      xvalues[i] = (int) cp.getX();
      yvalues[i++] = (int) cp.getY();
    }
    return new Polygon(xvalues, yvalues, vectors.size());
  }
//  public static byte[] getJarResource(String resource) {
//    return jar.getResource(resource);
//  }
  public static String getHexColor(int value) {
    Color clr = new Color(value);
    String red = Integer.toHexString(clr.getRed()).toUpperCase();
    String green = Integer.toHexString(clr.getGreen()).toUpperCase();
    String blue = Integer.toHexString(clr.getBlue()).toUpperCase();

    try {
      if (Integer.parseInt(red) < 10) red = "0" + red;
    } catch (NumberFormatException e) {
      ;
    }
    try {
      if (Integer.parseInt(green) < 10) green = "0" + green;
    } catch (NumberFormatException e) {
      ;
    }
    try {
      if (Integer.parseInt(blue) < 10) blue = "0" + blue;
    } catch (NumberFormatException e) {
      ;
    }
    return red + green + blue;
  }
  	public static String[] getSystemFonts() {
  		GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
    	return env.getAvailableFontFamilyNames();
  	}
  	public static void createPropertiesFile(String filename) {
  		System.out.println("filename-> " + filename);
		try {
			FileWriter fw = new FileWriter(filename, true);
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
  	}
  	public static void checkRegistrationKey() {
  		String key = Utils.getProperty("datadrafter.app.key");
  		
  		if (key != null) return;
  		
  		String prompt = "DataDrafter Personal Edition is free. However, we would\n" +
		                "like you to register your copy. Please send an email to\n" +
						"register@datadrafter.com and a key will be automatically\n" +
						"forwarded to you. When you receive the key via email, simply\n" +
						"enter it below and click OK.For your privacy your email\n" +
						"address will not be retained. The email containing your key will\n" +
						"include directions on how to opt-in to our users mailing list\n" +
						"if you so choose. We appreciate your interest in evaluating\n" +
						"DataDrafter Personal Edition.";
 		
  		String response = ""; 
		response = JOptionPane.showInputDialog(prompt);
		
		if (response == null || response.length() == 0) {
			System.exit(0);
		}
		
		if (response.equals("DDPER11-JJ8675309E9")) {
			JOptionPane.showMessageDialog(null, "Thank you for registering!");
			props.put("datadrafter.app.key", response);
			try {
				//System.out.println("props_file-> " + props_file);
				props.store(new FileOutputStream("./" + props_file), null);
				return;
			} catch (IOException e) {
			  JOptionPane.showMessageDialog(null, e);
			}
		} 
		
		JOptionPane.showMessageDialog(null, response + " is not a valid registration key");
		System.exit(0);			
  	}
  	public static double getFormattedDouble(double value) {
  	  if (df == null) {
  	  	df = new DecimalFormat(Utils.getProperty("datadrafter.config.decimalformat"));
  	  }
  	  // System.out.println("double value-> " + value);
  	  return Double.parseDouble(df.format(value).toString());
  	}
  	public static String convertToLinearUnitOfMeasure(double value) {
  		return "0 Feet 0 Inches";
  	}
	public static String getCodeBase() {
		return codeBase;
	}
	public static void setCodeBase(String codeBase) {
		Utils.codeBase = codeBase;
	}
	public static Shape getControlPoint(Point2D p) {
		// Create a small square around the given point.
		int side = 6;
		return new Rectangle2D.Double(p.getX() - side / 2,
									  p.getY() - side / 2,
									  side, side);
	}
	
	public static String readFileAsString(String filePath)	throws java.io.IOException{
	    StringBuffer fileData = new StringBuffer(1000);
	    BufferedReader reader = new BufferedReader(
	            new FileReader(filePath));
	    char[] buf = new char[1024];
	    int numRead=0;
	    while((numRead=reader.read(buf)) != -1){
	        String readData = String.valueOf(buf, 0, numRead);
	        fileData.append(readData);
	        buf = new char[1024];
	    }
	    reader.close();
	    return fileData.toString();
	}
	
	public static Point2D getMidPoint(Point2D p1, Point2D p2) {
	    double x = Utils.getFormattedDouble((p1.getX() + p2.getX()) / 2);
	    double y = Utils.getFormattedDouble((p1.getY() + p2.getY()) / 2);

	    return new Point2D.Double(x, y);
	}
}
