package com.datadrafter.utils;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class Constants {

  public static final int BUTTON_HEIGHT = 27;
  public static final int BUTTON_WIDTH = 73;

  public static final double DIVS_PER_PART = 512.0;
  public static final double PARTS_PER_UNIT = 12.0;

  public static final int GUI_ACTION_STATE_CHANGED = 9999;

  public static final int GUI_ACTION_ENABLE_UPDATE = 1000;
  public static final int GUI_ACTION_ENABLE_NEW = 1001;
  public static final int GUI_ACTION_ENABLE_DELETE = 1002;
  public static final int GUI_ACTION_ENABLE_VIEW = 1003;
  public static final int GUI_ACTION_DISABLE_UPDATE = 1004;
  public static final int GUI_ACTION_DISABLE_NEW = 1005;
  public static final int GUI_ACTION_DISABLE_DELETE = 1006;
  public static final int GUI_ACTION_DISABLE_VIEW = 1007;
  public static final int GUI_ACTION_CLOSE_FRAME = 1008;
  public static final int GUI_ACTION_OPEN = 1009;
  public static final int GUI_ACTION_VIEW = 1010;
  public static final int GUI_ACTION_UPDATE = 1011;
  public static final int GUI_ACTION_NEW = 1012;
  public static final int GUI_ACTION_DELETE = 1013;
  public static final int GUI_ACTION_ENABLE_OPEN = 1014;
  public static final int GUI_ACTION_DISABLE_OPEN = 1015;
  public static final int GUI_ACTION_MODE_ADMIN = 1016;
  public static final int GUI_ACTION_MODE_OPEN = 1017;
  public static final int GUI_ACTION_MODE_NEW = 1018;
  public static final int GUI_ACTION_MODE_UPDATE = 1019;
  public static final int GUI_ACTION_MODE_VIEW = 1020;
  public static final int GUI_ACTION_MOUSE_MOVED = 1021;
  public static final int GUI_ACTION_CLOSE_DIALOG = 1022;
  public static final int GUI_ACTION_UPDATE_STATE = 1023;
  public static final int GUI_ACTION_OBJ_SELECTED = 1024;
  public static final int GUI_ACTION_REMOVE_NODE = 1025;
  public static final int GUI_ACTION_EXPAND_NODE = 1026;
  public static final int GUI_ACTION_COLLAPSE_NODE = 1027;
  public static final int GUI_ACTION_CMD_HINT = 1028;
  public static final int GUI_ACTION_CMD_ACTIVATED = 1029;
  public static final int GUI_ACTION_CMD_NAME = 1030;
  public static final int GUI_ACTION_GRID_TYPE = 1031;

  public static final int OBJ_ACTION_OPEN = 2000;
  public static final int OBJ_ACTION_UPDATE = 2001;
  public static final int OBJ_ACTION_DELETE = 2002;
  public static final int OBJ_ACTION_VIEW = 2003;
  public static final int OBJ_ACTION_SELECT = 2004;
  public static final int OBJ_ACTION_NEW = 2005;
  public static final int OBJ_ACTION_ENABLE_UPDATE = 2006;
  public static final int OBJ_ACTION_DISABLE_UPDATE = 2007;
  public static final int OBJ_ACTION_ENABLE_NEW = 2008;
  public static final int OBJ_ACTION_DISABLE_NEW = 2009;
  public static final int OBJ_ACTION_ENABLE_DELETE = 2010;
  public static final int OBJ_ACTION_DISABLE_DELETE = 2011;
  public static final int OBJ_ACTION_PEEK = 2012;

  public static final int DAT_ACTION_OBJ_DELETED = 3000;
  public static final int DAT_ACTION_OBJ_UPDATED = 3001;
  public static final int DAT_ACTION_OBJ_CREATED = 3002;

  public static final int CAD_CMD_NONE = 4000;
  public static final int CAD_CMD_FIT_ALL = 4001;
  public static final int CAD_CMD_FIT = 4002;
  public static final int CAD_CMD_VIEW_PAN = 4003;
  public static final int CAD_CMD_VIEW_RESET = 4004;
  public static final int CAD_CMD_VIEW_ZOOMIN = 4005;
  public static final int CAD_CMD_VIEW_ZOOMOUT = 4006;
  public static final int CAD_CMD_VIEW_PAINT = 4007;
  public static final int CAD_CMD_DRAW_AREA = 4008;
  public static final int CAD_CMD_MODIFY_ELEM = 4009;
  public static final int CAD_CMD_VIEW_REFRESH = 4010;
  public static final int CAD_CMD_DRAW_LEVEL = 4010;

  public static final int FUNC_OPEN_SITE = 1;
  public static final int FUNC_NEW_SITE = 2;
  public static final int FUNC_UPDATE_SITE = 3;
  public static final int FUNC_DELETE_SITE = 4;
  public static final int FUNC_VIEW_SITE = 5;

  public static final int SAX_LINKGROUP = 1;
  public static final int SAX_DATALINK  = 2;

  public static final String PROPERTIES_FILE_KEY = "DATADRAFTER_PROPFILE";
  public Constants() {
  }
}
