package com.datadrafter.utils;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
import java.awt.Point;

public class GraphicUtils {
  public GraphicUtils() {
  }

  public static Point addPoints(Point p1, Point p2) {
    return new Point(p1.x + p2.x, p1.y + p2.y);
  }

  public static Point subtractPoints(Point p1, Point p2) {
    return new Point(p1.x - p2.x, p1.y - p2.y);
  }

  public static Point movePoint(Point p1, Point vec) {
    return addPoints(p1, vec);
  }

  public static double length(Point p1, Point p2) {
    Point p3 = subtractPoints(p1, p2);
    return Math.sqrt(p3.x * p3.x + p3.y * p3.y);
  }
  

  public static double distanceBetween(Point p1, Point p2) {
	Point p3 = subtractPoints(p1, p2);
	return Math.sqrt(p3.x * p3.x + p3.y * p3.y);
  }
  public static Point getUnitVector(Point p1, Point p2) {
    double length = distanceBetween(p1, p2);
    return new Point( (int) (p2.x / length), (int) (p2.y / length));
  }

  public static double getDotProduct(Point p1, Point p2) {
    return p1.x * p2.x + p1.y * p2.y;
  }

  public static double getAngle(Point p1, Point p2) {
    return Math.acos(getDotProduct(p1, p2));
  }

  public static Point multiplyPoint(Point p1, double value) {
    return new Point( (int) (p1.x * value), (int) (p1.y * value));
  }

  public static Point dividePoint(Point p1, double value) {
    return new Point( (int) (p1.x / value), (int) (p1.y / value));
  }

  public static Point screenToReal(Point p, Point offset, double scale) {
    p = addPoints(p, offset);
    return multiplyPoint(p, scale);
  }

  public static Point realToScreen(Point p, Point offset, double scale) {
    p = subtractPoints(p, offset);
    return dividePoint(p, scale);
  }
}
