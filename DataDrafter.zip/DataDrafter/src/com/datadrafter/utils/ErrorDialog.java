package com.datadrafter.utils;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class ErrorDialog
    extends JDialog {
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
Exception exception;
  JPanel errorPanel = new JPanel();
  JScrollPane jScrollPane1 = new JScrollPane();
  JPanel labelPanel = new JPanel();
  JLabel jLabel1 = new JLabel();
  JButton closeButton = new JButton();
  JPanel buttonPanel = new JPanel();
  JButton stackButton = new JButton();
  BorderLayout borderLayout1 = new BorderLayout();
  FlowLayout flowLayout2 = new FlowLayout();
  public JTextArea errorTextArea = new JTextArea();
  BorderLayout borderLayout2 = new BorderLayout();

  public ErrorDialog(Frame frame, String title, boolean modal, Exception e) {
    super(frame, title, modal);
    this.exception = e;
    try {
      jbInit();
      pack();
      Dimension d = new Dimension(400, 250);
      this.setSize(d);
      // center window
      Utils.centerWindow(this, this.getWidth(), this.getHeight());
    }
    catch (Exception ex) {
    	ex.printStackTrace();
    }
  }

  void jbInit() throws Exception {
    this.setResizable(false);
    this.setTitle("Error");
    this.getContentPane().setLayout(borderLayout1);

    jScrollPane1.setPreferredSize(new Dimension(340, 200));
    errorPanel.setLayout(borderLayout2);
    jLabel1.setText("Error Message");
    labelPanel.setLayout(flowLayout2);
    closeButton.setMnemonic('C');
    closeButton.setText("Close");
    closeButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        closeButton_actionPerformed(e);
      }
    });
    stackButton.setText("Stack Trace");
    stackButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        stackButton_actionPerformed(e);
      }
    });
    errorTextArea.setText(exception.getMessage());
    errorTextArea.setWrapStyleWord(true);
    errorTextArea.setEditable(false);
    errorTextArea.setBackground(Color.lightGray);
    errorTextArea.setPreferredSize(new Dimension(600, 500));
    errorTextArea.setLineWrap(true);
    buttonPanel.add(closeButton, null);
    buttonPanel.add(stackButton, null);
    this.getContentPane().add(labelPanel, BorderLayout.NORTH);
    labelPanel.add(jLabel1, null);
    this.getContentPane().add(errorPanel, BorderLayout.CENTER);
    errorPanel.add(jScrollPane1, BorderLayout.CENTER);
    this.getContentPane().add(buttonPanel, BorderLayout.SOUTH);
    jScrollPane1.getViewport().add(errorTextArea, null);
  }

  void closeButton_actionPerformed(ActionEvent e) {
    this.dispose();
  }

  void stackButton_actionPerformed(ActionEvent e) {
    java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
    java.io.PrintStream ps = new java.io.PrintStream(baos);
    this.exception.printStackTrace(ps);
    this.errorTextArea.setText(baos.toString());
  }

  public static void main(String[] args) {
    try {
      ErrorDialog ediag = new ErrorDialog(new JFrame("My New Frame"),
                                          "Some Title", true,
                                          new Exception("This is a test"));
      ediag.setVisible(true);
    }
    catch (Exception e) {
    	e.printStackTrace();
    }
  }
}
