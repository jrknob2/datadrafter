/*
 * Created on Mar 2, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.datadrafter.cad.dxf;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import com.datadrafter.xcad.CadArc;
import com.datadrafter.xcad.CadDrawing;
import com.datadrafter.xcad.CadLayer;
import com.datadrafter.xcad.CadPolyLine;
import com.datadrafter.utils.Utils;

/**
 * @author Dad
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DXFDrawingReader {
	CadDrawing drawing = null;

	public DXFDrawingReader(String filename, CadDrawing drawing) {
	    this.drawing = drawing;
	    getDrawing(filename);
	}
	public CadDrawing getDrawing() {
	  	return drawing;
	}
	public void getDrawing(String Infile) {
	  //String name = new String(Infile.substring(0,Infile.lastIndexOf('.')));
      String line = "";
      try {
        BufferedReader in = new BufferedReader(new FileReader(Infile));
        while (((line = in.readLine()) != null) &&
              (!line.equalsIgnoreCase("ENTITIES"))) {
        }
        // read entities section
        while (((line = in.readLine()) != null) &&
              (!line.equalsIgnoreCase("ENDSEC"))) {
        // translate circle entities
          if (line.equalsIgnoreCase("CIRCLE")) {
          CadArc arc = new CadArc();
          readDXFCircle(in, arc);
        }
        // translate light weight polyline entities
        else if (line.equalsIgnoreCase("LWPOLYLINE")) {
          CadPolyLine lseg = new CadPolyLine();
          readDXFLWPolyline(in, lseg);
        } else {
        	System.out.println("line-> " + line);
        }
      }

      in.close();
    }  catch (IOException e) {
      System.out.println("IO Exception:" + Infile);
    }
  }
	  public void readDXFCircle(BufferedReader in, CadArc arc) throws IOException  {
	    String line;
	    while (((line = in.readLine()) != null)&&(!line.equals("  0"))) {
	      if (line.equals("  8")) {
//	    	CadLayer layer = new CadLayer(drawing);
//	      	layer.
//	        drawing.getLayers().add(new CadLayer(drawing));
//	      
//	      , Utils.getUniqueId(), line, -1, -1, true));
	        //this.layer = in.readLine();
	      }
	      else if (line.equals(" 10"))
	      	System.out.println("x-> " + in.readLine());	      	
	        //this.x= Double.parseDouble(in.readLine());
	      else if (line.equals(" 20"))
	      	System.out.println("y-> " + in.readLine());	      	
	        //this.y= Double.parseDouble(in.readLine());
	      else if (line.equals(" 40")) {
	      	System.out.println("radius-> " + in.readLine());	      	
	        //this.r = Double.parseDouble(in.readLine());
	        return;
	      }
	    }
	  }
	  public void readDXFLWPolyline(BufferedReader in, CadPolyLine lseg) throws IOException  {
	    String line;
	    //boolean closed;
	    //Point pt = new Point();

	    while (((line = in.readLine()) != null) && (!line.equals("  0"))) {
	      if (line.equals("  8")) {
	      	//System.out.println("layer-> " + in.readLine());
	        //this.layer = in.readLine();
	        drawing.getLayers().add(new CadLayer(drawing));
	      } else if (line.equals(" 70")) { //{
	      	System.out.println("line-> " + in.readLine());
//	        line = in.readLine();
//	        if (line.equals("     1")) 
//	        	closed = true;
//	        else 
//	        	closed = false;
//	      }
	      } else if (line.equals(" 10")) {
	      	System.out.println("x-> " + in.readLine());
	      	//	        pt = new Point();
//	        pt.x= Double.parseDouble(in.readLine());
	      }
	      else if (line.equals(" 20")) {
	      	System.out.println("y-> " + in.readLine());
	      	//	        pt.y= Double.parseDouble(in.readLine());
//	        pts.add(pt);
	      }
	    }
	    return;
	  }
	  
}
