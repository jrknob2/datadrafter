Leonard, Wayne says:
			String sql="SELECT DISTINCT TO_CHAR(MC.RPT_DATE,'MM/DD/YY - Dy')"+
                       "  FROM M_RPT_CALENDAR MC "+
                       " WHERE MC.RPT_DATE BETWEEN SYSDATE-1 AND SYSDATE+14 "+
                       " ORDER BY TO_CHAR(MC.RPT_DATE,'MM/DD/YY - Dy')";
Leonard, Wayne says:
			String sql="SELECT REQUEST_ID, MARKET, PLATFORM FROM M_RPT_CALENDAR WHERE rpt_date = TO_DATE(?, 'MM/DD/YY - Dy')  ORDER BY  market,lm_timezone";
Knoblock, Terry J says:
thx
