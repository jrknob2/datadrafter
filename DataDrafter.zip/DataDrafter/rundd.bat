"C:\Program Files (x86)\Java\jre7\bin\java" -cp lib\obf_personal_1_2.jar;lib\xml-api.jar;lib\xerces_2_5_0.jar com.datadrafter.personal.gui.DataDrafterPersonal
